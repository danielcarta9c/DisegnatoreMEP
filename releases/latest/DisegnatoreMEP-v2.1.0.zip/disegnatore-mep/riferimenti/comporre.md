# Comporre — dal grafo completo al piano

## Indice

- 1. Il lavoro, in tre righe
- 2. Il metodo, e viene prima di ogni regola
- 3. Cosa ricevi
- 4. Il file che produci
- 5. Le regole, nell'ordine in cui si applicano
- 6. Quello che il piano **non può** dire, e come si aggira
- 7. Cosa non è tuo, e non lo diventa
- 8. Il metodo di lavoro, passo per passo
- 9. Prima di consegnare: il controllo finale


**Queste istruzioni bastano da sole.** Non serve leggere altro per fare il lavoro: tutto
quello che ti serve — il metodo, i numeri delle porte, il formato del file, i controlli — sta
qui. I rimandi ai documenti servono a chi vuole sapere **da dove viene** una regola, non a chi
deve applicarla.

---

## 1. Il lavoro, in tre righe

Ricevi il **grafo completo** di un impianto — tutti i pezzi e tutte le tubazioni fra loro — e
produci il **piano**: un file JSON che dice **dove sta ogni pezzo posabile sul foglio**, e
nient'altro.

Non disegni tu. Il piano lo esegue un motore deterministico che posa, orienta, instrada in
griglia, interrompe le linee sotto i simboli, impagina e misura. **Tu decidi una cosa sola —
dove stanno i pezzi — e quella cosa decide la tavola.**

> **Il metro non è il numero di pieghe.** È se la tavola **assomiglia al lavoro di un
> disegnatore**. Un criterio grafico, non matematico.
>
> **E non esiste un numero massimo di curve** (**D-171**). Il committente, il 22 settembre
> 2026: «più dritte possibili, meno curve possibili e meno sormonti possibili, e viaggiano in
> parallelo. **Non c'è un numero massimo** — dicevo una curva nel caso del generatore singolo e
> due accumuli, ma era per far capire il concetto». Quindi **non hai un budget da spendere**:
> hai un confronto da vincere. Fra due pose dello stesso impianto vince quella con meno pieghe
> e meno sormonti, e **una piega che i simboli impongono non la conti fra le tue** — un
> collettore verticale si attraversa con due pieghe, una tre vie sulla terza via con una,
> l'ultima macchina entra in fondo al collettore con un gomito, e quelle non sono tue.

---

## 2. Il metodo, e viene prima di ogni regola

**Il disegno nasce dalle autostrade.** Lo ha detto il committente così:

> «Sposta le macchine in modo che le linee delle autostrade vengano con pochissime curve, poi
> attacchi il resto delle valvole piccole e strade secondarie. Ma **il disegno nasce dalle
> linee delle autostrade**. LE AUTOSTRADE CON POCHE CURVE e pochi sormonti.»

Un'**autostrada** è la tubazione grossa che unisce due macchine: la mandata dal generatore
all'accumulo, il ritorno dall'utenza al generatore, il tronco che attraversa la centrale.
**Per definizione ha poche curve e tratti rettilinei.** Le strade secondarie sono gli stacchi
verso valvole, strumenti, confini di rete.

### 2.1 La cosa che devi sapere prima di tutte: **la quota di un'autostrada non si sceglie**

È quella della **porta** della macchina che la genera. Le porte stanno a **millimetri fissi
dall'origine del pezzo**, e li trovi nel manifesto del simbolo (`python3 scripts/mep.py simbolo <id>`).
Questi sono quelli che incontri quasi sempre:

| pezzo | ingombro | porte, e a che quota dall'origine |
|---|---|---|
| `heat-pump-air-water` | 40 × 30 | `water_supply` **destra +5** · `water_return` **destra +20** |
| `gas-boiler` | 40 × 30 | `water_supply` **destra +5** · `water_return` **destra +20** |
| `heat-pump-air-water-large` (pompa di calore di alta potenza) | 60 × 30 | `water_supply` **destra +5** · `water_return` **destra +20** |
| `gas-boiler-modular` (caldaia modulare) | 60 × 25 | `water_supply` **destra +5** · `water_return` **destra +20** |
| `solar-collector` (collettore solare) | 40 × 25 | `supply` **destra +5** · `return` **destra +20** — sul fluido solare |
| `buffer-four-port` | 25 × 45 | `primary_in` **sinistra +5** · `primary_out` **sinistra +20** · `secondary_out` **destra +5** · `secondary_in` **destra +20** · `vent` sopra e `drain` sotto, a x +12,5 |
| `buffer-two-port` | **25 × 10, coricato** | `a` sinistra +5 · `b` destra +5 — **in asse** · `vent` sopra e `drain` sotto, a x +12,5 · `probe` sotto, a x +17,5 |
| `dhw-heat-pump` (pompa di calore per ACS) | 25 × 45 | `cold_in` sinistra +37,5 · `dhw_out` sopra, a x +12,5 |
| `zone-manifold` (collettore di zona) | 40 × 5 | `in` sinistra +2,5 · `out_1` sotto, a x +12,5 · `out_2` sotto, a x +27,5 |
| `zone-manifold-pair` (collettore con ritorno) | **40 × 15** | `in` sinistra +2,5 · `out` sinistra +12,5 · sotto, **a coppie a 10 mm come i terminali**: `out_1` a x +7,5 e `ret_1` a x +17,5, `out_2` a x +27,5 e `ret_2` a x +37,5 |
| `zone-manifold-pair-3` … `-12` (collettore con ritorno a N vie) | **20·N × 15** | come quello a due, una coppia ogni **20 mm**: `out_n` a x +7,5 + 20·(n−1), `ret_n` 10 mm più in là · `in` e `out` a sinistra |
| `buffer-six-port` (volano a sei attacchi) | 25 × 45 | come `buffer-four-port` · in più `aux_in` destra +27,5 e `aux_out` destra +37,5, gli attacchi predisposti |
| `capped-connection` (attacco predisposto) | 5 × 5 | `a` destra +2,5: il tappo è dall'altra parte |
| `buffer-combined` | 25 × 45 | `primary_in` **sinistra +5** · `primary_out` **sinistra +20** · `secondary_out` **destra +5** · `secondary_in` **destra +20** · `dhw_out` sopra, a x +7,5 · `cold_in` sinistra +37,5 |
| `plate-heat-exchanger` | 12,5 × 25 | `primary_in` **sinistra +5** · `primary_out` **sinistra +20** · `secondary_out` destra +5 · `secondary_in` destra +20 |
| `dhw-cylinder` | 25 × 45 | `coil_in` sinistra **+7,5** · `coil_out` sinistra **+17,5** · `dhw_out` sopra · `cold_in` sinistra +37,5 · `recirculation_in` **destra +12,5**, il ricircolo (D-176) |
| `radiator`, `fan-coil`, `fan-coil-ducted`, `ahu-coil`, `underfloor-panel` | 20 × 15 | `in` **sinistra +2,5** · `out` **sinistra +12,5** — tutt'e due **sullo stesso lato** (D-167) |
| `dhw-cylinder-twin-coil` (bollitore a due serpentini) | 25 × 55 | `coil_in` sinistra **+7,5** · `coil_out` sinistra **+17,5** · `solar_coil_in` sinistra **+27,5** · `solar_coil_out` sinistra **+37,5** · `cold_in` sinistra +47,5 · `dhw_out` sopra, a x +7,5 · `recirculation_in` destra +12,5 |
| `mixing-valve-thermostatic` (miscelatrice termostatica ACS) | 5 × 10 | `hot_in` sinistra +5 · `out` destra +5 · `cold_in` **sotto, a x +2,5** — è una tre vie (D-175): la posi tu, e la giri |

**Guarda l'interasse.** Pompa di calore, caldaia, volano e scambiatore a piastre hanno tutti
le due porte principali a **15 mm** l'una dall'altra, e alle **stesse quote +5 e +20** — e
così la pompa di calore di alta potenza, la caldaia modulare e il collettore solare. Questo
vuol dire una cosa sola, ed è la leva più potente che hai:

> ## Due macchine posate allo **stesso y** danno **due autostrade perfettamente rette**, gratis.

Pompa a `y=60` e volano a `y=60`: la mandata corre a 65 da una porta all'altra senza una
piega, il ritorno a 80. **Non hai speso niente.** Se invece le posi a `y=60` e `y=75`, ogni
linea fra loro fa **due pieghe** e te le porti dietro per tutta la tavola.

⚠ **Conta la quota della porta, non l'origine.** «Stesso `y`» vale per chi ha le porte alle
stesse quote. Un volano **a due attacchi** è **coricato e in linea** (**D-196**): alto 10, con `a`
e `b` in asse a +5. Per metterlo sul ritorno di una pompa, che esce a +20, lo posi **15 mm più
in basso** della pompa, e il ritorno gli passa dentro dritto, come in una valvola. Lo
**sfiato** — un pezzo solo col suo rubinetto, 5 × 7,5 (I-211) — sta sul suo cielo, addosso
all'attacco `vent`: `x` +10, `y` **−7,5** rispetto al volano. Resta 2,5 mm sotto la mandata,
che gli passa sopra dritta. Lo **scarico** sta sotto,
addosso a `drain`. Fino al 2 ottobre 2026 il volano a due attacchi era ritto, 25 × 45, e il
suo sfiato arrivava esattamente sulla quota della mandata: la mandata non poteva passargli
sopra (I-172).

⚠ **Il bollitore ha l'interasse 10, non 15** — `coil_in` +7,5 e `coil_out` +17,5 — perché
quelle due porte dicono **dov'è la serpentina dentro l'accumulo**, e non si spostano. La
coppia che lo serve **cambia interasse per forza**: è vero, è noto, e non si cura.

⚠ **Un terminale si prende da un lato solo**: `in` e `out` stanno tutt'e due sulla **faccia
sinistra**, a +2,5 e +12,5, con la mandata sopra. La coppia gli arriva **affiancata** e entra:
niente giro intorno, niente fascia sprecata a destra. È **D-167**, e il PO l'ha disposto così
dopo aver ridisegnato a mano due nostre tavole: «con uscita dall'altro lato **si spreca
spazio**, meglio metterli sempre con **ingresso e uscita su un lato solo**».

### 2.2 Il procedimento, in quest'ordine e non in un altro

1. **Leggi le porte delle macchine di spina** — generatori, accumuli, scambiatori, volani. La
   quota delle autostrade è già decisa da loro.
2. **Posa le macchine su quelle quote.** È la mossa che decide la tavola. Scegli **una fascia
   orizzontale per il primario** e mettici tutte le macchine che quel tronco attraversa, con
   lo **stesso y**.
3. **Chi sta in parallelo si impila**, uno sopra l'altro, e si unisce con **una verticale sola,
   corta, accanto alle macchine** — non in mezzo al foglio. Ogni macchina ci entra con uno
   **stacco orizzontale corto**.
4. **Tira le autostrade con gli occhi e guarda se sono rette**, prima di appendere qualunque
   cosa. Se una piega, torna al punto 2: **si sposta la macchina, non si accetta la piega**.
5. **Solo adesso** appendi valvole, strumenti, confini di rete e strade secondarie.

---

## 3. Cosa ricevi

Il **grafo completo** in JSON. Quello che ti serve:

- `components` — ogni pezzo con `id`, `definition_id` (che dice quale simbolo è), `tag`;
- `connections` — ogni tubazione, con le due estremità `{component_id, port_id}` e la rete;
- `networks` — a che circuito appartiene ogni tubazione, e con che fluido.

**Da un pezzo al suo simbolo.** `definition_id` dice **che cosa è** il pezzo, non quale
simbolo lo disegna: il simbolo lo dice la voce di catalogo del pezzo
(`python3 scripts/mep.py catalogo <definition_id>`, campo `symbol_id`), e il manifesto è
`python3 scripts/mep.py simbolo <symbol_id>`. Serve, perché i nomi non coincidono sempre: `tee-split` e
`tee-junction-dhw` si disegnano col simbolo `tee-junction`, `cold-water-inlet`,
`dhw-draw-off`, `existing-plant-inlet` e `existing-plant-outlet` con `network-boundary`, tutte le
`valve-isolation-*` con `valve-isolation`.

**Un pezzo con una scritta** — `etichetta` fra le sue proprietà, «al solare termico» su un
attacco predisposto, «verso impianto esistente» su un confine — vuole **un lato libero accanto**,
largo quanto la scritta: il motore la posa lì, o con un richiamo corto. Se non trova posto la
tavola **non esce** (`FREE_LABEL_OMITTED`, I-194): la scritta l'ha data il progettista. Non
mettere quel pezzo fra due tubazioni vicine.

**Chi è una macchina e chi è corredo** lo capisci dall'ingombro e dalle porte: un pezzo 40×30
o 25×45 è una macchina, un pezzo di 5 o 7,5 mm con due porte in linea è un organo che sta
**sopra una tubazione**. Un `tee` è un raccordo: unisce tre tubazioni e **non si posa a
occhio**, si posa dove il collettore deve stare. **Quale tubazione gli passa dritta lo decide
la posa, non il grafo**: il motore gira il raccordo e gli assegna le porte guardando dove
stanno i vicini — chi è allineato con l'uscita entra dritto, l'altro dalla derivazione.
Misurato: scambiando di posto le due zone che un raccordo riunisce, la mappa delle porte si
inverte con loro.

**I raccordi di una catena si posano nell'ordine della catena.** `python3 scripts/mep.py pezzi
<grafo>` finisce con «In che ordine stanno lungo le tratte»: per ogni catena, i pezzi dal primo
capo all'ultimo — `pdc.water_return → … → tee-vaso → tee-riempimento → tee-manometro →
confluenza.b`. Posali in quella fila, dal capo da cui parte verso quello a cui arriva, senza
scambiarne due. Il collaudo della 1.7.0 li ha posati al contrario: il ritorno è tornato
indietro, si è scavalcato due volte e la tavola non esce (`RUN_CROSSES_ITSELF`).

---

## 4. Il file che produci

JSON, e solo queste chiavi:

```json
{
  "formato": "A2",
  "note": [
    "Le due pompe impilate a x=35, y=60 e y=110: il collettore e' una verticale corta accanto a loro (A2, B3).",
    "Volano a y=60, sulla stessa quota della pompa maestra: mandata e ritorno rette, zero pieghe (D-159)."
  ],
  "pezzi": {
    "pdc-1":   {"x": 35,  "y": 60,  "regola": "D-159 — quota della porta"},
    "pdc-2":   {"x": 35,  "y": 110, "regola": "A2 — chi sta in parallelo si impila"},
    "volano":  {"x": 220, "y": 60,  "regola": "D-159 — stesso y della pompa: autostrade rette"},
    "deviatrice": {"x": 150, "y": 62.5, "rotazione": 0}
  }
}
```

- **`formato`** — uno fra `A3`, `A2`, `A1` (l'A4 non c'è più: non contiene il cartiglio, **D-186**).
  Scegli il più piccolo in cui l'impianto ci sta comodo. ⚠ **Ma non allargare il disegno per riempirlo**: il vuoto non è un difetto
  (**D-170**, D3). **Se hai preso un foglio più grande del necessario te lo dice il rapporto**
  (`SHEET_LARGER_THAN_NEEDED`), e si cambia una riga e si rilancia.
- **`pezzi`** — un'entrata per **ogni pezzo di `components` che posi tu**, e **solo** per
  quelli. ⚠ Il grafo nomina altre decine di identificativi in `subsystems` e
  `rule_applications` che **non sono pezzi**: ignorali.
  **Gli organi in linea non li posi tu**: valvole d'intercettazione, filtri, defangatori,
  separatori d'aria, circolatori, ritegni, riduttori, gruppi di sicurezza sanitari, il giunto
  antivibrante e la riduzione all'attacco della macchina (`pipe-reducer`, D-233). Li
  riconosci dal manifesto del simbolo, che dichiara `inline_gap_mm`: il motore li posa **da
  solo, sulla loro tratta** (§4bis). Se ne scrivi uno nel piano, il comando te lo dice e si
  ferma. ⚠ Il **rubinetto portamanometro** si chiama «a tre vie» (`valve-gauge-cock-3way`) ma
  è un organo in linea a due attacchi: non è una tre vie, non si posa e non si ruota.
  ⚠ **La miscelatrice termostatica dell'ACS non è più un organo in linea** (**D-175**): ha il
  terzo attacco, da cui entra l'acqua fredda, e **la posi tu** come ogni tre vie.
  **Tutti gli altri li posi tu**: macchine, raccordi (`tee-*`), valvole a tre vie — compresa
  la miscelatrice termostatica —, strumenti, sfiati, scarichi, vasi, gruppi di riempimento,
  confini di rete. Uno che dimentichi il motore
  lo mette accanto al pezzo a cui è attaccato, come può: è una rete di sicurezza, non un modo di
  comporre — **scrivili tutti**.
  `x` e `y` sono in millimetri, **origine in alto a sinistra del pezzo**, e si arrotondano al
  passo di griglia: **usa multipli di 2,5**.
  **Non sono coordinate sul foglio: contano solo le posizioni relative.** Prima di instradare
  il motore porta l'intero disegno al centro dell'area del formato che hai scelto, la stessa
  traslazione per tutti i pezzi — puoi cominciare da zero, e anche andare in negativo. Per
  questo non puoi collocare niente rispetto al bordo o al cartiglio: **D1 si governa con la
  forma della posa, D3 con la scelta del formato**. Quello che deve tornare è la misura: il
  disegno deve **starci** nell'area del formato, altrimenti le tratte che escono non trovano
  strada.
- **`rotazione`** — in **gradi orari**. **Scrivila solo dove la deduzione non arriva**: per un
  raccordo o per un pezzo con un attacco solo **non scriverla**, perché la rotazione è una
  conseguenza della posa e il motore la deduce dai vicini che il pezzo ha davvero.
  ⚠ **Su una valvola a tre vie devi scriverla** (**D-168**): la deduzione non la gira, e senza
  la tua scelta la terza via finisce **sempre verso il basso**. Il PO l'ha detto guardando le
  tavole: «la valvola a tre vie la metti sempre con uscita terza verso il basso, **guarda che
  puoi ruotarla**». **La terza via guarda il pezzo che serve**, e da che parte sta quel pezzo lo
  sai tu. Lo stesso vale per il **gruppo di riempimento**, che ha due attacchi e non è una
  macchina, e per la **miscelatrice termostatica**: il PO, il 23 settembre 2026, «anche lei è
  una di quelle valvole che deve poter ruotare e specchiare per evitare sormonti o curve non
  necessarie» (**D-175**).
- **`specchio`** — vero o falso, e si applica **prima** della rotazione, attorno all'asse
  verticale del pezzo. **Le giaciture sono otto, non quattro** (**D-169**), e per una valvola a
  tre vie le quattro rotazioni **non bastano**: leggi il riquadro qui sotto prima di posarne una.
  ⚠ **Molti simboli non si ruotano affatto** — pompa di calore, caldaia, volano, scambiatore a
  piastre dichiarano `allowed_rotations_deg: [0]`, e chiedere un'altra rotazione **fa abortire
  il comando**. Guarda il manifesto prima di scriverla. **Lo specchio invece vale per tutti**,
  anche per chi non si ruota (D-169): un volano a due attacchi specchiato ha `a` a destra e `b`
  a sinistra, ed è il modo di farlo guardare dall'altra parte senza girarlo.
- **`zone_tabelle`** — **non scriverla.** Sulla tavola vanno solo la tabella delle apparecchiature
  e la legenda, che il motore posa da sé (I-233): la tabella delle tratte, il computo e le note
  della distinta materiali stanno nel suo PDF, a parte, e `disegna` non riceve `--tabelle`. Il
  formato è il più piccolo che contiene il disegno — di solito un A3. (La chiave c'è ancora, per il
  motore che sa posare tabelle; il flusso della skill non la usa.)
- **`note`** e **`regola`** — **non sono decorazione.** Il piano senza di loro dice dove
  stanno i pezzi e non dice **perché**, e chi lo rivede non può correggerlo: può solo
  spostare. `note` porta la motivazione del piano intero, `regola` la stessa cosa pezzo per
  pezzo. **Ogni pezzo che hai spostato per una ragione porta quella ragione.**

Niente altre chiavi: il caricatore rifiuta quello che non riconosce, e te lo dice.

### 4bis. Il corredo: che cosa posa il motore, e che cosa chiede a te

Il grafo completo porta il **corredo** — organi in linea, strumenti, sfiati, scarichi, vasi,
gruppi di riempimento, confini di rete — e si mette **dopo** lo scheletro (§2.2, passo 5). È
di due specie, e le due si trattano in modo diverso:

- **gli organi in linea li posa il motore**. Si mettono in fila sulla loro tratta **a partire
  dalla porta del pezzo che isolano** — da un capo della tratta o dall'altro, secondo chi si
  manutiene —, a distanza fissa, e ogni organo vuole il proprio pezzo di rettilineo. **Il tuo
  lavoro è lasciarglielo** (B5): se la tratta non ha il rettilineo che la fila chiede, il
  comando si ferma e ti dice su quale tratta e quanti millimetri servono — «run X has no
  straight stretch of N mm for …». Si cura allontanando i due pezzi che la tratta unisce, o
  raddrizzandola; **mai** togliendo un organo, che è contenuto dell'impianto.
  **Quanto rettilineo chiede una fila**, misurato sul motore il 23 settembre 2026 fra la porta
  di una pompa e un raccordo: con una valvola **17,5 mm**, con due organi **20–25 mm**. Non è
  una costante: è il punto da cui partire, e se non basta il comando ti dice la tratta —
  allontana i due pezzi **un passo alla volta**. Con i diametri chiesti, sulla pompa di
  calore il giunto ha dopo di sé la **riduzione** quando il tubo è più piccolo dell'attacco
  (D-233): sulla villetta di riferimento la mandata, dalla porta al raccordo della
  sicurezza, ne ha voluti **32,5 mm**, 10 più di prima;
- **gli appesi li posi tu**: un manometro, un termometro, uno sfiato, uno scarico, un vaso,
  una sicurezza, un gruppo di riempimento stanno all'altro capo di uno **stacco** che parte da
  un raccordo sulla linea (`tee-branch`). Stanno **addosso** (A4), con lo stacco più corto che
  la griglia consente: il rilievo `SERVICE_STUB_LONGER_THAN_ITS_MINIMUM` ti dice di quanti
  millimetri sei lontano. **Il raccordo che regge lo stacco sta sulla linea, alla sua quota**
  (B8): fuori quota, la linea va a prenderlo e torna. E **prima di appendere guarda quale
  autostrada passa di lì** (§6): un appeso nella colonna che una linea deve percorrere la
  costringe a girargli intorno;
- **i confini di rete** — l'acquedotto, le utenze sanitarie — stanno **addosso al pezzo che
  servono**, con lo stacco minimo (A4), non nella fascia della distribuzione. Vale anche per
  gli ingressi dell'acqua fredda che il completamento aggiunge — `AF-02`, `AF-03`… —, uno per
  ciascun pezzo che la usa: il gruppo di riempimento e la **miscelatrice termostatica**, che
  riceve il suo «pezzetto di AF in ingresso» (D-175) sulla terza via, `cold_in`. Il suo
  confine sta **sotto la terza via**, o dove l'hai girata, con la valvola di confine in mezzo.
- **il ricircolo sanitario**, dove c'è, **entra dal proprio confine** — sigla «ACS-R», lo
  stesso simbolo dell'ingresso dell'acqua fredda — e **torna nel bollitore** dal suo
  attacco destro, `recirculation_in` (D-176). Sulla sua tratta il motore mette in fila il
  circolatore, il ritegno e le valvole: è una tratta lunga, e vuole il suo rettilineo (B5).
  **Si disegna verde chiaro**, ed è giusto: è il colore che il committente usa per il
  ricircolo.

⚠ **Lo scheletro si posa pensando al corredo.** Le porte che il corredo userà dopo devono
restare raggiungibili: l'acqua fredda del bollitore entra da **sinistra a +37,5**, e se davanti
ci passano le due verticali della serpentina resta murata. Prima di chiudere lo scheletro,
guarda dove attaccherà ogni confine di rete e ogni appeso.

### L'algebra di una valvola a tre vie, e perché le rotazioni non bastano

Una tre vie ha la **via dritta** — `in_a`/`out` su facce opposte — e la **terza via
perpendicolare** a quella. Ruotando, **gira tutto insieme**: la terza via resta sempre dalla
stessa parte rispetto al verso della via dritta.

`switching-valve-3way`: `in_a` **sinistra** · `out` **destra** · `in_b` **sotto**.
`diverting-valve-3way`: `in` **sinistra** · `out_a` **destra** · `out_b` **sotto**.
`mixing-valve-thermostatic`: `hot_in` **sinistra** · `out` **destra** · `cold_in` **sotto** —
la via dritta è quella dell'acqua calda, dall'accumulo alle utenze, e la terza via è l'acqua
fredda che la miscela (D-175). Ha le giaciture della deviatrice, con `hot_in`, `out` e
`cold_in` al posto di `in`, `out_a` e `out_b`; è larga 5 e alta 10, quindi la terza via sta a
**x +2,5**, e ruotata di 90 o 270 diventa larga 10 e alta 5.

Le **otto** giaciture della commutatrice, e serve leggerla come una tabella:

| | `in_a` | `out` | `in_b` |
|---|---|---|---|
| rotazione 0 | sinistra | destra | sotto |
| rotazione 90 | **sopra** | **sotto** | sinistra |
| rotazione 180 | destra | sinistra | sopra |
| rotazione 270 | sotto | sopra | destra |
| specchio + 0 | destra | sinistra | sotto |
| specchio + 90 | sotto | sopra | sinistra |
| specchio + 180 | sinistra | destra | sopra |
| **specchio + 270** | **sopra** | **sotto** | **destra** |

E quelle della **deviatrice**, che ha la stessa forma con altri nomi:

| | `in` | `out_a` | `out_b` |
|---|---|---|---|
| rotazione 0 | sinistra | destra | sotto |
| rotazione 90 | sopra | sotto | sinistra |
| rotazione 180 | destra | sinistra | sopra |
| rotazione 270 | sotto | sopra | destra |
| specchio + 0 | destra | sinistra | sotto |
| specchio + 90 | sotto | sopra | sinistra |
| specchio + 180 | sinistra | destra | sopra |
| specchio + 270 | sopra | sotto | destra |

Serve ricevere dall'alto, mandare in basso e prendere la terza via **a destra**? **Nessuna
delle quattro rotazioni ce l'ha.** La 90 ha le prime due ma la terza via a sinistra; la 270 ha
la terza via giusta e le altre due rovesciate. La giacitura esiste, ed è **una sola**:
`{"rotazione": 270, "specchio": true}`.

⚠ **Che succede se la sbagli, misurato:** la linea che arriva dalla parte sbagliata **gira
intorno alla valvola** — scende sotto, la scavalca, rientra dall'altra faccia — con **quattro
pieghe**. Sull'impianto 4, mettere la giacitura giusta ha portato le spezzate piegate da 4 a 3,
le pieghe da 5 a 4 e i sormonti da 3 a 2.

**La regola che ne esce, e vale oltre le tre vie:** un organo a tre vie **non si appende a una
linea** — si posa **nel punto dove le sue tre linee si incontrano**, e poi si sceglie la
giacitura che fa entrare ciascuna dalla faccia da cui arriva.

### I quattro numeri che ti servono, e che nessun errore dovrebbe doverti insegnare

| | |
|---|---|
| passo di griglia | **2,5 mm** — ogni `x` e `y` è un suo multiplo |
| stacco minimo di un organo di servizio (A4) | **10 mm** se lo stacco è vuoto; se porta organi in linea, quanto chiede la loro fila — il rilievo `SERVICE_STUB_LONGER_THAN_ITS_MINIMUM` scrive il minimo di ogni stacco. Sotto i 10 mm il motore a volte instrada, ma **due simboli più vicini di 10 mm si leggono come uno** (D-062): non ci scendere |
| corsia libera fra due linee affiancate (B9) | **10 mm** |
| interasse delle porte principali di una macchina | **15 mm** — pompa, caldaia, volano, scambiatore |

---

## 5. Le regole, nell'ordine in cui si applicano

Quando due si contendono lo stesso pezzo, **vince quella più in alto**, e la più in basso
cede. **Non si sommano mai**: una media pesata fra regole è il modo in cui questo progetto ha
già sbagliato una volta.

### A1 — Tre fasce verticali, da sinistra a destra
**Generazione** · **accumuli e scambiatori** · **distribuzione**: le parole sono del PO, e il
processo si legge da sinistra a destra. Chi sta in quale fascia lo dice il catalogo, ed è la
stessa lettura del rilievo `PIECE_OUTSIDE_ITS_BAND`:

- **generazione** — chi genera: pompe di calore, caldaie, **e la pompa di calore per ACS**
  (`dhw-heat-pump`), che il catalogo dichiara generatore anche se ha un accumulo dentro;
- **accumuli e scambiatori** — volani, bollitori, separatori, **scambiatori a piastre**,
  compreso quello istantaneo dell'ACS;
- **distribuzione** — i terminali che consegnano il calore all'ambiente.

**Non hanno una fascia**, e quindi non la allargano e non la violano: raccordi, organi in
linea, appesi, collettori, valvole a tre vie, confini di rete. Stanno dove serve il pezzo a
cui sono legati.

### A2 — Chi sta in parallelo si impila
Due pompe, tre pompe in cascata, due caldaie: **uno sopra l'altro, stessa x**, con un passo
verticale costante. Mai affiancate.

### A4 — Un organo di servizio sta **addosso** al pezzo che serve
Un confine di rete, un prelievo, uno scarico: **lì accanto, con un tratto di tubazione
corto**. Non «da qualche parte nella fascia giusta». È l'errore più comune di chi legge solo
A1: mette il confine ACS nella fascia della distribuzione e lo fa finire **a mezzo foglio di
distanza** dal bollitore che serve.

### B1 — Le autostrade dritte
Vedi §2. **Se una piega, si sposta la macchina** — a meno che la piega non te la impongano i
simboli, e allora non è tua e non la puoi togliere spostando niente. **Non c'è un massimo di
curve** (**D-171**): il rilievo `HIGHWAY_IS_NOT_STRAIGHT` ti dice quante ne hai fatte **in
più** di quelle imposte, e quelle in più si tolgono spostando le macchine.

**Quali pieghe ti impongono i simboli, e quali no.** Sono imposte:
- **dentro un pezzo** che la catena attraversa: entrare da una faccia e uscire da una
  perpendicolare è una piega — il collettore verticale che B3 pretende ne costa due, una tre
  vie sulla terza via una;
- **fra due pezzi** le cui porte stanno su **assi perpendicolari** — una uscita orizzontale e
  una verticale: è una **L**, e non la toglie niente. È il gomito dell'ultima macchina in
  fondo al collettore verticale, la terza via della deviatrice che va alla serpentina del
  bollitore (una L sola se la discesa dalla deviatrice **corre accanto al ritorno della
  serpentina, all'interasse delle autostrade**: si sposta la deviatrice, non il bollitore — B11,
  B12, I-240),
  la testa della colonna del pettine;
- il **gradino di una coppia** fra due macchine con interassi diversi — il volano a 15, il
  terminale a 10: una delle due linee corre dritta, l'altra scala di 5 mm, e quello è il suo
  prezzo.

**E un sormonto può essere imposto anche lui.** Un pezzo che prende dalla mandata e rende al
ritorno, e sta **fuori dalla coppia** — il bollitore appeso sotto o sopra le due linee del
primario — con una delle due diramazioni deve scavalcare l'altra linea: un sormonto che
nessuna posa toglie.

**Non sono imposte**, e il rilievo te le conta:
- una **U** fra due porte che guardano dalla stessa parte: si toglie **specchiando** uno dei due
  pezzi (§4, `specchio`);
- una linea che **gira intorno** a un pezzo che dovrebbe attraversare dritta — una tre vie o un
  raccordo di traverso sulla linea: si gira il pezzo, e la linea passa;
- il gradino fra due porte che si guardano, quando le due macchine non stanno allo stesso `y`;
- il giro largo, quando arrivi a una porta dalla parte sbagliata.

### B3 — Più macchine in parallelo ⇒ **collettore verticale**
I due raccordi che uniscono un parallelo stanno su **una verticale corta accanto alle
macchine**. Due collettori — mandata e ritorno — stanno su **due verticali diverse**, vicine.

**Quale delle due sta più vicina alle macchine lo decidono i sormonti**, ed è il committente
che l'ha detto: «indifferente, quello che fa **meno sormonti** direi; se indifferente scegli
tu». Con le macchine impilate, lo stacco che va alla verticale lontana attraversa quella
vicina: qualunque sia l'ordine, qualche sormonto c'è. **Prova i due ordini e tieni quello con
meno sormonti**; a parità scegli, e scrivi nelle note che cosa hai misurato. Misurato sulla
cascata di tre pompe: 5 sormonti con la mandata vicina, 6 col ritorno vicino.

**Il collettore è una linea sola, e lo decide la giacitura dei raccordi.** Il raccordo a T
(`tee-junction`, anche per la ripartizione `tee-split`) ha la via dritta `a`–`b` e il braccio
`c`. Ha otto giaciture come le tre vie, **specchio compreso**:

| | `a` | `b` | `c` |
|---|---|---|---|
| rotazione 0 | sinistra | destra | sopra |
| rotazione 90 | sopra | sotto | destra |
| rotazione 180 | destra | sinistra | sotto |
| rotazione 270 | sotto | sopra | sinistra |
| specchio + 0 | destra | sinistra | sopra |
| **specchio + 90** | **sotto** | **sopra** | **destra** |
| specchio + 180 | sinistra | destra | sotto |
| specchio + 270 | sopra | sotto | sinistra |

Una dorsale che **sale** con le macchine a destra (il ritorno di più terminali in colonna) vuole
`{"rotazione": 90, "specchio": true}`: nessuna delle quattro rotazioni ce l'ha. Posa i raccordi
uno sopra l'altro sulla x della dorsale, ciascuno alla quota dell'attacco della sua macchina.
⚠ **Misurato su REL-026**, tre ventilconvettori: coi raccordi girati senza specchio il ritorno
faceva un dente a ogni confluenza (8 pieghe, e il rilievo `PARALLEL_MACHINES_WITHOUT_A_COLLECTOR`);
con la giacitura giusta 4 pieghe e nessun rilievo. **Quel rilievo non si lascia: si cura.**
Se nel grafo la dorsale passa per il braccio `c` invece che per `a`–`b`, nessuna giacitura la
raddrizza: è da correggere **nel grafo** (Capire, §«la via dritta del raccordo»), e lo dici.

### B8 — Una linea non lascia la propria quota per poi tornarci
Il sali-scendi. Se un pezzo sta su un'autostrada, **posalo sulla quota dell'autostrada**, o la
linea scende a prenderlo e poi risale, portandosi dietro tutto quello che le sta appeso.

### B10 — Mandata sopra, ritorno sotto
Sulle orizzontali, sempre. È anche il motivo per cui le porte sono a +5 e +20 e non viceversa.

### B11 — Mandata e ritorno corrono **insieme**
«Corrono sempre insieme, non esiste che una va e l'altra va zig zag accanto.» Stesso interasse
per tutta la corsa. Se lo perdono, è perché le due macchine agli estremi hanno interassi
diversi — e allora o le allinei, o è uno dei due casi noti: la **serpentina del bollitore**
(interasse 10, §2.1) e il **terminale** (interasse 10, D-167) contro una macchina a 15.

⚠ **Nei due casi noti il rilievo `SUPPLY_AND_RETURN_DO_NOT_RUN_TOGETHER` è vero e non si
cura**: la coppia cambia interasse per forza, ed è lo stesso gradino che B1 ti dà per imposto.
**Non inseguirlo.** Il rilievo guarda solo le corse di almeno 20 mm: avvicinare il terminale
finché la corsa scende sotto i 20 mm lo spegne senza cambiare il disegno, ed è esattamente
inseguire un numero. Metti il terminale dove il disegno lo vuole, e scrivi nelle note che il
rilievo resta ed è il caso noto.

### B12 — La coppia è un binario, e si ramifica **a pettine**

**È la regola che il PO ha disegnato invece di dirla**, riprendendo due nostre tavole:

> **Mandata e ritorno sono un oggetto solo — un binario a due corsie — e si ramificano a
> pettine.** Due colonne **adiacenti** portano il fluido, e da quelle si stacca **una coppia di
> orizzontali per ogni utenza**: mandata sopra, ritorno sotto, **affiancate per tutta la
> corsa**, fino al terminale, che si prende **da un lato solo**.

Tre cose che questa regola vieta, e che si sbagliano sempre:

1. **una colonna di ritorno lontana**, con ogni utenza che va a prendersela. Le due colonne
   stanno **vicine**, e le utenze si servono dalla coppia;
2. **due collettori distanti fra loro**: stanno su **una colonna stretta addosso alle
   macchine**, non a duecento millimetri;
3. **una coppia che si apre**: se mandata e ritorno prendono strade diverse per arrivare allo
   stesso pezzo, la posa è sbagliata — non l'instradamento.

**Come si compone un pettine**, in pratica: impila le utenze in colonna, metti le due colonne
del binario **alla loro sinistra e vicine fra loro**, e posa ogni utenza alla quota che vuoi —
la coppia le arriva orizzontale, affiancata, e entra da sinistra.

### La distribuzione di una centrale grande (I-204, I-205)

Il PO, sul primo caso reale: «in una centrale grande dove disegniamo la distribuzione anche le
dorsali mandata-ritorno della distribuzione dopo le pompe secondarie **sono delle autostrade e
come tali vanno trattate**». E: «le pompe in parallelo si disegnano in parallelo, o entrambe
verso destra o su o giù, ma non una da una parte e una dall'altra».

1. **La coppia del secondario resta sulle quote del volano** (`secondary_out` +5, `secondary_in`
   +20) fino alla zona più lontana: è la sua autostrada, dritta. Vaso e manometro che le
   regole o il progettista mettono sul ritorno pendono **in giù** da lì.
2. **Le pompe di zona le posa il motore**, sulla loro tratta, e le mette sul **primo rettilineo
   orizzontale** che contiene valvola, pompa e valvola (circa 35 mm). Dai a ogni tratta di pompa
   quel rettilineo, e le pompe escono parallele e con lo stesso verso. La zona lontana prende la
   pompa sulla coppia dritta; quella vicina parte da un raccordo sulla mandata, **scende sotto il
   ritorno** — lo incrocia una volta — e corre orizzontale con la sua pompa fino alla sua colonna.
3. **Ogni zona ha le sue due colonne affiancate, a 10 mm** (B12), e i collettori alla loro
   destra, uno sotto l'altro. Le colonne si ordinano così la coppia gira senza incrociarsi:
   - la coppia che arriva da sinistra con la mandata sopra scende con **il ritorno dentro e la
     mandata fuori** (la mandata, che sta sopra, gira più in là);
   - la zona che arriva con la sola mandata, da sotto il ritorno, ha **la mandata dentro**: il
     ritorno sale fuori fino alla dorsale.
   Il ramo verso ogni collettore attraversa l'altra colonna una volta: è il pettine, e va bene.
4. **Il primo raccordo di una colonna si gira a mano** (C2): dedotto, guarda il raccordo delle
   pompe che sta a sinistra e prende la coppia di lato — due pieghe in più per linea. Sulla
   colonna di mandata `"rotazione": 90` (ingresso in alto, prosecuzione in basso, collettore a
   destra); su quella di ritorno `"rotazione": 90, "specchio": true` (uscita in alto, ingresso
   dal basso, collettore a destra).
5. **Il collettore con ritorno prende i terminali sotto la sua coppia**: ventilconvettore e
   pannello con `"rotazione": 270, "specchio": true` — gli attacchi in alto, la mandata a
   sinistra —, a x **+5** e **+25** dal collettore, **35 mm più in basso** (la discesa tiene la
   valvola dell'uscita). Due linee dritte per terminale; collettori uno ogni **60 mm**.
   **A N vie è lo stesso** (`zone-manifold-pair-N`): il terminale della via *n* a x **+5 + 20·(n−1)**,
   tutti alla stessa `y`, 35 mm sotto il collettore. Il collettore è largo 20 mm per via — 120 a sei,
   240 a dodici —: misura la posa prima di scegliere il foglio (D3).

**Prima le autostrade**, anche per il motore (I-201, I-203): instrada le autostrade, poi la
distribuzione, per ultimi gli stacchi, e un'autostrada disegnata non si sposta più.

**Lo sfiato è un pezzo solo, 5 × 7,5, con il suo rubinetto** (I-210, I-211), e pende **addosso al
suo raccordo, senza tubo in mezzo** (I-212): l'origine dello sfiato alla `x` del raccordo e alla sua `y`
−7,5, così che la porta dello sfiato stia sul braccio del raccordo. Sale 10 mm dalla linea: sul ritorno
di una pompa di calore, con la mandata 15 mm sopra, resta 5 mm sotto la mandata e **non la scavalca
mai**, neppure sulla macchina la cui mandata prosegue come autostrada. Sul cielo di un volano sta
addosso all'attacco `vent`, a `y` −7,5. Ogni millimetro di stacco in più lo segnala A4.

### D1 — Il disegno non arriva al bordo

### D3 — Si prende il foglio più piccolo che contiene il disegno
**Il foglio deve contenere anche la legenda**: se il comando risponde «the legend needs … but
its band is … tall», o «the 3 functional bands need … but the drawing area is … wide», il
formato è troppo piccolo — si prende il successivo, non si comprime il disegno.
⚠ **Il vuoto non è un difetto** (**D-170**). Tieni il disegno **stretto** e prendi il foglio
più piccolo che lo contiene; il bianco che resta non si corregge. **Non allargare mai il
disegno per riempire il foglio**, e soprattutto **non allontanare un pezzo dalla macchina che
serve**: A4 vince su questa regola, sempre. Se hai sbagliato formato te lo dice
`SHEET_LARGER_THAN_NEEDED`, e si cambia una riga e si rilancia.

### L'aria-aria — un canalizzato (E1, E2, E3)

Il metodo è lo stesso: prima le autostrade, poi il resto. Le autostrade sono le linee
frigorifere, la mandata al plenum, i rami alle bocchette e il bus ai termostati.

- **Unità esterna e unità interna alla stessa `y`**: le porte frigorifere si allineano e le
  due linee vengono rette. Il **plenum alla `y` dell'unità interna**; le **bocchette in
  colonna**, ognuna alla quota della sua uscita (passo 12,5); la **ripresa sopra l'unità**,
  sull'asse della bocca.
- **La centrale di zona separata dal plenum**, sotto, sull'asse dei motori; i **termostati in
  colonna** accanto, ognuno alla quota della sua porta di bus. Con la centrale attaccata al
  plenum il kit aveva bus a L con sormonti e quattro rilievi bloccanti sulle scritte dei
  termostati.
- **Sotto l'unità interna** il collegamento all'unità esterna, la condensa con sifone e
  scarico **addosso** (A4), il comando a filo; **il quadro sotto l'unità esterna**, con
  l'alimentazione dritta in verticale.

---

### L'elettrico e il comando — una tavola o due (I-227, proposta D-213)

Se il grafo porta cavi o bus — reti del dominio `control`: l'alimentazione dal quadro, i comandi del
regolatore, il bus, le sonde — decidi **prima di comporre** se l'elettrico sta sulla tavola
dell'impianto o su una tavola sua. Il grafo è uno solo: le due tavole escono dallo stesso grafo, con
due piani.

**Due tavole** se vale almeno una di queste:

1. **è una centrale**: il grafo ha un generatore sull'acqua (pompa di calore aria-acqua, caldaia,
   boiler in pompa di calore) oppure un accumulo (volano, accumulo combinato, bollitore);
2. **è densa**: `python3 scripts/mep.py pezzi <grafo> --vista idraulica` elenca **più di 15 pezzi da
   posare**;
3. **la tavola unica non esce**: composta in una vista sola ha un rilievo bloccante o una tratta
   ceduta, e un giro di ricomposizione non li toglie.

**Tavola unica** altrimenti: la sola distribuzione (un collettore con circolatore e miscelatrice, il
suo regolatore e le sue sonde), l'aria-aria con un'unità esterna e un'unità interna.

**Il progettista decide sempre.** Se ha detto «tavola unica» o «tavola a parte per l'elettrico», fai
quello che ha detto, anche contro la regola qui sopra; se la regola ti porta dove lui non ha detto,
dillo nella consegna in una riga («l'elettrico è su una tavola a parte: è una centrale»).

#### Come si scrivono

Il campo **`vista`** del piano dice quale parte del grafo la tavola disegna:

| `vista` | che cosa disegna |
|---|---|
| `"tutto"` (se il campo manca) | il grafo intero: la tavola unica |
| `"idraulica"` | tutto **tranne** i cavi e i bus, e tranne i pezzi che stanno solo sul comando (quadro, interruttore magnetotermico differenziale, sezionatore, relè d'appoggio, termostato ambiente a contatto, regolatore, sonda esterna). La sonda a immersione resta sul suo tubo, senza il cavo |
| `"elettrico"` | i **soli** cavi e bus, e i pezzi che toccano: quadro, interruttore magnetotermico differenziale, sezionatore, relè d'appoggio, termostato ambiente a contatto, regolatore, sonde, e le macchine, i circolatori e le valvole che hanno un cavo. Niente acqua. La tabella in alto a sinistra elenca **ogni pezzo** della tavola con la sua sigla, tranne il sezionatore (I-276) |

Per due tavole scrivi **due piani** sullo stesso grafo completo, `piano-idraulica.json` con
`"vista": "idraulica"` e `piano-elettrico.json` con `"vista": "elettrico"`, e disegna due volte. Il
motore fa il resto:

- il titolo della tavola porta «— idraulica» e «— elettrico e comando», e il numero della tavola
  dell'elettrico è quello del grafo con «-E» (P.04 e P.04-E);
- la legenda di ciascuna rimanda all'altra («Vedi tavola P.04-E «elettrico e comando»»);
- **le sigle sono le stesse** sulle due tavole: sono quelle del grafo intero;
- i file escono con nomi diversi (`…-idraulica-t1.pdf`, `…-elettrico-t1.pdf`).

I pezzi da posare non sono gli stessi nelle due viste: chiedili per ciascuna, con
`mep.py pezzi <grafo> --vista idraulica` e `--vista elettrico`. Sulla tavola dell'elettrico **il
circolatore va nel piano**: non ha il suo tubo, e non sta più in linea. Il sezionatore resta in
linea sul suo cavo, e lo posa il motore. **Il relè d'appoggio va nel piano** anche lui: ha tre
attacchi, e non sta in linea.

**L'interruttore magnetotermico differenziale** (`circuit-breaker-rcbo`, REL-018) sta in linea
sulla linea della macchina, **all'uscita del quadro**: è nel quadro, e la tavola lo disegna
stretto all'uscita da cui la linea parte, prima del cavo. **Non va nel piano**: lo posa il motore,
con la sigla (QF-01) accanto, e sta solo sulla tavola dell'elettrico, in tabella («2P C32 · Idn 30
mA tipo A») e in legenda. La scritta del cavo — «3G6 · L 15 m» — resta sulla linea, sul tratto
verso la macchina. Tu dai al motore una linea su cui stia: se l'uscita del quadro guarda la
macchina con un tratto dritto di almeno **due centimetri** (il segno è largo un centimetro),
l'interruttore ci sta sopra e si legge come l'uscita della linea; se il cavo gira subito, il
motore lo posa sul primo tratto dritto dopo la piega, accanto al quadro. Se c'è anche il
sezionatore (solo se il progettista lo vuole), quello resta accanto alla macchina.

**Il termostato ambiente a contatto** (`room-thermostat-contact`, I-269) sta in linea sul cavo
fra il quadro e il circolatore che accende, come il sezionatore: **non va nel piano**, lo posa il
motore sulla linea, con la sigla (TAC-01) e il nome del locale (`etichetta`) accanto, e sta solo
sulla tavola dell'elettrico. Tu dai al motore una linea su cui stia: il quadro e il circolatore
posati in modo che il cavo fra i due abbia un tratto dritto di almeno **due centimetri** — il
segno è largo un centimetro, e sigla e locale gli stanno sopra e sotto (o ai lati, se il tratto è
verticale). Una linea che dal quadro gira subito sul circolatore lo schiaccia contro la piega:
allontana il circolatore. Se il circolatore ha anche un relè (il caso del §4.8 di Capire in cui
il contatto non basta), il termostato sta sul cavo della bobina, fra il quadro e il relè.

#### Come si compone la tavola dell'elettrico

**Le uscite del quadro e gli ingressi del regolatore si possono scambiare.** Quale `out_n` del
quadro o quale `out_n`/`probe_n` del regolatore usa un cavo non è topologia: il pezzo collegato
resta lo stesso. Se l'uscita scelta in Capire fa incrociare due cavi, cambia l'attacco nel
grafo (solo quello: stessi pezzi, stessa rete), rilancia `completa` e dillo nella consegna in
una riga. `python3 scripts/mep.py pezzi <grafo> --vista elettrico` dice dove sta ogni porta.

È uno schema di collegamento, non la centrale ridisegnata: i pezzi non devono stare dove stanno
sull'idraulica. Quello che conta è che i cavi siano corti e non si incrocino.

- **Il regolatore al centro.** Le sue porte: alimentazione e bus su un fianco, i comandi sull'altro,
  le sonde sotto. Specchialo (`"specchio": true`) se i pezzi che comanda stanno dall'altra parte.
- **Le macchine dal lato dell'alimentazione e del bus del regolatore**, le **valvole e i
  circolatori dal lato dei comandi**: girali (`rotazione`) perché l'attacco del comando guardi il
  regolatore — il cavo è una retta.
- **Il quadro vicino alle macchine che alimenta**, con un'uscita sull'asse dell'alimentazione della
  macchina: il cavo è una verticale, e il sezionatore di prossimità ci sta in mezzo da solo.
- **Le sonde sotto il regolatore**, nell'ordine dei loro ingressi: la più lontana sull'ingresso più
  lontano, così i cavi non si incrociano.
- **Guarda l'ordine delle porte prima di posare.** La pompa di calore ha l'alimentazione a sinistra
  del bus, sotto; il regolatore ha l'alimentazione sopra il bus. Con il quadro sotto la macchina e il
  regolatore accanto, il bus passa sotto il quadro: altrimenti incrocia l'alimentazione.

**Quando regola la pompa di calore** (I-230, proposta) non c'è un regolatore: sonde e comandi
vanno alla macchina, e il centro della tavola è lei. Le sue porte: le **uscite sopra**, da
sinistra `out_acs`, `out_miscelatrice`, `out_pompa_zona_1`, `out_pompa_zona_2`,
`out_pompa_ricircolo`, `out_ausiliario`, a 5 mm; gli **ingressi a sinistra**, dall'alto
`sonda_acs`, `sonda_accumulo`, `sonda_zona_2`, `termostato`; **sotto** alimentazione, bus e
comando a filo. Così (la villetta di `docs/collaudi/REL-015/pdc-regola/`):

- **la pompa di calore al centro**, non specchiata;
- **le uscite a ventaglio**: quelle di sinistra (le valvole) girano a sinistra, quelle di destra
  (i relè dei circolatori) a destra; l'uscita più esterna gira più in basso, la successiva più
  in alto, e i cavi non si incrociano. Le valvole in colonna, girate col comando verso la
  macchina (`"rotazione": 90`): la macchina le comanda con un cavo solo (D-215);
- **i relè d'appoggio in colonna a destra della macchina** (D-228), diritti (`"rotazione": 0`):
  il relè ha la `bobina` a sinistra, verso la macchina, l'ingresso `a` a destra, verso il quadro,
  alla stessa quota della bobina, e l'uscita `b` sopra, un passo a destra del centro. **Il
  circolatore sta sopra il suo relè**, sull'asse di `b`, girato con l'alimentazione in giù
  (`"rotazione": 180`): il cavo è una verticale corta. Fra un relè e il successivo trenta
  millimetri, il posto del circolatore e del cavo del quadro che passa sopra di lui (la
  villetta: relè a x 50, y −25, −55, −85; circolatori a x 52,5, y −40, −70, −100);
- **le sonde in fila sotto, a sinistra della macchina**, diritte (`"rotazione": 0`): la sonda
  dell'ingresso più basso è la più vicina. Lascia fra l'una e l'altra il posto della sigla e
  della scritta (`etichetta`: «bollitore», «volano», «mandata pannelli»): tre sonde uguali senza
  scritta non dicono quale cavo va dove;
- **il quadro in basso a destra, sotto la colonna dei relè.** L'alimentazione della macchina
  esce da sotto il quadro, attraverso l'interruttore QF-01 che il motore stringe all'uscita, ed
  entra da sotto nella macchina. La macchina da un'uscita sotto (`out_5`); i relè dalle uscite sopra e a
  destra — il relè più basso dalla prima (`out_1`), quello sopra dalla seconda (`out_2`), il più
  alto dall'uscita a destra (`out_3`): le linee salgono affiancate a destra della colonna, e la
  più esterna va al relè più alto, così non si incrociano (la villetta: quadro a x 75, y 35);
- **il comando a filo sotto la macchina**, a destra dell'alimentazione, più in alto del cavo che
  va al quadro.

Le uscite e gli ingressi stanno a 5 mm: i cavi che ne escono corrono affiancati a 5 mm per un
tratto, e la regola delle corsie libere (B9) lo segnala. Non è un errore del piano: dillo nella
consegna.

Sulla **tavola unica** l'acqua si compone come sempre, e i cavi vengono dopo: il motore instrada
prima tutta l'acqua e poi i cavi, nello spazio che resta. Metti il regolatore e il quadro **fuori**
dal disegno dell'acqua, dalla parte dei pezzi che comandano.

## 6. Quello che il piano **non può** dire, e come si aggira

**Il piano non può chiedere la forma di una spezzata.** Dice dove stanno i pezzi, e la forma
della linea la sceglie l'instradatore sul costo. «Scendi e fai una curva sola» **non si può
scrivere.**

**Se il piano non si instrada**, il comando dice quale tratta, fra quali due pezzi, e dove il
piano li ha messi. La «posa applicata» che stampa è **nel sistema del piano**, al decimo di
millimetro. Le coppie di numeri fra parentesi nel messaggio dell'instradatore sono **celle
della griglia del foglio**: non cercarle nel piano.

**Il colore di una linea lo decide il grafo**, non il verso in cui corre: un ritorno è blu
anche se va da sinistra a destra. Non spostare un pezzo per far uscire una linea del colore
giusto; se una linea esce del colore sbagliato, è un difetto del motore e va scritto.

**L'unica leva che hai è togliere di mezzo chi occupa la strada.** Prima di appendere un
organo, guarda **quale autostrada deve passare di lì**: se ci metti un gruppo di riempimento
nella colonna sotto l'uscita di una valvola, la linea gira intorno — non perché l'instradatore
sbagli, ma perché **non può passare**. È successo, e spostare quel gruppo di 20 mm ha portato
una linea da 3 pieghe a 1.

---

## 7. Cosa non è tuo, e non lo diventa

- **Non cambi il grafo.** Non aggiungi un pezzo, non ne togli uno, non cambi una tubazione. Se
  ti sembra che ne manchi uno, **lo scrivi come domanda dichiarata** e componi lo stesso.
- **Non inventi contenuto MEP.** Dove va la presa del ricircolo, se una valvola ci vuole: non
  è tuo.
- **Non cambi la convenzione grafica.** Colori, tratteggi, incroci, raggi degli spigoli: sono
  decisi, e non si toccano.
- **Non tari soglie e non inventi numeri.** Se ti viene voglia di scrivere «al massimo N
  colonne verticali», fermati: **quel numero non esiste**, e il criterio è grafico.

---

## 8. Il metodo di lavoro, passo per passo

1. **Leggi il grafo e separa** le macchine dal corredo. Disegna a mente lo **scheletro**: solo
   macchine e collettori.
2. **Trova le catene principali** — quali macchine sono unite a quali, e per quale rete. Quelle
   sono le autostrade.
3. **Scegli le quote.** Per ogni catena, guarda le porte delle macchine agli estremi: se hanno
   le stesse quote relative, **posale allo stesso y** e la catena è retta.
4. **Posa le macchine**, fascia per fascia, da sinistra a destra (A1). Impila i paralleli (A2).
5. **Metti i collettori**: una verticale corta accanto al parallelo, e fra mandata e ritorno
   più vicino alle macchine quello che fa meno sormonti (B3).
6. **Ricontrolla lo scheletro**: ogni catena fra due macchine è retta? Se no, torna al 3.
7. **Solo adesso appendi il corredo**, guardando per ognuno **quale autostrada passa di lì**
   (§6), e tenendo i confini di rete **addosso** al pezzo che servono (A4).
8. **Scrivi le note.** Ogni scelta che hai fatto per una ragione porta il nome della regola.

---

## 9. Prima di consegnare: il controllo finale

Rispondi a queste, e se una risposta è «no» torna indietro:

- [ ] **Ogni pezzo che posi tu ha un'entrata in `pezzi`, e nessun organo in linea ce l'ha?**
- [ ] **Le `x` e le `y` sono multipli di 2,5?**
- [ ] **I raccordi di ogni catena stanno nell'ordine che `pezzi` stampa?**
- [ ] **Le porte che un'autostrada unisce stanno alla stessa quota?** Per pompa, caldaia,
      volano a quattro attacchi e scambiatore vuol dire lo stesso `y`; per chi ha le porte ad
      altre quote no (§2.1). Se no, hai una ragione scritta nelle note?
- [ ] **I paralleli sono impilati alla stessa `x`, con passo costante?**
- [ ] **I due collettori di un parallelo sono su due verticali vicine, nell'ordine che fa
      meno sormonti, e l'hai scritto nelle note?**
- [ ] **Ogni confine di rete sta accanto al pezzo che serve?**
- [ ] **Nessun pezzo di corredo sta nella colonna o nella riga che un'autostrada deve
      percorrere?**
- [ ] **Il foglio è il più piccolo che contiene il disegno?** Il bianco che resta non è un
      difetto (D3).
- [ ] **`rotazione` compare solo dove serve davvero?**
- [ ] **Ogni pezzo spostato per una ragione porta la sua `regola`?**

E l'ultima, che vale più delle altre:

- [ ] **Guarda lo scheletro che hai composto e chiediti: assomiglia a una tavola disegnata da
      un disegnatore?** Se la risposta è no, il piano non è finito — anche se tutte le caselle
      sopra sono spuntate.
