"""Disegnatore MEP deterministic core."""

__version__ = "1.3.0"
