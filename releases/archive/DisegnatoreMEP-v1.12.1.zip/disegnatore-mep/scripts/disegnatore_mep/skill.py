"""Il comando della skill: il lavoro deterministico, in un comando solo (REL-001).

La skill che il progettista lancia in Claude ha tre pezzi fatti da un agente —
Capire, Comporre, Rivedere — e il resto e' questo comando
(`docs/ARCHITETTURA-DEL-PIANO.md` §1):

- `valida` il grafo di prima stesura che Capire scrive, e ne elenca le domande;
- `completa` il grafo con le regole degli accessori, e dice che cosa ha aggiunto e
  perche', e che cosa non ha potuto aggiungere: il progettista approva su questo;
- `disegna` la tavola dal piano che Comporre scrive: la esegue, la misura — il
  preflight e le regole del piano —, e la scrive in SVG, **PDF** e DXF, **con i
  rilievi accanto**, per il progettista. I controlli sono della skill, non della
  sessione che la sviluppa (**I-166**). Con `--tabelle` posa nelle zone del piano le
  tabelle di un file — quello che scrive `distinta` (REL-012);
- `catalogo` stampa le voci fra cui Capire sceglie, una riga per voce, o una voce
  intera; `simbolo` il manifesto di un simbolo; `pezzi` i pezzi che il piano posa;
- `anteprima` fa della tavola un'immagine, per guardarla; `consegna` copia i file
  per il progettista;
- `ambiente` dice che cosa l'ambiente ha e che cosa no.

**Non chiede niente e non decide niente**: dove serve una scelta, la dice. Le
cartelle dei dati — simboli, catalogo, regole, nomi, cartiglio — le riceve da chi
lo lancia: nella skill vengono dalla cartella della skill, dove simboli, catalogo e
regole stanno in un file ciascuno (`FASCI`), nel repository sono quelle del
repository.
"""

import argparse
import hashlib
import importlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zlib
from collections import Counter
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from pydantic import ValidationError

from disegnatore_mep.catalog.registry import ComponentRegistry
from disegnatore_mep.graph.naming import Naming
from disegnatore_mep.graphics.cartiglio import (
    PT_MM,
    Cartiglio,
    CartiglioDellaTavola,
    larghezza_mm,
    rilievi_del_cartiglio,
    valori_del_cartiglio,
)
from disegnatore_mep.graphics.frame import ORDINARY_FRAMES, SheetFrame
from disegnatore_mep.graphics.pdf import per_winansi, scrivi_pdf
from disegnatore_mep.graphics.registry import SymbolRegistry
from disegnatore_mep.graphics.sheet import render_sheet, stati_della_tavola
from disegnatore_mep.graphics.tabella import RIENTRO_MM
from disegnatore_mep.graphics.tabelle import (
    MARGINE_DALLA_ZONA_MM,
    STACCO_FRA_LE_TABELLE_MM,
    posa_le_tabelle,
)
from disegnatore_mep.io.canonical import canonical_json
from disegnatore_mep.io.project_json import load_project
from disegnatore_mep.layout.autostrade import autostrade_in_tavola, tratte_del_progetto
from disegnatore_mep.layout.errors import LayoutError
from disegnatore_mep.layout.geometry import (
    ColonnaDellaTabella,
    RigaDellaTabellaLibera,
    SheetGeometry,
    TabellaNelleZone,
)
from disegnatore_mep.model.project import ConnectionModel, ProjectModel
from disegnatore_mep.model.types import ApprovalStatus, Domain, IssueSeverity
from disegnatore_mep.piano.esecutore import EsitoDelPiano, esegui_piano
from disegnatore_mep.piano.formato import FORMATI_ORDINARI, PianoDiComposizione, carica_piano
from disegnatore_mep.piano.revisore import misura
from disegnatore_mep.piano.vista import VISTE, vista_del_grafo
from disegnatore_mep.rules.apply import saturation
from disegnatore_mep.rules.errors import RuleError
from disegnatore_mep.rules.proposal import RuleProposal
from disegnatore_mep.rules.registry import RuleRegistry
from disegnatore_mep.rules.report import CATEGORY_LABELS, build_report
from disegnatore_mep.validation.issues import ValidationIssue
from disegnatore_mep.validation.regole import rilievi_delle_regole
from disegnatore_mep.validation.topology import validate_project

if TYPE_CHECKING:
    from disegnatore_mep.diametri.riduzioni import RiduzionePosata

GRAVITA: dict[IssueSeverity, str] = {
    IssueSeverity.BLOCKING: "Bloccanti — la tavola non si consegna",
    IssueSeverity.APPROVAL: "Da approvare — il progettista decide",
    IssueSeverity.WARNING: "Avvisi — la tavola si consegna, e si sa",
}

ESTENSIONI_DA_CONSEGNARE = (".pdf", ".dxf", ".md", ".jpg")
"""Quello che il progettista riceve: il PDF, il DXF, i rilievi, il logo del cartiglio, e
il PDF della distinta (REL-015, I-232: niente piu' Excel). L'SVG resta nella cartella di
lavoro (collaudo T2 di REL-012, §1). Il logo no: il DXF lo nomina (`graphics.dxf`), e
aperto senza il logo accanto AutoCAD mostra il riquadro del logo vuoto. La distinta e la
pianta: collaudo T3 di REL-012, §2 punto 8 — prima si copiavano a mano."""


@dataclass(frozen=True)
class Cartelle:
    """Dove stanno i dati che il comando legge."""

    simboli: Path
    catalogo: Path
    regole: Path
    naming: Path
    cartiglio: Path
    """Il modello del cartiglio Nove C, con il logo accanto (REL-002)."""


FASCI = ("simboli", "catalogo", "regole")
"""I dati che legge solo il comando. Nella skill ognuno sta **in un file solo**,
`dati/<nome>.json`: il caricamento su claude.ai accetta al massimo 200 file, e questi
tre da soli ne erano 183 (I-188). Il comando li riapre da se' (`apri_i_fasci`)."""


def fascio_della_cartella(cartella: Path, nome: str) -> str:
    """Una cartella di dati in un file solo, leggibile: ogni JSON come il suo oggetto, ogni
    altro file — i disegni dei simboli — come il suo testo, esatto. Lo scrive la
    costruzione della skill (`scripts/costruisci-skill.py`)."""
    file: dict[str, object] = {}
    for percorso in sorted(cartella.iterdir()):
        if not percorso.is_file():
            raise ValueError(f"{percorso}: un fascio raccoglie solo file, non cartelle")
        testo = percorso.read_text(encoding="utf-8")
        file[percorso.name] = json.loads(testo) if percorso.suffix == ".json" else testo
    return json.dumps({"fascio": nome, "file": file}, ensure_ascii=False, indent=1) + "\n"


def apri_i_fasci(dati: Path) -> Path:
    """I fasci della skill riaperti in una cartella temporanea — una cartella per
    sottocartella del fascio —, una volta sola per contenuto: l'impronta dei fasci e'
    nel nome della cartella. La cartella della skill puo' essere di sola lettura, quella
    temporanea no."""
    fasci = [dati / f"{nome}.json" for nome in FASCI]
    impronta = hashlib.sha256(b"".join(f.read_bytes() for f in fasci)).hexdigest()[:16]
    aperti = Path(tempfile.gettempdir()) / "disegnatore-mep" / f"dati-{impronta}"
    if aperti.is_dir():
        return aperti
    provvisoria = aperti.with_name(f"{aperti.name}.{os.getpid()}")
    shutil.rmtree(provvisoria, ignore_errors=True)
    try:
        for fascio in fasci:
            contenuto = json.loads(fascio.read_text(encoding="utf-8"))
            cartella = provvisoria / contenuto["fascio"]
            cartella.mkdir(parents=True)
            for nome, valore in contenuto["file"].items():
                if Path(nome).name != nome or nome.startswith("."):
                    raise ValueError(f"{fascio}: nome di file non ammesso in un fascio: {nome!r}")
                testo = valore if isinstance(valore, str) else json.dumps(valore, ensure_ascii=False, indent=2) + "\n"
                (cartella / nome).write_text(testo, encoding="utf-8")
    except BaseException:
        shutil.rmtree(provvisoria, ignore_errors=True)
        raise
    try:
        provvisoria.rename(aperti)
    except OSError:
        # Un'altra chiamata l'ha riaperta nello stesso momento: vale la sua, che e' uguale.
        shutil.rmtree(provvisoria, ignore_errors=True)
    return aperti


def cartelle_della_skill(radice: Path) -> Cartelle:
    """Le cartelle dei dati della skill: i fasci riaperti, e i file che stanno da soli."""
    dati = radice / "dati"
    aperti = apri_i_fasci(dati)
    return Cartelle(
        simboli=aperti / "simboli",
        catalogo=aperti / "catalogo",
        regole=aperti / "regole",
        naming=dati / "naming",
        cartiglio=dati / "cartiglio" / "Cartiglio_NoveC_A3.json",
    )


def cartelle_del_repository(radice: Path) -> Cartelle:
    """Le stesse cartelle, dove stanno nel repository."""
    return Cartelle(
        simboli=radice / "assets" / "symbols",
        catalogo=radice / "examples" / "layout" / "catalog",
        regole=radice / "rules" / "hydronic",
        naming=radice / "naming",
        cartiglio=radice / "assets" / "cartigli" / "Cartiglio_NoveC_A3.json",
    )


class _Dati:
    """I dati caricati una volta sola, quando il comando li chiede."""

    def __init__(self, cartelle: Cartelle) -> None:
        self.cartelle = cartelle
        self.simboli = SymbolRegistry.from_directory(cartelle.simboli)
        self.catalogo = ComponentRegistry.from_directory(cartelle.catalogo, symbols=self.simboli)
        self.naming = Naming.from_directory(cartelle.naming)


# --- valida -----------------------------------------------------------------


def _stampa_rilievi(rilievi: Sequence[ValidationIssue]) -> None:
    for gravita, titolo in GRAVITA.items():
        gruppo = [item for item in rilievi if item.severity == gravita]
        if not gruppo:
            continue
        print(f"\n{titolo}")
        for item in gruppo:
            print(f"  - {item.message}")
            print(f"    codice: {item.code} · {', '.join(item.entity_ids)}")


def _domande(modello: ProjectModel) -> list[str]:
    return [
        f"{item.id}: {item.text}"
        for item in modello.assumptions
        if item.status == ApprovalStatus.PROPOSED
    ]


def _valida(args: argparse.Namespace, cartelle: Cartelle) -> int:
    """Il grafo di Capire carica, e regge contro il catalogo? E che cosa chiede?"""
    dati = _Dati(cartelle)
    modello = load_project(args.grafo)
    # Le porte di comando che il grafo collega (REL-012): senza elettrico, nessuna.
    dati.catalogo = dati.catalogo.per_il_progetto(modello)
    esito = validate_project(modello, dati.catalogo)
    print(
        f"Il grafo si legge: {len(modello.components)} pezzi, {len(modello.connections)} "
        f"tubazioni, {len(modello.networks)} reti; regime della centrale: "
        f"{modello.plant_regime.value if modello.plant_regime else 'non dichiarato'}."
    )
    if not esito.ok:
        print("\nIl grafo non regge contro il catalogo: si corregge e si rilancia.")
        _stampa_rilievi(esito.issues)
        return 2
    _stampa_rilievi(esito.issues)
    domande = _domande(modello)
    if domande:
        print(f"\nAssunzioni e domande ancora da confermare ({len(domande)}):")
        for domanda in domande:
            print(f"  - {domanda}")
    else:
        print("\nNessuna assunzione da confermare.")
    return 0


# --- completa ---------------------------------------------------------------


def _completa(args: argparse.Namespace, cartelle: Cartelle) -> int:
    """Le regole degli accessori sul grafo: che cosa aggiungono, e perche'."""
    dati = _Dati(cartelle)
    modello = load_project(args.grafo)
    # Le porte di comando che il grafo collega (REL-012): senza elettrico, nessuna.
    dati.catalogo = dati.catalogo.per_il_progetto(modello)
    esito = validate_project(modello, dati.catalogo)
    if not esito.ok:
        print("Il grafo non regge contro il catalogo: si corregge prima di completarlo.")
        _stampa_rilievi(esito.issues)
        return 2
    regole = RuleRegistry.from_directory(cartelle.regole)
    regole.cross_check(dati.catalogo)
    risultato = saturation(modello, dati.catalogo, regole)
    completo, proposte, lacune = risultato.model, risultato.applied, risultato.gaps
    # La riduzione all'attacco della macchina, dove il tubo scelto dalla velocita' e'
    # piu' piccolo (D-233, I-281): un pezzo vero, subito dopo il giunto antivibrante.
    # Non e' una regola: la posa questo passo, una volta sola anche ai rilanci.
    from disegnatore_mep.diametri.riduzioni import posa_le_riduzioni

    completo, riduzioni = posa_le_riduzioni(completo, dati.catalogo)
    rapporto = build_report(proposte, lacune, dati.naming)
    from disegnatore_mep.diametri.costruttori import avvisi_del_costruttore
    from disegnatore_mep.elettrico.costruttori import avvisi_della_linea, scrivi_i_dati_del_manuale
    from disegnatore_mep.piano.vista import sigle_del_grafo_intero

    # I dati elettrici della linea della pompa di calore che il progettista non ha dato,
    # dal manuale Shenling e dalla specifica Nove C (REL-018, I-278): si scrivono dove
    # mancano, e si dice quello che si e' scritto. Non e' una regola: come la riduzione, li
    # scrive questo passo, a ogni rilancio dal grafo di prima stesura.
    sigle_elettriche = sigle_del_grafo_intero(completo, dati.catalogo, cartelle.naming)
    completo, dati_elettrici_scritti = scrivi_i_dati_del_manuale(completo, dati.catalogo, sigle_elettriche)
    avvisi_del_manuale = avvisi_del_costruttore(completo, dati.catalogo)
    avvisi_del_manuale += avvisi_della_linea(completo, dati.catalogo, sigle_elettriche)

    in_piu = len(completo.components) - len(modello.components)
    print(
        f"Le regole hanno aggiunto {len(proposte)} accessori; con i raccordi e i confini che li "
        f"reggono, il grafo passa da {len(modello.components)} a {len(completo.components)} pezzi "
        f"(+{in_piu})."
    )
    for categoria, etichetta in CATEGORY_LABELS.items():
        voci = rapporto.of(categoria)
        if not voci:
            continue
        print(f"\n{etichetta} ({len(voci)})")
        # Una regola che mette dodici valvole ha una ragione sola: si dice una volta,
        # e sotto i dodici posti. Ripeterla dodici volte non la rende piu' vera.
        # Accanto a ogni posto il nome del pezzo nel grafo completo: e' quello con
        # cui il progettista lo toglie (`accessori_tolti`, I-192).
        della_categoria = [item for item in proposte if item.category == categoria]
        gruppi: dict[tuple[str, str], list[str]] = {}
        for voce, proposta in zip(voci, della_categoria, strict=True):
            gruppi.setdefault((voce.name, voce.rule), []).append(
                f"{voce.where} — {proposta.component_id}"
            )
        for (nome, regola), dove in gruppi.items():
            voce = next(v for v in voci if (v.name, v.rule) == (nome, regola))
            print(f"  - {nome} — {len(dove)} {'pezzo' if len(dove) == 1 else 'pezzi'}")
            for posto in dove:
                print(f"      {posto}")
            print(f"    perche': {voce.rationale}")
            print(f"    fonte: {voce.source} · regola: {regola}")
    if not rapporto.open_points:
        print("\nPunti aperti: nessuno.")
    else:
        # Un accessorio che servirebbe e che non si puo' proporre e' una domanda
        # al progettista: si stampa sempre, anche quando il resto e' a posto.
        print("\nPunti aperti — accessori che servirebbero e che non si possono proporre")
        for punto in rapporto.open_points:
            print(f"  - {punto.name} — {punto.where}")
            print(f"    {punto.what_is_missing}")
            print(f"    perche' servirebbe: {punto.rationale}")
            print(f"    fonte: {punto.source} · regola: {punto.rule}")

    if dati_elettrici_scritti:
        # Un'informazione, come le riduzioni: il dato del progettista vince sempre, e qui
        # si dice solo quello che mancava (REL-018).
        print("\nDati elettrici scritti dal manuale Shenling e dalla specifica Nove C (informazione)")
        for scritto in dati_elettrici_scritti:
            print(f"  - {scritto}")
    if avvisi_del_manuale:
        # Il manuale del costruttore comanda (I-243): si segnala, non si corregge (D-223, D-226).
        print("\nAvvisi del manuale del costruttore e della specifica Nove C")
        for avviso in avvisi_del_manuale:
            print(f"  - {avviso}")
    _stampa_la_prevalenza(completo, dati.catalogo, cartelle)
    _stampa_i_tubi(completo, dati.catalogo, cartelle, riduzioni=riduzioni)

    _stampa_le_scelte_del_progettista(modello, risultato.withheld, proposte, dati)
    _stampa_il_corredo_sull_esistente(completo, proposte)

    verdetto = validate_project(completo, dati.catalogo)
    if not verdetto.ok:
        print("\nIl grafo completato non regge: e' un difetto delle regole, non del grafo.")
        _stampa_rilievi(verdetto.issues)
        return 2
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(canonical_json(completo), encoding="utf-8")
    # Il grafo da leggere accanto non si scrive piu': il progettista non lo leggeva, e
    # approva sull'elenco qui sopra (I-186).
    print(f"\nGrafo completo: {args.out}")
    domande = _domande(completo)
    if domande:
        print(f"\nAssunzioni ancora da confermare ({len(domande)}):")
        for domanda in domande:
            print(f"  - {domanda}")
    return 0


def _stampa_la_prevalenza(modello: ProjectModel, catalogo: ComponentRegistry, cartelle: Cartelle) -> None:
    """La prevalenza della pompa a bordo contro le perdite del giro primario (I-270).

    Un avviso, come quelli del manuale: il DN non cambia, e la scelta resta del
    progettista. Se mancano la prevalenza, le lunghezze o i diametri non si dice niente."""
    from disegnatore_mep.diametri.perdite import avvisi_della_prevalenza
    from disegnatore_mep.piano.vista import sigle_del_grafo_intero

    if modello.diametri is None:
        return
    avvisi = avvisi_della_prevalenza(
        modello, catalogo, sigle=sigle_del_grafo_intero(modello, catalogo, cartelle.naming)
    )
    if avvisi:
        print("\nAvvisi della prevalenza della pompa a bordo")
        for avviso in avvisi:
            print(f"  - {avviso}")


def _stampa_i_tubi(
    modello: ProjectModel,
    catalogo: ComponentRegistry,
    cartelle: Cartelle,
    riduzioni: "Sequence[RiduzionePosata] | None" = None,
) -> None:
    """Il tubo del progettista piu' piccolo di quello del calcolo (I-279): un avviso, la
    tavola scrive il suo. E, in `completa`, le riduzioni agli attacchi delle macchine
    (I-281, D-233): un'informazione, non un avviso — il tubo lo sceglie la velocita', e
    la riduzione e' un pezzo che `completa` posa dopo il giunto."""
    from disegnatore_mep.diametri.tratti import avvisi_dei_tubi
    from disegnatore_mep.piano.vista import sigle_del_grafo_intero

    if modello.diametri is None and not any(item.sezione for item in modello.connections):
        return
    sigle = sigle_del_grafo_intero(modello, catalogo, cartelle.naming)
    avvisi = avvisi_dei_tubi(modello, catalogo, sigle)
    if avvisi:
        print("\nAvvisi dei tubi")
        for avviso in avvisi:
            print(f"  - {avviso}")
    if not riduzioni:
        return
    print("\nRiduzioni agli attacchi delle macchine (informazione)")
    # Una riga per macchina e per coppia di pollici: «riduzione 1¼"×1" aggiunta su
    # mandata e ritorno di GT-01».
    gruppi: dict[tuple[str, str, str, str, bool], list[str]] = {}
    for item in riduzioni:
        porta = item.riduzione.porta
        lato = "mandata" if "supply" in porta else "ritorno" if "return" in porta else porta
        tubo = item.riduzione.tubo
        chiave = (item.riduzione.macchina, item.riduzione.attacco, tubo.pollici, tubo.scritta, item.aggiunta)
        gruppi.setdefault(chiave, []).append(lato)
    for (macchina, attacco, pollici, scritta, aggiunta), lati in gruppi.items():
        come = "aggiunta" if aggiunta else "gia' posata"
        print(
            f"  - riduzione {attacco}×{pollici} {come} su {' e '.join(sorted(lati))} di "
            f"{sigle.get(macchina, macchina)}, subito dopo il giunto antivibrante: attacco {attacco}, "
            f"tubo {scritta}"
        )


def _stampa_le_scelte_del_progettista(
    modello: ProjectModel, tolte: Sequence[RuleProposal], applicate: Sequence[RuleProposal], dati: _Dati
) -> None:
    """Quello che il progettista ha tolto o dichiarato a bordo, detto a ogni rilancio
    (REL-009, I-192): per famiglia, con il motivo; e le sue voci che non hanno effetto."""
    voci = {item.pezzo: item for item in modello.accessori_tolti}
    if voci:
        for titolo, spostate in (
            ("Tolti dal progettista", False),
            ("Spostati dal progettista", True),
        ):
            queste = [item for item in tolte if (voci[item.component_id].altrove is not None) == spostate]
            if not queste:
                continue
            spiegazione = (
                "la regola li posa dove il progettista dice" if spostate
                else "le regole li metterebbero, il grafo non li porta"
            )
            print(f"\n{titolo} ({len(queste)}) — {spiegazione}")
            gruppi: dict[tuple[str, str], list[str]] = {}
            for proposta in queste:
                voce = voci[proposta.component_id]
                posto = (
                    f"su {proposta.anchor.component_id}.{proposta.anchor.port_id}, rete "
                    f"{proposta.network_id} — {proposta.component_id}"
                )
                if voce.altrove is not None:
                    posto += f" → su {voce.altrove}"
                gruppi.setdefault((proposta.name, voce.motivo), []).append(posto)
            for (nome, motivo), dove in gruppi.items():
                print(f"  - {nome} — {len(dove)} {'pezzo' if len(dove) == 1 else 'pezzi'}")
                for posto in dove:
                    print(f"      {posto}")
                print(f"    motivo: {motivo}")
        trovati = {item.component_id for item in tolte}
        a_vuoto = [voce.pezzo for voce in modello.accessori_tolti if voce.pezzo not in trovati]
        if a_vuoto:
            print(
                f"\nAccessori tolti che non tolgono niente ({len(a_vuoto)}) — nessuna regola posa "
                "un pezzo con questo nome: si correggono con il nome che il pezzo ha nel grafo completo"
            )
            for pezzo in a_vuoto:
                print(f"  - {pezzo}")
    # Dove una regola vuole il pezzo anche se la macchina lo porta dentro — la
    # sicurezza di ogni generatore, D-182 —, il bordo dichiarato non basta: si dice,
    # e il progettista sceglie se toglierlo.
    bordo = {item.id: set(item.a_bordo) for item in modello.components if item.a_bordo}
    comunque = sorted(
        (
            item
            for item in applicate
            if bordo.get(item.anchor.component_id, set())
            & set(dati.catalogo.resolve(item.definition_id).definition.functions)
        ),
        key=lambda item: item.component_id,
    )
    if comunque:
        print(
            f"\nDichiarati a bordo, e posati lo stesso ({len(comunque)}) — la regola li vuole anche "
            "dentro la macchina; se sul costruito non ci sono, si tolgono con il loro nome"
        )
        for item in comunque:
            print(
                f"  - {item.name} su {item.anchor.component_id}.{item.anchor.port_id} — "
                f"{item.component_id} · regola: {item.rule_id}@{item.rule_version}"
            )


def _stampa_il_corredo_sull_esistente(completo: ProjectModel, applicate: Sequence[RuleProposal]) -> None:
    """Il corredo che le regole posano su una parte esistente, detto come domanda
    (REL-009, I-195): le regole lo mettono come su un impianto nuovo, e sull'esistente
    il progettista sa se c'e'. Quello che non c'e' si toglie con il suo nome."""
    pezzi = {item.id: item for item in completo.components}
    reti = {item.id: item for item in completo.networks}
    tubo: dict[tuple[str, str], ConnectionModel] = {
        (ref.component_id, ref.port_id): connessione
        for connessione in completo.connections
        for ref in (connessione.endpoint_a, connessione.endpoint_b)
    }

    def sull_esistente(proposta: RuleProposal) -> bool:
        ancora = proposta.anchor
        if (pezzo := pezzi.get(ancora.component_id)) is not None and pezzo.esistente:
            return True
        connessione = tubo.get((ancora.component_id, ancora.port_id))
        return connessione is not None and (
            connessione.esistente or reti[connessione.network_id].esistente
        )

    queste = sorted((item for item in applicate if sull_esistente(item)), key=lambda item: item.component_id)
    if not queste:
        return
    print(
        f"\nSulle parti esistenti ({len(queste)}) — le regole li mettono come su un impianto nuovo: "
        "si chiede al progettista se ci sono, e quelli che non ci sono si tolgono con il loro nome"
    )
    gruppi: dict[str, list[str]] = {}
    for proposta in queste:
        gruppi.setdefault(proposta.name, []).append(
            f"su {proposta.anchor.component_id}.{proposta.anchor.port_id}, rete "
            f"{proposta.network_id} — {proposta.component_id}"
        )
    for nome, dove in gruppi.items():
        print(f"  - {nome} — {len(dove)} {'pezzo' if len(dove) == 1 else 'pezzi'}")
        for posto in dove:
            print(f"      {posto}")


# --- le tabelle del foglio ------------------------------------------------------

FORMATO_DELLE_TABELLE = "disegnatore-mep/tabelle-del-foglio"
"""Il formato del file che `disegna --tabelle` legge: quello che la distinta scrive in
`tabelle-del-foglio.json` (`distinta.uscite.tabelle_del_foglio`), versione 1.

    {"formato": "disegnatore-mep/tabelle-del-foglio", "versione": 1,
     "tabelle": [{"id": "tratte", "titolo": "…",
                  "colonne": [{"titolo": "Tratto", "allinea": "sinistra", "peso": 0.6}, …],
                  "sezioni": [{"titolo": "A. Apparecchiature" o null,
                               "righe": [["T01", "PLZ-01 - B1", …], …]}],
                  "zona": "destra" | "basso",    facoltativa
                  "larghezza_mm": 170}]}         facoltativa

Le celle sono testo gia' scritto: il comando non conta niente. Una sezione col titolo
diventa una riga di sezione («B. Distribuzione aria»), senza titolo le righe e basta.
`peso` e' la larghezza relativa della colonna."""

VERSIONE_DELLE_TABELLE = 1

ZONE_DELLE_TABELLE = ("destra", "basso")


def _squadratura_del_piano(piano: PianoDiComposizione) -> SheetFrame:
    """Il foglio del piano con le sue zone delle tabelle: lo stesso che l'esecutore
    costruisce, per sapere prima di eseguire dove le tabelle stanno."""
    frame = dict(zip(FORMATI_ORDINARI, ORDINARY_FRAMES, strict=True))[piano.formato]
    if piano.zone_tabelle is None:
        return frame
    return frame.con_le_zone(piano.zone_tabelle.destra_mm, piano.zone_tabelle.basso_mm)


@dataclass(frozen=True)
class _TabellaDelFile:
    """Una tabella come il file la da': il contenuto, e quanto ciascuna colonna pesa."""

    nome: str
    titolo: str | None
    pesi: tuple[float, ...]
    colonne: tuple[ColonnaDellaTabella, ...]
    """Con la larghezza ancora da decidere (1 mm): si fissa quando si sa la zona."""
    righe: tuple[RigaDellaTabellaLibera, ...]
    zona: str | None
    larghezza_mm: float | None


def _leggi_le_tabelle(percorso: Path) -> list[_TabellaDelFile]:
    """Le tabelle di un file nel formato `FORMATO_DELLE_TABELLE`. Un file che non e' in
    quel formato e' un errore che dice dove."""
    try:
        dati = json.loads(percorso.read_text(encoding="utf-8"))
    except json.JSONDecodeError as errore:
        raise ValueError(f"il file delle tabelle {percorso} non e' un JSON: {errore}") from errore

    def guasto(dove: str, che_cosa: str) -> ValueError:
        return ValueError(f"il file delle tabelle {percorso}: {dove}{che_cosa}")

    if not isinstance(dati, dict) or dati.get("formato") != FORMATO_DELLE_TABELLE:
        raise guasto("", f"manca \"formato\": \"{FORMATO_DELLE_TABELLE}\" (lo scrive il comando distinta)")
    if dati.get("versione") != VERSIONE_DELLE_TABELLE:
        raise guasto("", f"versione {dati.get('versione')!r}: il comando legge la {VERSIONE_DELLE_TABELLE}")
    tabelle = dati.get("tabelle")
    if not isinstance(tabelle, list):
        raise guasto("", "\"tabelle\" non e' un elenco")
    lette: list[_TabellaDelFile] = []
    for indice, tabella in enumerate(tabelle, start=1):
        if not isinstance(tabella, dict):
            raise guasto(f"la tabella {indice}: ", "non e' un oggetto")
        nome = str(tabella.get("id") or tabella.get("titolo") or indice)
        dove = f"la tabella «{nome}»: "
        colonne = tabella.get("colonne")
        if not isinstance(colonne, list) or not colonne:
            raise guasto(dove, "\"colonne\" manca o e' vuoto")
        pesi: list[float] = []
        lette_colonne: list[ColonnaDellaTabella] = []
        for colonna in colonne:
            peso = colonna.get("peso", 1) if isinstance(colonna, dict) else None
            allinea = colonna.get("allinea", "sinistra") if isinstance(colonna, dict) else None
            if not isinstance(peso, int | float) or isinstance(peso, bool) or peso <= 0:
                raise guasto(dove, f"la colonna {colonna!r} vuole un \"peso\" positivo")
            if allinea not in ("sinistra", "destra"):
                raise guasto(dove, f"la colonna {colonna!r}: \"allinea\" e' \"sinistra\" o \"destra\"")
            pesi.append(float(peso))
            lette_colonne.append(
                ColonnaDellaTabella(
                    intestazione=str(colonna.get("titolo") or ""), larghezza_mm=1.0, a_destra=allinea == "destra"
                )
            )
        righe: list[RigaDellaTabellaLibera] = []
        sezioni = tabella.get("sezioni")
        if not isinstance(sezioni, list):
            raise guasto(dove, "\"sezioni\" non e' un elenco")
        for sezione in sezioni:
            if not isinstance(sezione, dict) or not isinstance(sezione.get("righe", []), list):
                raise guasto(dove, f"la sezione {sezione!r} non ha \"righe\" in elenco")
            if sezione.get("titolo"):
                righe.append(RigaDellaTabellaLibera(sezione=str(sezione["titolo"])))
            for riga in sezione.get("righe", []):
                if not isinstance(riga, list) or len(riga) != len(colonne):
                    raise guasto(dove, f"la riga {riga!r} non ha {len(colonne)} celle, una per colonna")
                righe.append(RigaDellaTabellaLibera(celle=["" if c is None else str(c) for c in riga]))
        zona = tabella.get("zona")
        if zona is not None and zona not in ZONE_DELLE_TABELLE:
            raise guasto(dove, f"\"zona\" e' \"destra\" o \"basso\", non {zona!r}")
        larghezza = tabella.get("larghezza_mm")
        if larghezza is not None and (not isinstance(larghezza, int | float) or larghezza <= 0):
            raise guasto(dove, f"\"larghezza_mm\" e' un numero positivo, non {larghezza!r}")
        titolo = tabella.get("titolo")
        lette.append(
            _TabellaDelFile(
                nome=nome,
                titolo=str(titolo) if titolo else None,
                pesi=tuple(pesi),
                colonne=tuple(lette_colonne),
                righe=tuple(righe),
                zona=zona,
                larghezza_mm=float(larghezza) if larghezza is not None else None,
            )
        )
    return lette


def _parola_piu_larga_mm(testi: Sequence[str], corpo_pt: float, grassetto: bool) -> float:
    return max(
        (larghezza_mm(parola, corpo_pt, grassetto) for testo in testi for parola in per_winansi(testo).split()),
        default=0.0,
    )


def _larghezze_delle_colonne(tabella: _TabellaDelFile, larghezza: float, corpo_pt: float) -> list[float] | None:
    """Le larghezze delle colonne per una tabella larga `larghezza`: ciascuna almeno
    quanto la sua parola piu' lunga — il motore va a capo fra le parole, non dentro —,
    e il resto in proporzione ai pesi. `None` se nemmeno le parole piu' lunghe ci
    stanno."""
    minime = [
        _parola_piu_larga_mm(
            [riga.celle[indice] for riga in tabella.righe if riga.sezione is None], corpo_pt, False
        )
        for indice in range(len(tabella.colonne))
    ]
    minime = [
        max(minima, _parola_piu_larga_mm([colonna.intestazione], corpo_pt, True)) + 2 * RIENTRO_MM + 0.05
        for minima, colonna in zip(minime, tabella.colonne, strict=True)
    ]
    sezioni = [riga.sezione for riga in tabella.righe if riga.sezione is not None]
    if sezioni and max(larghezza_mm(per_winansi(s), corpo_pt, True) for s in sezioni) + 2 * RIENTRO_MM > larghezza:
        return None
    if sum(minime) > larghezza:
        return None
    # Ogni colonna e' larga max(minima, k x peso): si cerca il k che fa la larghezza.
    basso, alto = 0.0, larghezza / min(tabella.pesi)
    for _ in range(60):
        k = (basso + alto) / 2
        if sum(max(m, k * p) for m, p in zip(minime, tabella.pesi, strict=True)) > larghezza:
            alto = k
        else:
            basso = k
    return [int(max(m, basso * p) * 100) / 100 for m, p in zip(minime, tabella.pesi, strict=True)]


def _tabelle_nella_zona(
    frame: SheetFrame, zona: str, tabelle: Sequence[_TabellaDelFile]
) -> tuple[list[TabellaNelleZone], int] | str:
    """Le tabelle di una zona con le colonne a misura, e in quante colonne di zona
    stanno: si prova con una colonna di zona, poi con due, e cosi' via, ognuna larga
    quanto la zona divisa per il loro numero — la zona a destra, solo per le tabelle
    che la chiedono. Se non stanno in nessun modo, il perche'."""
    rettangolo = frame.zona_destra_mm if zona == "destra" else frame.zona_basso_mm
    if rettangolo is None:
        return f"il piano non lascia la zona {zona} (zone_tabelle)"
    corpo_pt = frame.standard.text_small_mm / PT_MM
    utile = rettangolo.width_mm - 2 * MARGINE_DALLA_ZONA_MM
    motivo = "non entra"
    # La zona a destra e' una striscia accanto alla legenda: divisa in colonne strette,
    # le tabelle non si leggono. Si divide solo se il file ce le manda apposta.
    divisibile = zona == "basso" or any(tabella.zona == "destra" for tabella in tabelle)
    for colonne_di_zona in range(1, 10 if divisibile else 2):
        larghezza = (utile - (colonne_di_zona - 1) * STACCO_FRA_LE_TABELLE_MM) / colonne_di_zona
        fatte: list[TabellaNelleZone] = []
        for tabella in tabelle:
            larghezze = _larghezze_delle_colonne(tabella, tabella.larghezza_mm or larghezza, corpo_pt)
            if larghezze is None:
                # Con piu' colonne di zona ogni colonna e' piu' stretta: non c'e' altro da provare.
                return motivo if colonne_di_zona > 1 else (
                    f"«{tabella.nome}» vuole piu' di {tabella.larghezza_mm or larghezza:.0f} mm per le sue parole"
                )
            fatte.append(
                TabellaNelleZone(
                    titolo=tabella.titolo,
                    colonne=[
                        colonna.model_copy(update={"larghezza_mm": misura})
                        for colonna, misura in zip(tabella.colonne, larghezze, strict=True)
                    ],
                    righe=list(tabella.righe),
                    zona="destra" if zona == "destra" else "basso",
                )
            )
        try:
            posa_le_tabelle(SheetGeometry(sheet_id="prova", title="prova"), frame, fatte)
        except LayoutError as errore:
            motivo = str(errore)
            continue
        return fatte, colonne_di_zona
    return motivo


def tabelle_per_le_zone(
    piano: PianoDiComposizione, percorsi: Sequence[Path]
) -> tuple[list[TabellaNelleZone], list[str]]:
    """Le tabelle dei file, pronte per il motore, e una riga per ciascuna che dice dove
    va. Una tabella con la sua `zona` va li'; le altre, nell'ordine dei file, **a
    destra se ci stanno in una colonna, se no in basso**, dove la zona si divide in
    colonne quanto serve. Le colonne della tabella si allargano quanto la zona, o
    quanto una colonna di zona.

    Solleva `LayoutError` se il piano non lascia zone, o se una tabella non entra:
    il testo non si rimpicciolisce, e si allargano le zone o si prende il foglio
    successivo."""
    tabelle = [tabella for percorso in percorsi for tabella in _leggi_le_tabelle(percorso)]
    if not tabelle:
        return [], []
    if piano.zone_tabelle is None:
        raise LayoutError(
            "il piano non lascia zone alle tabelle: scrivi nel piano "
            '"zone_tabelle": {"destra_mm": …, "basso_mm": …} (regole del piano, D4)'
        )
    frame = _squadratura_del_piano(piano)
    nelle_zone: dict[str, list[_TabellaDelFile]] = {"destra": [], "basso": []}
    esito: dict[str, tuple[list[TabellaNelleZone], int]] = {}
    for tabella in tabelle:
        provate = [tabella.zona] if tabella.zona else list(ZONE_DELLE_TABELLE)
        perche: list[str] = []
        for zona in provate:
            prova = _tabelle_nella_zona(frame, zona, [*nelle_zone[zona], tabella])
            if isinstance(prova, str):
                perche.append(f"{'a destra' if zona == 'destra' else 'in basso'}: {prova}")
                continue
            nelle_zone[zona].append(tabella)
            esito[zona] = prova
            break
        else:
            raise LayoutError(
                f"la tabella «{tabella.titolo or tabella.nome}» non entra nelle zone del piano — "
                + "; ".join(perche)
                + ". Allarga le zone (zone_tabelle) o prendi il formato successivo: le scritte "
                "non si rimpiccioliscono"
            )
    pronte: list[TabellaNelleZone] = []
    righe: list[str] = []
    for zona in ZONE_DELLE_TABELLE:
        if zona not in esito:
            continue
        fatte, colonne_di_zona = esito[zona]
        pronte.extend(fatte)
        for tabella, fatta in zip(nelle_zone[zona], fatte, strict=True):
            righe.append(
                f"«{tabella.nome}» {'a destra' if zona == 'destra' else 'in basso'}, larga "
                f"{sum(c.larghezza_mm for c in fatta.colonne):.0f} mm"
                + (f" (la zona in {colonne_di_zona} colonne)" if colonne_di_zona > 1 else "")
            )
    return pronte, righe


# --- disegna ----------------------------------------------------------------


def _rilievi_in_parole(
    titolo: str,
    formato: str,
    tratte: int,
    cedute: int,
    preflight: Sequence[ValidationIssue],
    regole: Sequence[ValidationIssue],
    cartiglio: Sequence[str],
    sostituzioni: Sequence[str],
) -> str:
    """I rilievi della tavola, scritti per il progettista: si consegnano col PDF.

    Una regola del piano che ferma la tavola (B4, REL-016) sta fra i bloccanti, e non
    una seconda volta fra le regole."""
    preflight = [*preflight, *(item for item in regole if item.severity == IssueSeverity.BLOCKING)]
    regole = [item for item in regole if item.severity != IssueSeverity.BLOCKING]
    bloccanti = [item for item in preflight if item.severity == IssueSeverity.BLOCKING]
    righe = [
        f"# Rilievi della tavola — {titolo}",
        "",
        f"Formato **{formato}** · tratte **{tratte}** · tratte cedute **{cedute}** · "
        f"rilievi bloccanti **{len(bloccanti)}**.",
        "",
        # Il file va al progettista (collaudo T3 di REL-012): le frasi fisse con le
        # lettere accentate, non con l'apostrofo; i codici restano in fondo alla riga.
        "Li misurano i controlli della skill sulla tavola finita: il controllo di qualità "
        "e le regole del piano. Non sono un giudizio sull'impianto: dicono com'è "
        "disegnato.",
        "",
    ]
    for gravita, nome in GRAVITA.items():
        gruppo = [item for item in preflight if item.severity == gravita]
        righe += [f"## {nome}", ""]
        righe += [f"- {item.message} (`{item.code}` · {', '.join(item.entity_ids)})" for item in gruppo] or [
            "- nessuno"
        ]
        righe.append("")
    righe += ["## Le regole del piano", ""]
    righe += [f"- {item.message} (`{item.code}` · {', '.join(item.entity_ids)})" for item in regole] or [
        "- nessuna violazione"
    ]
    righe += ["", "## Il cartiglio", ""]
    righe += [f"- {riga}" for riga in cartiglio] or ["- compilato per intero"]
    if sostituzioni:
        righe += ["", "## Caratteri che il PDF non ha", ""]
        righe += [f"- {riga}" for riga in sostituzioni]
    return "\n".join(righe) + "\n"


def _ha_ezdxf() -> bool:
    try:
        importlib.import_module("ezdxf")
    except ImportError:
        return False
    return True


def _capi_delle_tratte(errore: str, esito: EsitoDelPiano, piano: PianoDiComposizione) -> list[str]:
    """Per ogni tratta che il messaggio dell'instradamento nomina, i due pezzi che unisce
    e dove il piano li ha messi: il messaggio dice la tratta, chi compone vuole i pezzi."""
    dove = {item.component_id: item.origin for item in esito.posa}
    righe = []
    for tratta in esito.partizione.trunks:
        if not any(re.search(rf"(?<![\w-]){re.escape(c)}(?![\w-])", errore) for c in tratta.connection_ids):
            continue
        capi = []
        for ref in (tratta.start, tratta.end):
            posto = dove.get(ref.component_id)
            nel_piano = "nel piano" if ref.component_id in piano.pezzi else "posato dal motore"
            capi.append(
                f"{ref.component_id}.{ref.port_id}"
                + (f" ({nel_piano} a {posto.x_mm:g}, {posto.y_mm:g})" if posto else "")
            )
        righe.append(f"la tratta {', '.join(tratta.connection_ids)} va da {capi[0]} a {capi[1]}")
    return righe


def _ingombro_della_posa(esito: EsitoDelPiano) -> tuple[float, float]:
    """Larghezza e altezza della posa, in millimetri: dal primo pezzo all'ultimo."""
    if not esito.posa:
        return 0.0, 0.0
    x0 = min(p.origin.x_mm for p in esito.posa)
    y0 = min(p.origin.y_mm for p in esito.posa)
    x1 = max(p.origin.x_mm + p.width_mm for p in esito.posa)
    y1 = max(p.origin.y_mm + p.height_mm for p in esito.posa)
    return x1 - x0, y1 - y0


def _disegna(args: argparse.Namespace, cartelle: Cartelle) -> int:
    """Esegue il piano, misura la tavola e la scrive, con i rilievi accanto."""
    dati = _Dati(cartelle)
    modello = load_project(args.grafo)
    piano = carica_piano(args.piano)
    cartiglio = Cartiglio.da_file(cartelle.cartiglio)
    # Le tabelle del foglio (REL-012): si sa dove vanno prima di eseguire, cosi' una
    # tabella che non entra ferma il comando prima di scrivere una tavola senza.
    tabelle, dove_vanno = tabelle_per_le_zone(piano, args.tabelle or [])
    esito = esegui_piano(
        modello, piano, dati.catalogo, dati.simboli, cartelle.naming, verifica=args.verifica, tabelle=tabelle
    )
    # La tavola disegna la vista del piano (REL-012, I-227): da qui si legge il suo grafo.
    intero, catalogo_intero = modello, dati.catalogo.per_il_progetto(modello)
    modello, dati.catalogo = esito.modello, esito.catalogo
    if dove_vanno:
        print("Tabelle del foglio:")
        for riga in dove_vanno:
            print(f"  - {riga}")

    if esito.girati:
        print("Girati dalla deduzione:")
        for riga in esito.girati:
            print(f"  - {riga}")
    area = esito.frame.drawing_rect_mm
    larghezza, altezza = _ingombro_della_posa(esito)
    # Chi compone deve sapere quanto posto prende la tabella, per giudicare se una posa
    # piu' stretta le passa sotto o accanto nello stesso formato: la camera Opus di
    # REL-001 e' salita all'A2, e lo stesso disegno stava nell'A3.
    tabelle = [f.tabella for f in esito.disegno.sheets if f.tabella] if esito.disegno else []
    tabella = (
        f" ({tabelle[0].larghezza_mm:g} x {tabelle[0].altezza_mm:g} mm)" if len(tabelle) == 1 else ""
    )
    # Nell'esecutivo anche le note di posa, a destra della tabella (REL-011, D-231).
    note = [f.note_di_posa for f in esito.disegno.sheets if f.note_di_posa] if esito.disegno else []
    if len(note) == 1:
        tabella += (
            f" e le note di posa alla sua destra ({note[0].larghezza_mm:g} x "
            f"{note[0].altezza_mm:g} mm)"
        )
    print(
        f"Area del disegno dell'{piano.formato}: {area.width_mm:g} x {area.height_mm:g} mm, "
        f"con la tabella delle apparecchiature in alto a sinistra{tabella}; la posa ne occupa "
        f"{larghezza:g} x {altezza:g}."
    )
    if esito.disegno is None:
        print(f"\nIl piano non si instrada: {esito.errore}")
        for riga in _capi_delle_tratte(esito.errore or "", esito, piano):
            print(f"  - {riga}")
        if larghezza > area.width_mm or altezza > area.height_mm:
            # Il motore porta il disegno al centro dell'area: se non ci sta, le tratte che
            # escono non trovano strada, e il messaggio accusa una tratta innocente.
            print(
                f"  - Probabile causa: la posa ({larghezza:g} x {altezza:g} mm) non sta nell'area "
                f"dell'{piano.formato} ({area.width_mm:g} x {area.height_mm:g}). Stringi la posa o prendi "
                "il formato successivo, prima di spostare la tratta."
            )
        print("\nPosa applicata (i pezzi del piano sono marcati con *):")
        for posato in sorted(esito.posa, key=lambda i: (i.origin.x_mm, i.origin.y_mm)):
            segno = "*" if posato.component_id in piano.pezzi else " "
            print(
                f"  {segno} {posato.component_id:46} {posato.width_mm:5.1f}x{posato.height_mm:5.1f} "
                f"@({posato.origin.x_mm:6.1f},{posato.origin.y_mm:6.1f})"
            )
        return 2

    regole = rilievi_delle_regole(esito.disegno, esito.frame, dati.catalogo, modello)
    # **Una regola che ferma la tavola** (B4, REL-016) si conta e si stampa coi
    # bloccanti del preflight: chi legge non deve cercarla fra gli avvisi.
    bloccanti = [
        *esito.bloccanti,
        *(item for item in regole if item.severity == IssueSeverity.BLOCKING),
    ]
    _stampa_rilievi([*esito.rilievi, *(item for item in regole if item.severity == IssueSeverity.BLOCKING)])
    regole_avvisi = [item for item in regole if item.severity != IssueSeverity.BLOCKING]
    if regole_avvisi:
        print("\nLe regole del piano")
        for item in regole_avvisi:
            print(f"  - {item.message}")
            print(f"    codice: {item.code} · {', '.join(item.entity_ids)}")
    else:
        print("\nLe regole del piano: nessuna violazione.")
    # La prevalenza si verifica sul grafo intero, e si dice sulla tavola che porta i DN (I-270).
    idrauliche = {item.id for item in modello.networks if item.domain is Domain.HYDRONIC}
    if any(item.network_id in idrauliche for item in modello.connections):
        _stampa_la_prevalenza(intero, catalogo_intero, cartelle)
        _stampa_i_tubi(intero, catalogo_intero, cartelle)

    args.out.mkdir(parents=True, exist_ok=True)
    dxf = not args.senza_dxf and _ha_ezdxf()
    scritti: list[Path] = []
    for foglio in esito.disegno.sheets:
        nome = f"{modello.metadata.project_id}-{foglio.sheet_id}"
        svg = args.out / f"{nome}.svg"
        tavola = CartiglioDellaTavola(cartiglio=cartiglio, valori=valori_del_cartiglio(modello, foglio.sheet_id))
        svg.write_text(render_sheet(foglio, esito.frame, dati.simboli, tavola), encoding="utf-8")
        pdf = scrivi_pdf(svg, titolo=f"{modello.metadata.project_name} — {foglio.sheet_id}")
        scritti += [svg.with_suffix(".pdf"), svg]
        if dxf:
            from disegnatore_mep.graphics.dxf import write_dxf

            scritti += list(write_dxf(foglio, esito.frame, dati.simboli, svg.with_suffix(".dxf"), tavola))
        sul_cartiglio = rilievi_del_cartiglio(tavola, esito.frame, stati_della_tavola(foglio))
        sostituzioni = [
            f"{s.carattere!r} in «{s.scritta}»: nel PDF e' scritto «{s.con}»" for s in pdf.sostituzioni
        ]
        rilievi = args.out / f"{nome}-rilievi.md"
        rilievi.write_text(
            _rilievi_in_parole(
                foglio.title,
                piano.formato,
                len(foglio.routes),
                sum(1 for tratta in foglio.routes if tratta.unresolved),
                esito.rilievi,
                regole,
                sul_cartiglio,
                sostituzioni,
            ),
            encoding="utf-8",
        )
        scritti.append(rilievi)
        for riga in sul_cartiglio:
            print(f"\nCartiglio: {riga}")
        for riga in sostituzioni:
            print(f"\nPDF: {riga}")
    if args.geometria:
        args.geometria.parent.mkdir(parents=True, exist_ok=True)
        args.geometria.write_text(esito.disegno.model_dump_json(indent=2) + "\n", encoding="utf-8")

    print("\nFile scritti:")
    for percorso in scritti:
        print(f"  - {percorso}")
    if not dxf:
        print(
            "  (il DXF non c'e': "
            + ("chiesto senza" if args.senza_dxf else "manca la libreria ezdxf")
            + ")"
        )
    codici = Counter(item.code for item in [*esito.rilievi, *regole])
    punti = misura(esito, [*esito.rilievi, *regole])
    print(
        f"\nFormato {piano.formato} · tratte {sum(len(f.routes) for f in esito.disegno.sheets)} · "
        f"tratte cedute {len(esito.cedute)} · rilievi bloccanti {len(bloccanti)} · "
        f"pieghe {punti.pieghe} · sormonti {punti.incroci} · "
        f"avvisi e regole: {', '.join(f'{c} x{n}' for c, n in sorted(codici.items())) or 'nessuno'}"
    )
    if bloccanti or esito.cedute:
        print("\nLa tavola non si consegna: c'e' un rilievo bloccante o una tratta ceduta (D-063).")
        return 2
    return 0


# --- catalogo, anteprima, ambiente ---------------------------------------------


def _pezzi(args: argparse.Namespace, cartelle: Cartelle) -> int:
    """I pezzi del grafo completo, divisi come li divide Comporre: quelli che il piano posa,
    con ingombro, rotazioni ammesse e porte; e quelli in linea, che posa il motore."""
    dati = _Dati(cartelle)
    modello = load_project(args.grafo)
    # La vista del piano (REL-012, I-227): sulla tavola dell'elettrico un circolatore non
    # ha il suo tubo, e il piano lo posa.
    modello, catalogo = vista_del_grafo(modello, args.vista, dati.catalogo, cartelle.naming)
    da_posare: list[str] = []
    in_linea: list[str] = []
    for pezzo in modello.components:
        voce = catalogo.get(pezzo.definition_id)
        simbolo = catalogo.resolve(pezzo.definition_id).symbol.manifest
        porte = ", ".join(
            f"{p.id} {p.face} ({p.x_mm:g}, {p.y_mm:g})" for p in (*simbolo.ports, *simbolo.control_ports)
        )
        riga = (
            f"{pezzo.id} — {voce.name} · simbolo {simbolo.id} {simbolo.width_mm:g} x "
            f"{simbolo.height_mm:g} · rotazioni {', '.join(str(r) for r in simbolo.allowed_rotations_deg)}"
            f"\n    porte: {porte}"
        )
        (in_linea if simbolo.inline_gap_mm is not None else da_posare).append(riga)
    print(f"Da posare nel piano ({len(da_posare)}):")
    print("\n".join(f"  {r}" for r in da_posare))
    print(f"\nIn linea, li posa il motore sulla loro tratta ({len(in_linea)}): non vanno nel piano.")
    print("\n".join(f"  {r.splitlines()[0]}" for r in in_linea))
    catene, tratte = ordine_lungo_le_tratte(modello, catalogo)
    print(
        "\nIn che ordine stanno lungo le tratte: posa i pezzi del piano in quest'ordine, dal "
        "primo capo all'ultimo. Un raccordo posato fuori ordine fa scavalcare la linea a se' "
        "stessa, e la tavola non esce (RUN_CROSSES_ITSELF)."
    )
    if catene:
        print("  Le catene principali:")
        print("\n".join(f"    {riga}" for riga in catene))
    if tratte:
        print("  Le altre tratte con organi in linea o fra due raccordi:")
        print("\n".join(f"    {riga}" for riga in tratte))
    return 0


def ordine_lungo_le_tratte(modello: ProjectModel, catalogo: ComponentRegistry) -> tuple[list[str], list[str]]:
    """In che ordine i pezzi stanno lungo le tratte del grafo (REL-016, D1).

    Il collaudo della 1.7.0 ha posato i raccordi del ritorno nell'ordine inverso a quello
    della catena, e per saperlo avrebbe dovuto leggere le `connections`: `pezzi` non lo
    diceva. Qui si dice, in due elenchi di righe «pezzo.porta → pezzo → … → pezzo.porta»:

    - **le catene principali**, cioe' le autostrade, intere e nel loro verso: i raccordi
      che toccano e, fra un raccordo e l'altro, gli organi in linea;
    - **le altre tratte** che hanno organi in linea o che uniscono due raccordi: quelle
      dove un ordine c'e' da rispettare. Una tratta fra due pezzi senza niente in mezzo
      non ha ordine da dire.

    Gli organi in linea li posa il motore e portano «(in linea)»: non vanno nel piano, ma
    dicono da che parte sta il raccordo che li segue."""
    in_linea = frozenset(
        item.id for item in modello.components if catalogo.resolve(item.definition_id).is_inline
    )
    raccordi = frozenset(
        item.id for item in modello.components if catalogo.get(item.definition_id).is_a_fitting
    )
    tratte = tratte_del_progetto(modello, catalogo)
    per_chiave = {tratta.connection_ids: tratta for tratta in tratte}

    def organi(nomi: Sequence[str]) -> list[str]:
        return [f"{nome} (in linea)" if nome in in_linea else nome for nome in nomi]

    catene: list[str] = []
    nelle_catene: set[tuple[str, ...]] = set()
    for catena in autostrade_in_tavola(modello, catalogo, tratte):
        primo = catena.passi[0][0]
        pezzi = [f"{primo.component_id}.{primo.port_id}"]
        for chiave, (entrata, uscita) in zip(catena.catene, catena.passi, strict=True):
            tratta = per_chiave[chiave]
            nelle_catene.add(chiave)
            dentro = list(tratta.inline_component_ids)
            if entrata != tratta.start:
                dentro.reverse()
            pezzi += organi(dentro)
            pezzi.append(uscita.component_id)
        ultimo = catena.passi[-1][1]
        pezzi[-1] = f"{ultimo.component_id}.{ultimo.port_id}"
        catene.append(" → ".join(pezzi))
    altre: list[str] = []
    for tratta in tratte:
        if tratta.connection_ids in nelle_catene:
            continue
        fra_raccordi = {tratta.start.component_id, tratta.end.component_id} <= raccordi
        if not tratta.inline_component_ids and not fra_raccordi:
            continue
        altre.append(
            " → ".join(
                [
                    f"{tratta.start.component_id}.{tratta.start.port_id}",
                    *organi(tratta.inline_component_ids),
                    f"{tratta.end.component_id}.{tratta.end.port_id}",
                ]
            )
        )
    return catene, altre


def _riga_del_catalogo(voce: dict[str, object]) -> str:
    """Una voce del catalogo in una riga e mezza: quello su cui Capire sceglie."""
    mestieri = ", ".join(str(m) for m in voce.get("functions", []))  # type: ignore[attr-defined]
    extra = []
    variante = voce.get("variant")
    if isinstance(variante, dict):
        extra.append(f"variante di {variante.get('of')}, se il testo dice: {', '.join(variante.get('named_as', []))}")
    if voce.get("carries_on_board"):
        extra.append("a bordo: " + ", ".join(str(m) for m in voce["carries_on_board"]))  # type: ignore[attr-defined]
    if voce.get("stored_medium"):
        extra.append(f"tiene in serbo: {voce['stored_medium']}")
    if voce.get("fills_from"):
        extra.append(f"si riempie da: {voce['fills_from']}")
    attacchi = []
    for porta in voce.get("ports", []):  # type: ignore[attr-defined]
        segni = [str(porta.get("flow", "?")), str(porta.get("medium", porta.get("domain", "?")))]
        if porta.get("stub"):
            segni.append("di servizio")
        if porta.get("required") is False:
            segni.append("facoltativo")
        attacchi.append(f"{porta['id']} ({', '.join(segni)})")
    righe = f"{voce['id']} — {voce.get('name', '')} · mestieri: {mestieri}"
    if extra:
        righe += " · " + " · ".join(extra)
    return righe + f"\n    attacchi: {', '.join(attacchi)}"


def _voce_intera(cartella: Path, ident: str, che_cosa: str, come_cercarla: str) -> int:
    """Il file intero di una voce — del catalogo o dei simboli —, come lo legge il motore."""
    percorso = cartella / f"{ident}.json"
    if Path(ident).name != ident or not percorso.is_file():
        print(f"Nessun{che_cosa} «{ident}»: {come_cercarla}.")
        return 1
    print(percorso.read_text(encoding="utf-8"), end="")
    return 0


def _simbolo(args: argparse.Namespace, cartelle: Cartelle) -> int:
    """Il manifesto di un simbolo: ingombro, porte con le loro quote, rotazioni ammesse."""
    return _voce_intera(
        cartelle.simboli, args.simbolo, " simbolo",
        "il simbolo di un pezzo e' il campo symbol_id della sua voce, `mep.py catalogo <id>`",
    )


def _catalogo(args: argparse.Namespace, cartelle: Cartelle) -> int:
    """Le voci del catalogo, una riga ciascuna: id, nome, mestieri, attacchi. Con l'id di
    una voce, la voce intera."""
    if args.voce:
        return _voce_intera(
            cartelle.catalogo, args.voce, "a voce del catalogo",
            "le voci si cercano con `mep.py catalogo --cerca <parola>`",
        )
    trovate = 0
    for percorso in sorted(cartelle.catalogo.glob("*.json")):
        voce = json.loads(percorso.read_text(encoding="utf-8"))
        if args.mestiere and args.mestiere not in voce.get("functions", []):
            continue
        if args.cerca and not any(
            args.cerca.lower() in str(campo).lower() for campo in (voce["id"], voce.get("name", ""))
        ):
            continue
        trovate += 1
        print(_riga_del_catalogo(voce))
    if not trovate:
        # Una voce che manca e' un pezzo che non si disegna (Capire, tipo B): dirlo
        # subito evita di sceglierne una che somiglia.
        cercata = " e ".join(f"«{v}»" for v in (args.cerca, args.mestiere) if v)
        print(f"Nessuna voce del catalogo per {cercata}: quel pezzo il catalogo non ce l'ha.")
    return 0


def _png(larghezza: int, altezza: int, righe: Sequence[bytes]) -> bytes:
    """Un PNG a colori da righe RGB, con la sola libreria standard."""

    def blocco(tipo: bytes, dati: bytes) -> bytes:
        corpo = tipo + dati
        return len(dati).to_bytes(4, "big") + corpo + zlib.crc32(corpo).to_bytes(4, "big")

    intestazione = larghezza.to_bytes(4, "big") + altezza.to_bytes(4, "big") + bytes([8, 2, 0, 0, 0])
    grezzo = b"".join(b"\x00" + riga for riga in righe)
    return (
        b"\x89PNG\r\n\x1a\n"
        + blocco(b"IHDR", intestazione)
        + blocco(b"IDAT", zlib.compress(grezzo, 6))
        + blocco(b"IEND", b"")
    )


def anteprima(
    sorgente: Path, destinazione: Path, dpi: int, zona: tuple[float, float, float, float] | None = None
) -> str | None:
    """La tavola come immagine PNG, con quello che l'ambiente ha. Dice con che cosa
    l'ha fatta, o `None` se non ha niente con cui farla.

    `zona` e' un riquadro in millimetri del foglio — da sinistra, dall'alto —: un A2 intero
    a 110 dpi non fa leggere una valvola, un suo pezzo a 300 si'."""
    pdf = sorgente if sorgente.suffix == ".pdf" else sorgente.with_suffix(".pdf")
    if not pdf.exists():
        scrivi_pdf(sorgente, pdf)
    punti = None if zona is None else tuple(v * 72 / 25.4 for v in zona)
    try:
        fitz = importlib.import_module("fitz")
        pagina = fitz.open(pdf)[0]
        ritaglio = fitz.Rect(*punti) if punti else None
        pagina.get_pixmap(dpi=dpi, clip=ritaglio).save(destinazione)
        return "PyMuPDF"
    except ImportError:
        pass
    try:
        pdfium = importlib.import_module("pypdfium2")
        pagina = pdfium.PdfDocument(str(pdf))[0]
        taglio = (0.0, 0.0, 0.0, 0.0)
        if punti:
            larghezza, altezza = pagina.get_size()
            # pypdfium2 vuole quanto togliere da sinistra, sotto, destra e sopra.
            taglio = (punti[0], altezza - punti[3], larghezza - punti[2], punti[1])
        immagine = pagina.render(scale=dpi / 72, rev_byteorder=True, crop=taglio)
        dati = bytes(immagine.buffer)
        passo, riga = immagine.stride, immagine.width * immagine.n_channels
        if immagine.n_channels != 3:
            raise ValueError(f"pypdfium2 ha reso {immagine.n_channels} canali invece di 3")
        destinazione.write_bytes(
            _png(immagine.width, immagine.height,
                 [dati[y * passo : y * passo + riga] for y in range(immagine.height)])
        )
        return "pypdfium2"
    except ImportError:
        pass
    programma = shutil.which("pdftoppm")
    if programma:
        radice = destinazione.with_suffix("")
        riquadro: list[str] = []
        if punti:
            px = [round(v * dpi / 72) for v in punti]
            riquadro = ["-x", str(px[0]), "-y", str(px[1]), "-W", str(px[2] - px[0]), "-H", str(px[3] - px[1])]
        subprocess.run(
            [programma, "-png", "-r", str(dpi), "-singlefile", *riquadro, str(pdf), str(radice)],
            check=True,
            capture_output=True,
        )
        return "pdftoppm"
    return None


def _anteprima(args: argparse.Namespace, cartelle: Cartelle) -> int:
    zona = None
    if args.zona:
        valori = [float(v) for v in args.zona.split(",")]
        if len(valori) != 4 or valori[0] >= valori[2] or valori[1] >= valori[3]:
            raise ValueError(f"--zona vuole x0,y0,x1,y1 in millimetri, con x0 < x1 e y0 < y1: {args.zona}")
        zona = (valori[0], valori[1], valori[2], valori[3])
    destinazione = args.out or args.tavola.with_suffix(".png" if zona is None else ".zona.png")
    con = anteprima(args.tavola, destinazione, args.dpi, zona)
    if con is None:
        print(
            "Nessun programma per fare della tavola un'immagine (ne' PyMuPDF, ne' "
            "pypdfium2, ne' pdftoppm): la tavola si guarda nel PDF."
        )
        return 1
    print(f"Anteprima: {destinazione} (con {con}, {args.dpi} dpi)")
    return 0


def _ambiente(args: argparse.Namespace, cartelle: Cartelle) -> int:
    import pydantic

    print(f"Python {sys.version.split()[0]} · pydantic {pydantic.VERSION}")
    print(f"Motore: {Path(__file__).resolve().parent}")
    print(f"DXF: {'si' if _ha_ezdxf() else 'no, manca ezdxf: la tavola esce in PDF e SVG'}")
    rasterizzatori = [
        nome for nome in ("fitz", "pypdfium2") if importlib.util.find_spec(nome) is not None
    ] + (["pdftoppm"] if shutil.which("pdftoppm") else [])
    print(
        "Anteprima PNG: "
        + (", ".join(rasterizzatori) if rasterizzatori else "no — manca un lettore di PDF (pypdfium2 o PyMuPDF)")
    )
    dati = _Dati(cartelle)
    regole = RuleRegistry.from_directory(cartelle.regole)
    print(
        f"Dati: {len(dati.simboli.all())} simboli, "
        f"{len(list(cartelle.catalogo.glob('*.json')))} voci di catalogo, "
        f"{len(regole.all())} regole, cartiglio "
        f"{'si' if cartelle.cartiglio.exists() else 'NO'}"
    )
    print("Pronto.")
    return 0


def consegna(cartelle: Path | Sequence[Path], destinazione: Path) -> list[Path]:
    """Copia nella cartella di consegna i file per il progettista da una o piu'
    cartelle — la tavola dello schema, la distinta, la pianta —: PDF, DXF, rilievi,
    l'Excel della distinta e il logo che il DXF nomina (`ESTENSIONI_DA_CONSEGNARE`);
    non l'SVG.

    Lo stesso nome in due cartelle va bene se il file e' lo stesso (il logo, accanto
    a ogni DXF); due file diversi con lo stesso nome fermano la consegna prima di
    copiare, perche' uno coprirebbe l'altro."""
    elenco = [cartelle] if isinstance(cartelle, Path) else list(cartelle)
    scelti: dict[str, Path] = {}
    for cartella in elenco:
        if not cartella.is_dir():
            raise OSError(f"{cartella}: la cartella da consegnare non c'e'")
        for percorso in sorted(cartella.iterdir()):
            if not (percorso.is_file() and percorso.suffix in ESTENSIONI_DA_CONSEGNARE):
                continue
            gia = scelti.get(percorso.name)
            if gia is not None and gia.read_bytes() != percorso.read_bytes():
                raise ValueError(
                    f"{percorso.name} c'e' in {gia.parent} e in {percorso.parent}, ed e' diverso: "
                    "uno coprirebbe l'altro. Rinomina una delle due tavole."
                )
            scelti.setdefault(percorso.name, percorso)
    destinazione.mkdir(parents=True, exist_ok=True)
    return [Path(shutil.copy2(percorso, destinazione / nome)) for nome, percorso in scelti.items()]


def _consegna(args: argparse.Namespace, cartelle: Cartelle) -> int:
    for percorso in consegna(args.cartelle, args.destinazione):
        print(f"Consegnato: {percorso}")
    return 0


def _pianta(args: argparse.Namespace, cartelle: Cartelle) -> int:
    from disegnatore_mep.pianta.comando import esegui

    return esegui(args.pianta, args.out, cartelle.cartiglio, not args.senza_dxf, distinta=args.distinta,
                  grafo=args.grafo, catalogo=cartelle.catalogo, nomi=cartelle.naming)


# --- il comando ---------------------------------------------------------------


def costruisci_il_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mep.py", description="Il comando della skill Disegnatore MEP."
    )
    comandi = parser.add_subparsers(dest="comando", required=True)

    comandi.add_parser("ambiente", help="che cosa l'ambiente ha, e se il comando e' pronto")

    catalogo = comandi.add_parser("catalogo", help="le voci del catalogo, una riga ciascuna; con un id, la voce intera")
    catalogo.add_argument("voce", nargs="?", help="l'id di una voce: la stampa intera")
    catalogo.add_argument("--mestiere", help="solo le voci che fanno questo mestiere")
    catalogo.add_argument("--cerca", help="solo le voci con questa parola nell'id o nel nome")

    simbolo = comandi.add_parser("simbolo", help="il manifesto di un simbolo: ingombro, porte, rotazioni")
    simbolo.add_argument("simbolo", help="l'id del simbolo (il symbol_id della voce di catalogo)")

    pezzi = comandi.add_parser("pezzi", help="i pezzi da posare nel piano, e quelli che posa il motore")
    pezzi.add_argument("grafo", type=Path, help="il grafo completo")
    pezzi.add_argument(
        "--vista",
        choices=VISTE,
        default="tutto",
        help="la vista del piano: tutto (la tavola unica), idraulica, elettrico (REL-012)",
    )

    valida = comandi.add_parser("valida", help="il grafo di Capire carica e regge?")
    valida.add_argument("grafo", type=Path)

    completa = comandi.add_parser("completa", help="le regole degli accessori sul grafo")
    completa.add_argument("grafo", type=Path)
    completa.add_argument("--out", type=Path, required=True, help="il grafo completo")

    disegna = comandi.add_parser("disegna", help="esegue il piano: tavola, PDF, DXF e rilievi")
    disegna.add_argument("grafo", type=Path, help="il grafo completo")
    disegna.add_argument("--piano", type=Path, required=True)
    disegna.add_argument("--out", type=Path, required=True, help="la cartella della tavola")
    disegna.add_argument("--geometria", type=Path, help="scrive anche la geometria, per le misure")
    disegna.add_argument(
        "--verifica",
        action="store_true",
        help="stampa accanto a ogni pezzo il suo indirizzo (D-110): per guardare, non per consegnare",
    )
    disegna.add_argument("--senza-dxf", action="store_true", help="non scrive il DXF")
    disegna.add_argument(
        "--tabelle",
        type=Path,
        action="append",
        help="un file di tabelle da posare nelle zone del piano (zone_tabelle): quello che "
        "scrive il comando distinta, tabelle-del-foglio.json; si puo' ripetere",
    )

    vista = comandi.add_parser("anteprima", help="la tavola come immagine PNG")
    vista.add_argument("tavola", type=Path, help="il PDF o l'SVG della tavola")
    vista.add_argument("--out", type=Path)
    vista.add_argument("--dpi", type=int, default=110)
    vista.add_argument(
        "--zona", help="solo un riquadro del foglio, x0,y0,x1,y1 in millimetri dall'alto a sinistra"
    )

    pianta = comandi.add_parser("pianta", help="la pianta dei posizionamenti e dei tracciati (M.03)")
    pianta.add_argument("pianta", type=Path, help="il JSON della pianta")
    pianta.add_argument("--out", type=Path, required=True, help="la cartella della tavola")
    pianta.add_argument("--senza-dxf", action="store_true", help="non scrive il DXF")
    pianta.add_argument(
        "--distinta", type=Path,
        help="il distinta.json del comando distinta: controlla numeri di tratta, capi e lunghezze, e da' la "
        "lunghezza ai tracciati che non l'hanno",
    )
    pianta.add_argument(
        "--grafo", type=Path, help="il grafo completo: controlla sigle, tubazioni e lunghezze dei tracciati"
    )

    finale = comandi.add_parser(
        "consegna",
        help="copia PDF, DXF, rilievi e il documento della distinta, da una o piu' cartelle, nella cartella data",
    )
    finale.add_argument(
        "cartelle", type=Path, nargs="+", help="la tavola, e se ci sono la distinta e la pianta"
    )
    finale.add_argument("destinazione", type=Path)

    distinta = comandi.add_parser(
        "distinta", help="la distinta materiali per l'installatore (proposta D-213): solo se il progettista la chiede"
    )
    distinta.add_argument("grafo", type=Path, help="il grafo completo, con lunghezze e sezioni sui tratti")
    distinta.add_argument("--out", type=Path, help="la cartella della distinta (non serve con --domande)")
    distinta.add_argument(
        "--domande",
        action="store_true",
        help="non scrive niente: dice in parole i dati da chiedere al progettista perche' nessuna voce esca DA "
        "DEFINIRE, da chiedere insieme alle domande del disegno",
    )
    distinta.add_argument(
        "--report",
        type=Path,
        help="la cartella della skill dei report Nove C (nove-c-report), installata accanto: con lei la distinta "
        "e' un PDF; senza, lo stesso contenuto in Markdown",
    )
    distinta.add_argument("--regole", type=Path, help="le regole della distinta: una cartella o un fascio")
    distinta.add_argument(
        "--sul-foglio",
        help="le tabelle di tabelle-del-foglio.json, fra tratte,computo,attivita,note (di default tutte); il flusso "
        "della skill non le posa sulla tavola",
    )
    distinta.add_argument(
        "--lista",
        action="store_true",
        help="la lista della spesa per l'installatore: stessi calcoli, solo i materiali da comprare, senza "
        "l'offerta a corpo (I-262)",
    )
    distinta.add_argument(
        "--fornitura",
        help="chi fornisce che cosa in questa offerta, es. apparecchiature=installatore; «confermata» per le "
        "predefinite; senza, le predefinite da confermare",
    )
    vaso = comandi.add_parser(
        "vaso",
        help="dimensiona il vaso d'espansione sul grafo completo e lo scrive in tabella (D-220); nell'esecutivo "
        "anche precarica, taratura della sicurezza e pressione di carica",
    )
    vaso.add_argument("grafo", type=Path, help="il grafo completo (dopo completa)")
    vaso.add_argument("--contenuto", type=float, required=True, help="litri d'acqua che il vaso vede: tutto il circuito")
    vaso.add_argument("--tmax", type=float, required=True, help="temperatura massima di mandata, °C")
    vaso.add_argument("--dislivello", type=float, required=True, help="metri dal vaso al punto piu' alto dell'impianto")
    vaso.add_argument("--taratura", type=float, default=3.0, help="taratura della valvola di sicurezza, bar (3)")
    vaso.add_argument("--pressione-minima", type=float, help="minima di esercizio del generatore, bar (Shenling 1,5)")
    vaso.add_argument("--riempimento", type=float, help="pressione di riempimento del costruttore, bar (Shenling 2,0)")
    vaso.add_argument("--coefficiente", type=float, help="coefficiente d'espansione della miscela, con il glicole")
    vaso.add_argument("--stimato", action="store_true", help="il contenuto e' una stima, non un dato")
    vaso.add_argument("--vaso", help="l'id del vaso, se il grafo ne ha piu' d'uno")
    vaso.add_argument("--out", type=Path, help="dove scrivere il grafo (di default lo stesso file)")
    return parser


def _vaso(args: argparse.Namespace, cartelle: Cartelle) -> int:
    from disegnatore_mep.vaso.comando import esegui as esegui_il_vaso

    dati = _Dati(cartelle)
    return esegui_il_vaso(
        args.grafo,
        args.out,
        dati.catalogo,
        contenuto_l=args.contenuto,
        temperatura_massima_c=args.tmax,
        dislivello_m=args.dislivello,
        vaso_id=args.vaso,
        taratura_bar=args.taratura,
        pressione_minima_bar=args.pressione_minima,
        riempimento_bar=args.riempimento,
        coefficiente=args.coefficiente,
        stimato=args.stimato,
    )


def _distinta(args: argparse.Namespace, cartelle: Cartelle) -> int:
    # REL-013, proposta D-213: un modulo a parte, che nessun altro comando chiama.
    from disegnatore_mep.distinta.comando import domande, esegui

    if args.domande:
        return domande(
            args.grafo, args.regole, cartelle.regole, cartelle.catalogo, cartelle.naming, fornitura=args.fornitura,
            cartella_dei_simboli=cartelle.simboli,
        )
    if args.out is None:
        raise ValueError("distinta: serve --out <cartella> (o --domande, che non scrive niente)")
    return esegui(
        args.grafo,
        args.out,
        args.regole,
        cartelle.regole,
        cartelle.catalogo,
        cartelle.naming,
        sul_foglio=args.sul_foglio,
        fornitura=args.fornitura,
        report=args.report,
        lista=args.lista,
        cartella_dei_simboli=cartelle.simboli,
    )


def main(argv: Sequence[str] | None, cartelle: Cartelle) -> int:
    """Codici di uscita: `0` fatto, `2` fatto ma c'e' qualcosa che ferma la consegna,
    `1` non si e' potuto fare — un file che non si legge, un dato che manca."""
    args = costruisci_il_parser().parse_args(argv)
    try:
        comando: dict[str, Callable[[argparse.Namespace, Cartelle], int]] = {
            "ambiente": _ambiente,
            "completa": _completa,
            "catalogo": _catalogo,
            "simbolo": _simbolo,
            "pezzi": _pezzi,
            "valida": _valida,
            "disegna": _disegna,
            "anteprima": _anteprima,
            "consegna": _consegna,
            "distinta": _distinta,
            "vaso": _vaso,
            "pianta": _pianta,
        }
        return comando[args.comando](args, cartelle)
    except (OSError, ValidationError, ValueError, RuleError) as errore:
        print(f"Errore: {errore}", file=sys.stderr)
        return 1
