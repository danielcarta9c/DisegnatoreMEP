"""Dal grafo completo alla distinta materiali (REL-013, proposta D-213).

La distinta **non progetta**: lunghezze, sezioni, portate, protezioni, marca e modello
sono dati del progettista, scritti nel grafo. La distinta li **maggiora** e ne
**conta il corredo** con le regole di `rules/distinta/`, e ogni quantita' esce con
la regola che l'ha prodotta, la sua fonte, il suo perche' e il conto fatto. Dove un
dato manca la voce esce **DA DEFINIRE**, con la domanda: mai un numero inventato.

L'ordine: le apparecchiature (A); per ogni fluido, le voci a metro e a giunzione sui
suoi tratti; per ogni pezzo, il suo corredo di posa; le voci di catalogo e i fluidi
senza regola (X, DA DEFINIRE); le attivita' a corpo, le opere del committente e le
varianti. Poi la verifica dell'aria, che **segnala e non corregge**.
"""

import math
import re
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from .confezioni import in_confezioni
from .grafo import (
    Impianto,
    Pezzo,
    Tratta,
    TubiDelloSchema,
    con_i_tubi,
    leggi_impianto,
    numero,
    tratte_dell_impianto,
)
from .lunghezze import Minimo, da_quotare, in_parole, per_eccesso, quante_volte
from .regole import Fornitura, RegoleDellaDistinta, la_fornitura

DA_DEFINIRE = "DA DEFINIRE"

SEGNAPOSTO = re.compile(r"\{([a-z_]+(?:\.[a-z0-9_-]+)?)\}")

UNA_DELLE_MACCHINE = "una delle macchine della linea frigorifera"

DATI_DI_MACCHINA = ("precarica_fino_a_m", "carica_aggiuntiva_g_m", "refrigerante")
"""I dati della scheda della macchina che la riserva di refrigerante legge."""

CALCOLI_CON_LA_LUNGHEZZA = frozenset(
    {"lunghezza", "confezioni", "passo", "per_metro", "metri_arrotondati", "carica_refrigerante"}
)


MARCA_E_MODELLO = "marca e modello"

DATI_DEL_TUBO = ("pollice", "sezione")

FLUIDI_D_ACQUA = frozenset({"heating_water", "cold_water", "domestic_hot_water", "solar_fluid"})
"""I fluidi che corrono nei tubi d'acqua (REL-020)."""
"""I dati di un pezzo in linea sull'acqua che vengono dal tubo, non dal pezzo (REL-020)."""

PEZZO = "pezzo"
TRATTO = "tratto"
REGOLE = "regole"
IMPIANTO = "impianto"
"""Un dato dell'impianto, che il progettista dice nella chat e l'agente scrive nel blocco
`distinta` del grafo (REL-022)."""


@dataclass(frozen=True)
class Mancante:
    """Un dato che manca alla distinta, detto in modo che lo si possa chiedere al
    progettista **prima** del primo lancio (REL-016, D4): quale dato (`dato`, il campo
    del grafo; «marca e modello» per i due insieme), su che cosa (`su`: un pezzo, un
    tratto, o le regole della distinta, che il progettista non sa) e di chi (`chi`, la
    sigla del pezzo o il numero del tratto; `di`, il suo nome in parole).

    Nasce **nello stesso punto** in cui nasce la domanda della voce DA DEFINIRE: le
    domande di `mep.py distinta --domande` e le voci DA DEFINIRE del documento vengono
    dalla stessa fonte, e non possono divergere."""

    dato: str
    su: str
    chi: str
    di: str


@dataclass
class Voce:
    """Una riga della distinta."""

    sezione: str
    testo: str
    um: str
    quantita: float | None
    """`None`: DA DEFINIRE, o una variante che ha solo il prezzo unitario."""
    fornitura: str
    regola: str
    """Da quale regola viene: `fluidi/<fluido>/<voce>`, `corredo/<voce di catalogo>/<voce>`, …"""
    fonte: str
    perche: str
    calcolo: str
    note: str = ""
    da_definire: bool = False
    domande: list[str] = field(default_factory=list)
    rif: str = ""
    contributi: list[tuple[str, float]] = field(default_factory=list, repr=False)
    mancanti: list[Mancante] = field(default_factory=list, repr=False)
    """I dati che mancano a questa voce, uno per domanda (`Mancante`)."""
    prezzo: "PrezzoDellaVoce | None" = field(default=None, repr=False)
    """Con quali codici del listino della minuteria si prezza (REL-021); `None`: la
    regola non lo dice."""


@dataclass(frozen=True)
class PrezzoDellaVoce:
    """I codici del listino di una voce, scelti sui suoi dati (REL-021): per ogni
    unita' della voce, `n` unita' di ciascun codice. `manca` dice perche' un codice
    non c'e' (il dato che serve, o nessuna scelta che vale): la voce e' DA PREZZARE."""

    codici: tuple[tuple[str, float], ...]
    manca: str = ""
    nota: str = ""


def prezzo_della_voce(regola: Mapping[str, Any], valori: Mapping[str, Any]) -> PrezzoDellaVoce | None:
    """I codici del listino della regola `regola` (il suo campo `prezzo`) sui dati
    `valori`: un codice fisso, o la scelta per il valore di un dato (`per`), con la
    prima espressione (`se`) che vale. Senza `prezzo` nella regola, `None`; con un
    `prezzo` vuoto, DA PREZZARE (la voce non e' nel listino)."""
    componenti = regola.get("prezzo")
    if componenti is None:
        return None
    nota = str(regola.get("prezzo_nota") or "")
    if not componenti:
        return PrezzoDellaVoce((), "non e' nel listino", nota)
    codici: list[tuple[str, float]] = []
    for componente in componenti:
        n = float(componente.get("n", 1))
        if "codice" in componente:
            codici.append((str(componente["codice"]), n))
            continue
        per = str(componente["per"])
        if "{" in per:
            # Piu' dati insieme: «{poli} {curva}{in_a} {tipo_differenziale}» → «2P C32 B».
            testo, mancanti = riempi(per, valori)
            if mancanti:
                return PrezzoDellaVoce((), f"manca il dato «{mancanti[0]}»", nota)
        else:
            valore = valori.get(per)
            if valore in (None, ""):
                return PrezzoDellaVoce((), f"manca il dato «{per}»", nota)
            testo = in_parole(valore) if isinstance(valore, float) else str(valore)
        scelte = componente.get("scegli", [])
        if scelte and all("almeno" in s for s in scelte):
            # La taglia commerciale non minore del valore (il vaso da 24 l → quello da 25).
            misura = numero(testo)
            adatte = sorted((float(s["almeno"]), str(s["codice"])) for s in scelte if misura is not None and float(s["almeno"]) >= misura)
            scelto = adatte[0][1] if adatte else None
        else:
            scelto = next((str(s["codice"]) for s in scelte if re.search(str(s["se"]), testo)), None)
        if scelto is None:
            return PrezzoDellaVoce((), f"nessuna voce del listino per {per} «{testo}»", nota)
        codici.append((scelto, n))
    return PrezzoDellaVoce(tuple(codici), "", nota)


@dataclass(frozen=True)
class EsitoDellaVerifica:
    dove: str
    controllo: str
    valore: str
    soglia: str
    esito: str
    """«entro», «oltre», «da rispettare», «non verificabile»."""
    fonte: str
    misura: float | None = None
    """Il numero misurato (la velocita' in m/s), quando c'e'."""


@dataclass
class Distinta:
    progetto: Mapping[str, Any]
    regole: RegoleDellaDistinta
    voci: list[Voce]
    tratte: list[Tratta]
    sigle: Mapping[str, str]
    nomi_dei_fluidi: Mapping[str, str]
    verifica: list[EsitoDellaVerifica]
    avvisi: list[str]
    note: list[str]
    domande_dei_tratti: list[str]
    da_confermare: list[str] = field(default_factory=list)
    """Le scelte che la distinta prende dalle regole predefinite e che il progettista
    conferma per questa offerta (la fornitura): non sono DA DEFINIRE — le quantita'
    ci sono —, ma non sono fatti."""
    fornitura: str = ""
    """Chi fornisce che cosa in questa offerta, in una frase: confermata dal progettista,
    o le predefinite «da confermare» (`Fornitura.in_parole`). La dice il PDF fra le
    avvertenze, confermata o no."""
    mancanti_dei_tratti: list[Mancante] = field(default_factory=list)
    """Le lunghezze dei tratti che mancano (le `domande_dei_tratti`, come dati)."""
    mancanti_della_verifica: list[Mancante] = field(default_factory=list)
    """I dati senza i quali una verifica non si fa (la portata, la lunghezza massima
    della linea frigorifera): non fanno voci DA DEFINIRE, ma la verifica resta muta."""

    def voci_della_sezione(self, lettera: str) -> list[Voce]:
        return [voce for voce in self.voci if voce.sezione == lettera]

    @property
    def mancanti(self) -> list[Mancante]:
        """I dati che mancano alle voci DA DEFINIRE e ai tratti, senza ripetizioni,
        nell'ordine in cui la distinta li incontra."""
        tutti: list[Mancante] = []
        for mancante in [*self.mancanti_dei_tratti, *(m for v in self.voci for m in v.mancanti)]:
            if mancante not in tutti:
                tutti.append(mancante)
        return tutti

    @property
    def domande(self) -> list[str]:
        tutte: list[str] = []
        for domanda in [*self.domande_dei_tratti, *(d for v in self.voci for d in v.domande)]:
            if domanda not in tutte:
                tutte.append(domanda)
        return tutte

    @property
    def da_definire(self) -> list[Voce]:
        return [voce for voce in self.voci if voce.da_definire]

    @property
    def tratte_in_tabella(self) -> list[Tratta]:
        # REL-022: le linee d'acqua si comprano a metri per rete, non per tratto del disegno.
        return [tratta for tratta in self.tratte if tratta.num and tratta.fluido not in FLUIDI_D_ACQUA]

    def da_a(self, tratta: Tratta) -> str:
        return " - ".join(self.sigle.get(p, p) for p in tratta.pezzi)

    def materiale(self, tratta: Tratta) -> str:
        return materiale_della_tratta(tratta, self.regole.fluidi.get(tratta.fluido, {}))


def materiale_della_tratta(tratta: Tratta, regola_del_fluido: Mapping[str, Any]) -> str:
    """Il materiale che la tabella delle tratte scrive: quello dato sul tratto; per un
    **raccordo diretto** quello che il fluido dice per il raccordo diretto
    (`materiale_del_raccordo_diretto`), se lo dice; se no quello del fluido.

    La ripresa montata sulla bocca della macchina (lunghezza 0) e' il plenum di ripresa
    del corredo: la tabella la chiamava «canale di ripresa», l'Excel «plenum di ripresa»
    (collaudo T3 di REL-012). Un nome solo, quello del corredo."""
    dato = tratta.dato("materiale")
    if dato:
        return str(dato)
    if tratta.diretta and regola_del_fluido.get("materiale_del_raccordo_diretto"):
        return str(regola_del_fluido["materiale_del_raccordo_diretto"])
    return str(regola_del_fluido.get("materiale") or "")


def riempi(testo: str, valori: Mapping[str, Any]) -> tuple[str, list[str]]:
    """Il testo con i dati al posto dei segnaposto; quelli che mancano diventano
    «DA DEFINIRE (nome)», e tornano nell'elenco."""
    mancanti: list[str] = []

    def sostituisci(trovato: re.Match[str]) -> str:
        nome = trovato.group(1)
        valore = valori.get(nome)
        if valore is None or valore == "":
            mancanti.append(nome)
            return f"{DA_DEFINIRE} ({nome})"
        if isinstance(valore, float):
            return in_parole(valore)
        return str(valore)

    return SEGNAPOSTO.sub(sostituisci, testo), mancanti


def _unici(valori: Iterable[str | None]) -> list[str]:
    visti: list[str] = []
    for valore in valori:
        if valore and valore not in visti:
            visti.append(valore)
    return visti


def _nome_del_tratto(distinta_parziale: "_Lavoro", tratta: Tratta) -> str:
    chi = f"{tratta.num} " if tratta.num else ""
    return f"{chi}({tratta.rete.nome}: {distinta_parziale.da_a(tratta)})"


def _in_parole_le_tubazioni(impianto: Impianto, tratta: Tratta, idents: Sequence[str]) -> str:
    """Le tubazioni di un tratto dette coi loro capi, non coi loro id."""
    return ", ".join(impianto.tubazione_in_parole(t) for t in tratta.tubazioni if t.id in idents)


@dataclass
class _Lavoro:
    """Lo stato mentre la distinta si compone."""

    impianto: Impianto
    regole: RegoleDellaDistinta
    tratte: list[Tratta]
    nomi_del_catalogo: Mapping[str, str]
    nomi_dei_fluidi: Mapping[str, str]
    fornitura: Fornitura
    pollici: Mapping[str, str] = field(default_factory=dict)
    """Il pollice degli accessori in linea sull'acqua (I-279)."""
    dati_della_distinta: Mapping[str, Any] = field(default_factory=dict)
    """Il blocco `distinta` del grafo: i dati di cantiere della chat (REL-022)."""
    voci: list[Voce] = field(default_factory=list)
    avvisi: list[str] = field(default_factory=list)
    domande_dei_tratti: list[str] = field(default_factory=list)
    mancanti_dei_tratti: list[Mancante] = field(default_factory=list)
    mancanti_della_verifica: list[Mancante] = field(default_factory=list)

    @property
    def sigle(self) -> dict[str, str]:
        return {ident: pezzo.sigla for ident, pezzo in self.impianto.pezzi.items()}

    def da_a(self, tratta: Tratta) -> str:
        sigle = self.sigle
        return " - ".join(sigle.get(p, p) for p in tratta.pezzi)

    def nome_della_voce(self, voce: str) -> str:
        corredo = self.regole.corredo.get(voce, {})
        return str(self.nomi_del_catalogo.get(voce) or corredo.get("nome") or voce)

    def nome_del_fluido(self, fluido: str) -> str:
        return str(self.nomi_dei_fluidi.get(fluido, fluido))

    def del_pezzo(self, dato: str, pezzo: Pezzo) -> Mancante:
        return Mancante(dato, PEZZO, pezzo.sigla, self.nome_della_voce(pezzo.voce))

    def del_tratto(self, dato: str, tratta: Tratta) -> Mancante:
        return Mancante(dato, TRATTO, tratta.num or "", f"{tratta.rete.nome}: {self.da_a(tratta)}")

    @property
    def fornitura_installatore(self) -> str:
        return self.fornitura.installatore

    def sezione_e_fornitura(self, voce: Mapping[str, Any]) -> tuple[str, str]:
        """La sezione della voce e chi la fornisce: la `fornitura` della regola e' una
        scelta dell'offerta (`apparecchiature`, `bocchette_e_griglie`, …, in
        `distinta.json`), «committente», o niente (l'installatore). Una voce del
        Committente che l'offerta da' all'installatore passa nella sezione che la
        scelta dice, e si quota."""
        return self.fornitura.sezione_e_chi(str(voce["sezione"]), voce.get("fornitura"))


# --- le lunghezze --------------------------------------------------------------


def _in_ordine_di_sigla(sigla: str) -> tuple[tuple[int, int | str], ...]:
    """La sigla come si legge: «TA-2» prima di «TA-10», «TA-03» prima di «TA-04»."""
    return tuple(
        (0, int(pezzo)) if pezzo.isdigit() else (1, pezzo.casefold())
        for pezzo in re.split(r"(\d+)", sigla)
        if pezzo
    )


def _ordina_e_numera(lavoro: _Lavoro) -> None:
    """Per fluido, nell'ordine di `fluidi.json`; dentro il fluido, **nell'ordine delle
    sigle dei pezzi che la tratta collega**, come si leggono nella colonna «Da - a»:
    PLZ-01 - TA-01 prima di PLZ-01 - TA-02. Cosi' T0n va a TA-0n quando c'e' una tratta
    per bocchetta (collaudo T3 di REL-012: T03 andava a TA-04). A parita' di sigle — le
    due linee frigorifere fra le stesse macchine — vale l'ordine del grafo."""
    ordine = {fluido: indice for indice, fluido in enumerate(lavoro.regole.fluidi)}
    posizione = {id(tratta): indice for indice, tratta in enumerate(lavoro.tratte)}
    sigle = lavoro.sigle
    lavoro.tratte.sort(
        key=lambda t: (
            ordine.get(t.fluido, len(ordine)),
            tuple(_in_ordine_di_sigla(sigle.get(p, p)) for p in t.pezzi),
            posizione[id(t)],
        )
    )
    numero_del_tratto = 0
    for tratta in lavoro.tratte:
        if not tratta.diretta or tratta.sezioni:
            numero_del_tratto += 1
            tratta.num = f"T{numero_del_tratto:02d}"


def _minimo_della_classe(regole: RegoleDellaDistinta, fluido: str) -> Minimo | None:
    for classe in regole.lunghezze.get("classi", []):
        if fluido in classe.get("fluidi", []) and float(classe.get("minimo_m", 0)) > 0:
            return Minimo(float(classe["minimo_m"]), f"minimo {classe['classe']}")
    return None


def _lunghezze(lavoro: _Lavoro) -> None:
    regola = lavoro.regole.lunghezze["regola"]
    segue = {str(s["fluido"]): s for s in lavoro.regole.lunghezze.get("segue", [])}

    def calcola(tratta: Tratta, altri: Sequence[Minimo]) -> None:
        if tratta.lunghezza_m is None:
            return
        minimi: list[Minimo] = []
        della_classe = _minimo_della_classe(lavoro.regole, tratta.fluido)
        if della_classe:
            minimi.append(della_classe)
        scritto = numero(tratta.dato("lunghezza_minima_m"))
        if scritto:
            minimi.append(Minimo(scritto, "minimo scritto sul tratto"))
        minimi.extend(altri)
        della_regola = regola
        for classe in lavoro.regole.lunghezze.get("classi", []):
            if tratta.fluido in classe.get("fluidi", []) and "aggiunta_m" in classe:
                # REL-020: una classe con la sua aggiunta (l'acqua in centrale, tratti corti).
                della_regola = {**regola, "aggiunta_m": float(classe["aggiunta_m"])}
        esito = da_quotare(tratta.lunghezza_m, della_regola, minimi)
        tratta.da_quotare_m = esito.da_quotare
        tratta.calcolo_della_lunghezza = esito.calcolo

    for tratta in lavoro.tratte:
        nome = _nome_del_tratto(lavoro, tratta)
        if tratta.illeggibili:
            lavoro.domande_dei_tratti.append(
                f"{nome}: la lunghezza di {_in_parole_le_tubazioni(lavoro.impianto, tratta, tratta.illeggibili)} "
                "non e' un numero."
            )
            lavoro.mancanti_dei_tratti.append(lavoro.del_tratto("lunghezza_m", tratta))
        if tratta.diretta or tratta.fluido in FLUIDI_D_ACQUA:
            # REL-022 (I-288): il grafo e' uno spazio di disegno. I metri dei tubi d'acqua
            # non si leggono sui suoi tratti: li dice il progettista, per rete e diametro.
            continue
        if tratta.lunghezza_m is None:
            lavoro.domande_dei_tratti.append(
                f"{nome}: quanto e' lungo? Serve `lunghezza_m` (la lunghezza stimata) su una sua tubazione, "
                "o 0 se e' un raccordo diretto."
            )
            lavoro.mancanti_dei_tratti.append(lavoro.del_tratto("lunghezza_m", tratta))
            continue
        if tratta.senza_lunghezza:
            lavoro.avvisi.append(
                f"{nome}: {_in_parole_le_tubazioni(lavoro.impianto, tratta, tratta.senza_lunghezza)} senza "
                "lunghezza; si considera compresa nei "
                f"{in_parole(tratta.lunghezza_m)} m dati sul tratto."
            )
        if tratta.fluido not in segue:
            calcola(tratta, ())
    for tratta in lavoro.tratte:
        if tratta.diretta or tratta.lunghezza_m is None or tratta.fluido not in segue:
            continue
        regola_segue = segue[tratta.fluido]
        seguiti = [
            altra
            for altra in lavoro.tratte
            if altra.fluido in regola_segue["fluidi_seguiti"]
            and set(altra.capi) == set(tratta.capi)
            and altra.da_quotare_m is not None
        ]
        altri = []
        if seguiti:
            lunga = max(seguiti, key=lambda t: t.da_quotare_m or 0)
            in_piu = float(regola_segue["in_piu_m"])
            altri.append(
                Minimo((lunga.da_quotare_m or 0) + in_piu, f"segue {lunga.num} + {in_parole(in_piu)} m:")
            )
        calcola(tratta, altri)


# --- le voci dei fluidi ----------------------------------------------------------


def _gruppi(tratte: Sequence[Tratta], raggruppa: str) -> list[list[Tratta]]:
    if raggruppa == "fluido":
        return [list(tratte)]
    gruppi: dict[str | None, list[Tratta]] = {}
    for tratta in tratte:
        gruppi.setdefault(tratta.sezione, []).append(tratta)
    return list(gruppi.values())


def _elenco(parti: Sequence[tuple[str, float]], unita: str = "") -> str:
    testo = " + ".join(f"{chi} {in_parole(q)}" for chi, q in parti)
    totale = sum(q for _, q in parti)
    return f"{testo} = {in_parole(totale)}{unita}" if len(parti) > 1 else f"{testo}{unita}"


def _pezzo_con(lavoro: _Lavoro, tratta: Tratta, dati: Sequence[str]) -> Pezzo | None:
    for capo in tratta.capi:
        pezzo = lavoro.impianto.pezzi.get(capo)
        if pezzo and any(pezzo.proprieta.get(d) not in (None, "") for d in dati):
            return pezzo
    return None


def _voce_del_fluido(
    lavoro: _Lavoro,
    fluido: str,
    regola_del_fluido: Mapping[str, Any],
    voce: Mapping[str, Any],
    gruppo: list[Tratta],
) -> list[Voce]:
    calcolo = voce["calcolo"]
    tipo = str(calcolo["tipo"])
    ident = f"fluidi/{fluido}/{voce['id']}"
    nomi = [t.num for t in gruppo]
    sezioni = [t.sezione for t in gruppo]
    valori: dict[str, Any] = {
        "sezione": ", ".join(_unici(sezioni)) if all(sezioni) else None,
        "materiale": ", ".join(_unici(materiale_della_tratta(t, regola_del_fluido) for t in gruppo))
        or None,
        "rete": ", ".join(_unici(t.rete.nome for t in gruppo)),
    }

    def una_voce(quantita: float | None, conto: str, note: str = "", extra: Mapping[str, Any] | None = None) -> Voce:
        testo, mancanti = riempi(str(voce["testo"]), {**valori, **(extra or {})})
        domande = []
        dati: list[Mancante] = []
        for mancante in mancanti:
            if mancante == "sezione":
                senza = [t for t in gruppo if not t.sezione]
                domande.append(
                    f"{', '.join(t.num for t in senza)} ({lavoro.nome_del_fluido(fluido)}): che sezione hanno? "
                    "Serve `sezione` sul tratto (es. «Ø200», «3G2,5»)."
                )
                dati.extend(lavoro.del_tratto("sezione", t) for t in senza)
            else:
                domande.append(f"{', '.join(nomi)}: manca il dato «{mancante}» per «{testo}».")
                if mancante not in DATI_DI_MACCHINA:
                    # I dati della macchina li chiede la riserva di refrigerante, sul pezzo.
                    dati.extend(lavoro.del_tratto(mancante, t) for t in gruppo)
        sezione, fornitura = lavoro.sezione_e_fornitura(voce)
        return Voce(
            sezione=sezione,
            testo=testo,
            um=str(voce["um"]),
            quantita=quantita,
            fornitura=fornitura,
            regola=ident,
            fonte=str(voce["fonte_in_parole"]),
            perche=str(voce["perche"]),
            calcolo=conto,
            note=note,
            da_definire=quantita is None or bool(mancanti),
            domande=domande,
            mancanti=dati,
            prezzo=prezzo_della_voce(voce, {**valori, **(extra or {})}),
        )

    senza_lunghezza = [t for t in gruppo if t.da_quotare_m is None]
    if tipo in CALCOLI_CON_LA_LUNGHEZZA and senza_lunghezza and tipo != "carica_refrigerante":
        quali = ", ".join(t.num for t in senza_lunghezza)
        if len(senza_lunghezza) == len(gruppo):
            senza = una_voce(None, f"manca la lunghezza di {quali}", f"lunghezza di {quali} {DA_DEFINIRE}")
            senza.mancanti[:0] = [lavoro.del_tratto("lunghezza_m", t) for t in senza_lunghezza]
            return [senza]
        # Collaudo REL-012 t1, §2.4.1: una lunghezza che manca non cancella quelle date.
        # La parte nota si conta, e quella che manca e' una riga sua, DA DEFINIRE.
        noti = [t for t in gruppo if t.da_quotare_m is not None]
        mancante = _voce_del_fluido(lavoro, fluido, regola_del_fluido, voce, senza_lunghezza)
        for riga in mancante:
            riga.calcolo += f"; la parte nota ({', '.join(t.num for t in noti)}) e' nella riga sopra"
        return [*_voce_del_fluido(lavoro, fluido, regola_del_fluido, voce, noti), *mancante]
    lunghe = [(t.num, t.da_quotare_m or 0.0) for t in gruppo]
    totale = sum(q for _, q in lunghe)

    if tipo == "lunghezza":
        note = "; ".join(
            f"{t.num} stimati {in_parole(t.lunghezza_m or 0)} m" for t in gruppo
        )
        return [una_voce(totale, _elenco(lunghe, " m"), note)]
    if tipo == "confezioni":
        esito = in_confezioni(
            [q for _, q in lunghe], float(calcolo["confezione_m"]), float(calcolo["sfrido_m"]), float(calcolo["riserva"])
        )
        note = (
            f"{in_parole(totale)} m in {len(lunghe)} tratti interi: "
            + " + ".join(in_parole(q) for _, q in lunghe)
            + " m"
        )
        voci = [una_voce(float(esito.numero), esito.calcolo, note)]
        if esito.giunte:
            sezione, fornitura = lavoro.sezione_e_fornitura(voce)
            voci.append(
                Voce(
                    sezione=sezione,
                    testo=riempi("Manicotto di giunzione {sezione} per i tratti piu' lunghi di una confezione", valori)[0],
                    um="n",
                    quantita=float(esito.giunte),
                    fornitura=fornitura,
                    regola=ident,
                    fonte=str(voce["fonte_in_parole"]),
                    perche="Un tratto piu' lungo della parte utile di una confezione si giunta: una giunta, un manicotto.",
                    calcolo=f"{esito.giunte} giunte",
                )
            )
            lavoro.avvisi.append(
                f"{', '.join(nomi)}: un tratto e' piu' lungo di una confezione, {esito.giunte} giunte."
            )
        return voci
    if tipo == "per_tratta":
        n = float(calcolo["n"])
        tratti = "tratto" if len(gruppo) == 1 else "tratti"
        return [una_voce(n * len(gruppo), f"{len(gruppo)} {tratti} × {in_parole(n)} = {in_parole(n * len(gruppo))}")]
    if tipo == "passo":
        passo, in_piu = float(calcolo["passo_m"]), int(calcolo.get("in_piu", 0))
        parti = [(chi, float(max(0, quante_volte(q, passo) + in_piu))) for chi, q in lunghe]
        quantita = sum(q for _, q in parti)
        if not quantita:
            return []
        regola = f"(L / {in_parole(passo)} m per eccesso{f' {in_piu:+d}' if in_piu else ''} per tratto)"
        return [una_voce(quantita, f"{_elenco(parti)} {regola}")]
    if tipo == "per_metro":
        ogni, minimo = float(calcolo["ogni_m"]), int(calcolo.get("minimo", 0))
        quantita = float(max(minimo, quante_volte(totale, ogni)))
        return [una_voce(quantita, f"{in_parole(totale)} m / {in_parole(ogni)} m per eccesso, almeno {minimo} = {in_parole(quantita)}")]
    if tipo == "metri_arrotondati":
        fattore, passo = float(calcolo.get("fattore", 1.0)), float(calcolo["passo_m"])
        quantita = per_eccesso(totale * fattore, passo)
        return [
            una_voce(
                quantita,
                f"{_elenco(lunghe, ' m')} × {in_parole(fattore)}, per eccesso a {in_parole(passo)} m = {in_parole(quantita)} m",
            )
        ]
    if tipo == "fisso":
        n = float(calcolo["n"])
        return [una_voce(n, f"{in_parole(n)} per {'fluido' if calcolo.get('raggruppa') == 'fluido' else 'sezione'}")]
    if tipo == "attraversamenti":
        parti, assunti = [], []
        for tratta in gruppo:
            dato = numero(tratta.dato("attraversamenti"))
            if dato is None:
                dato = float(regola_del_fluido.get("attraversamenti_se_mancano", 0))
                if dato:
                    assunti.append(tratta.num)
            if dato:
                parti.append((tratta.num, dato))
        if not parti:
            return []
        note = (
            f"assunt{'o' if len(assunti) == 1 else 'i'} {in_parole(float(regola_del_fluido.get('attraversamenti_se_mancano', 0)))} "
            f"per {', '.join(assunti)} (attraversamenti non dati)"
            if assunti
            else ""
        )
        if assunti:
            lavoro.avvisi.append(
                f"{', '.join(assunti)} ({lavoro.nome_del_fluido(fluido)}): attraversamenti di parete non dati, "
                f"assunti {in_parole(float(regola_del_fluido.get('attraversamenti_se_mancano', 0)))} per tratto "
                f"({regola_del_fluido.get('fonte_attraversamenti_in_parole')})."
            )
        return [una_voce(sum(q for _, q in parti), _elenco(parti), note)]
    if tipo == "proprieta":
        nome = str(calcolo["proprieta"])
        per_valore: dict[str | None, list[Tratta]] = {}
        for tratta in gruppo:
            valore = tratta.dato(nome)
            per_valore.setdefault(str(valore) if valore not in (None, "") else None, []).append(tratta)
        voci = []
        for valore, tratte_del_valore in per_valore.items():
            rete = ", ".join(_unici(t.rete.nome for t in tratte_del_valore))
            voce_del_valore = una_voce(
                float(len(tratte_del_valore)),
                f"una per tratto: {', '.join(t.num for t in tratte_del_valore)}",
                extra={nome: valore, "rete": rete},
            )
            if valore is None:
                voce_del_valore.domande = [
                    f"{t.num} ({t.rete.nome}): manca `{nome}` sul tratto." for t in tratte_del_valore
                ]
                voce_del_valore.mancanti = [lavoro.del_tratto(nome, t) for t in tratte_del_valore]
            voci.append(voce_del_valore)
        return voci
    if tipo == "carica_refrigerante":
        minimo_kg = float(calcolo.get("minimo_kg", 0))
        dati = DATI_DI_MACCHINA
        voci = []
        for tratta in gruppo:
            macchina = _pezzo_con(lavoro, tratta, dati)
            proprieta = macchina.proprieta if macchina else {}
            precarica = numero(proprieta.get("precarica_fino_a_m"))
            grammi = numero(proprieta.get("carica_aggiuntiva_g_m"))
            refrigerante = proprieta.get("refrigerante")
            # Collaudo REL-012 t1, §2.4.3: si chiede solo quello che manca. Il
            # refrigerante dato (la voce lo scrive gia', «R32») non si richiede.
            mancano = [
                d for d in dati if proprieta.get(d) in (None, "") or (d != "refrigerante" and numero(proprieta.get(d)) is None)
            ]
            chi = macchina.sigla if macchina else " o ".join(lavoro.sigle.get(c, c) for c in tratta.capi)
            # REL-016, D4: i dati di macchina si chiedono anche quando manca la
            # lunghezza, perche' le domande si fanno tutte nello stesso giro.
            di_macchina = [
                lavoro.del_pezzo(d, macchina)
                if macchina
                else Mancante(d, PEZZO, chi, UNA_DELLE_MACCHINE)
                for d in mancano
            ]
            if tratta.da_quotare_m is None and not (precarica is None or grammi is None):
                senza = una_voce(
                    None,
                    f"manca la lunghezza di {tratta.num}",
                    f"lunghezza di {tratta.num} {DA_DEFINIRE}",
                    extra={"refrigerante": refrigerante},
                )
                senza.mancanti[:0] = [lavoro.del_tratto("lunghezza_m", tratta)]
                senza.mancanti.extend(di_macchina)
                voci.append(senza)
                continue
            if precarica is None or grammi is None:
                voce_mancante = una_voce(
                    None, "mancano i dati di macchina", extra={"refrigerante": refrigerante}
                )
                in_codice = [f"`{d}`" for d in mancano]
                elenco = in_codice[0] if len(in_codice) == 1 else f"{', '.join(in_codice[:-1])} e {in_codice[-1]}"
                verbo = "serve" if len(in_codice) == 1 else "servono"
                voce_mancante.domande.append(
                    f"{tratta.num}: su {chi} {verbo} {elenco} (dati di macchina del progettista) per la riserva "
                    "di refrigerante."
                )
                if tratta.da_quotare_m is None:
                    voce_mancante.mancanti.append(lavoro.del_tratto("lunghezza_m", tratta))
                voce_mancante.mancanti.extend(di_macchina)
                voci.append(voce_mancante)
                continue
            oltre = max(0.0, (tratta.da_quotare_m or 0) - precarica)
            grezza = oltre * grammi / 1000
            quantita = max(minimo_kg, per_eccesso(grezza, 0.05))
            con_la_carica = una_voce(
                quantita,
                f"{tratta.num}: ({in_parole(tratta.da_quotare_m or 0)} - {in_parole(precarica)} m) × "
                f"{in_parole(grammi)} g/m = {in_parole(grezza, 3)} kg, almeno {in_parole(minimo_kg)} kg → "
                f"{in_parole(quantita)} kg",
                f"precarica fino a {in_parole(precarica)} m; oltre, {in_parole(grammi)} g/m",
                extra={"refrigerante": refrigerante},
            )
            con_la_carica.mancanti.extend(di_macchina)
            voci.append(con_la_carica)
        return voci
    raise ValueError(f"{ident}: calcolo {tipo!r} sconosciuto")


def _voci_dei_fluidi(lavoro: _Lavoro) -> None:
    for fluido, regola_del_fluido in lavoro.regole.fluidi.items():
        if fluido in FLUIDI_D_ACQUA:
            continue
        tratte = [t for t in lavoro.tratte if t.fluido == fluido and not t.diretta]
        if not tratte:
            continue
        for voce in regola_del_fluido.get("voci", []):
            raggruppa = str(voce["calcolo"].get("raggruppa", "sezione"))
            # Una voce che non vale sulle linee con un certo pezzo in mezzo (REL-018): la
            # protezione della linea, dove la linea attraversa l'interruttore, che ha la sua.
            tranne = set(voce["calcolo"].get("tranne_le_linee_con", ()))
            della_voce = [
                t for t in tratte
                if not tranne or not any(
                    (pezzo := lavoro.impianto.pezzi.get(chi)) is not None and pezzo.voce in tranne
                    for chi in t.pezzi
                )
            ]
            # Una voce che vale solo sulle linee che partono da un certo pezzo (REL-021): la
            # protezione nel quadro, non sui comandi che escono dalla scheda di una macchina.
            da = set(voce["calcolo"].get("solo_le_linee_da", ()))
            if da:
                della_voce = [
                    t for t in della_voce
                    if any((pezzo := lavoro.impianto.pezzi.get(chi)) is not None and pezzo.voce in da for chi in t.capi)
                ]
            if not della_voce:
                continue
            for gruppo in _gruppi(della_voce, raggruppa):
                lavoro.voci.extend(_voce_del_fluido(lavoro, fluido, regola_del_fluido, voce, gruppo))
    senza_regola: dict[str, list[Tratta]] = {}
    for tratta in lavoro.tratte:
        if tratta.fluido not in lavoro.regole.fluidi and not tratta.diretta and tratta.fluido not in FLUIDI_D_ACQUA:
            senza_regola.setdefault(tratta.fluido, []).append(tratta)
    for fluido, tratte in senza_regola.items():
        for gruppo in _gruppi(tratte, "sezione"):
            sezione = gruppo[0].sezione or f"{DA_DEFINIRE} (sezione)"
            noti = [t for t in gruppo if t.da_quotare_m is not None]
            ignoti = [t for t in gruppo if t.da_quotare_m is None]
            for parte, quantita in ((noti, sum(t.da_quotare_m or 0 for t in noti)), (ignoti, None)):
                if not parte:
                    continue
                lavoro.voci.append(
                    Voce(
                        sezione="X",
                        testo=f"Linea di {lavoro.nome_del_fluido(fluido)} {sezione}: materiale, corredo e accessori {DA_DEFINIRE}",
                        um="m",
                        quantita=quantita,
                        fornitura=DA_DEFINIRE,
                        regola=f"fluidi/{fluido} (manca)",
                        fonte="nessuna: la distinta non ha regole per questo fluido",
                        perche="Senza regola la distinta non inventa materiale e accessori: quota la lunghezza, se c'e', e chiede.",
                        calcolo=_elenco([(t.num, t.da_quotare_m or 0) for t in parte], " m")
                        if quantita is not None
                        else f"manca la lunghezza di {', '.join(t.num for t in parte)}",
                        note=", ".join(t.num for t in parte),
                        da_definire=True,
                        domande=[
                            f"Il fluido «{lavoro.nome_del_fluido(fluido)}» non ha regole di distinta: materiale, "
                            "corredo e accessori a metro sono da scrivere nelle regole della distinta (fluidi)."
                        ],
                        mancanti=[
                            Mancante("fluido", REGOLE, ", ".join(t.num or "" for t in parte), lavoro.nome_del_fluido(fluido))
                        ],
                    )
                )


# --- i tubi d'acqua, dai dati della chat (REL-022) --------------------------------


DATI_DEI_TUBI = "tubi"

DATI_DA_CHIEDERE = frozenset({"gomiti"})
"""I dati a corpo del blocco `distinta` che, senza risposta, valgono come ipotesi e si
chiedono (I-288)."""
"""Il dato che manca quando il progettista non ha detto i metri di una rete d'acqua."""


def _voci_dei_tubi_d_acqua(lavoro: _Lavoro) -> None:
    """I tubi d'acqua come li dice il progettista nella chat (REL-022, I-288): per rete,
    il tubo, i metri e l'isolamento, nel blocco `distinta` del grafo. Non si misurano sui
    tratti del grafo, che e' uno spazio di disegno. I metri si maggiorano con la regola
    delle lunghezze dell'acqua; collari e manicotti seguono i metri; i gomiti sono a corpo,
    sull'impianto, sul tubo con piu' metri. Una rete d'acqua senza i suoi metri fa una
    voce DA DEFINIRE e una domanda."""
    dati = lavoro.dati_della_distinta
    reti_d_acqua = [r for r in lavoro.impianto.reti.values() if r.fluido in FLUIDI_D_ACQUA]
    usate = {t.rete.id for t in lavoro.tratte if t.fluido in FLUIDI_D_ACQUA}
    tubi = [t for t in dati.get("tubi") or [] if isinstance(t, Mapping)]
    regola = lavoro.regole.lunghezze["regola"]
    aggiunta = next(
        (float(c["aggiunta_m"]) for c in lavoro.regole.lunghezze.get("classi", []) if "aggiunta_m" in c
         and FLUIDI_D_ACQUA & set(c.get("fluidi", []))),
        float(regola["aggiunta_m"]),
    )
    della_regola = {**regola, "aggiunta_m": aggiunta}
    per_rete: dict[str, list[Mapping[str, Any]]] = {}
    for tubo in tubi:
        per_rete.setdefault(str(tubo.get("rete")), []).append(tubo)
    righe: dict[tuple[str, str, str], Voce] = {}
    principale: tuple[float, str, Mapping[str, Any]] | None = None
    for rete in reti_d_acqua:
        if rete.id not in usate:
            continue
        regola_del_fluido = lavoro.regole.fluidi.get(rete.fluido)
        if regola_del_fluido is None:
            continue
        dati_della_rete = per_rete.get(rete.id, [])
        if not dati_della_rete:
            lavoro.voci.append(
                Voce(
                    sezione="I",
                    testo=f"Tubo della rete «{rete.nome}»: diametro, metri e isolamento {DA_DEFINIRE}",
                    um="m",
                    quantita=None,
                    fornitura=lavoro.fornitura_installatore,
                    regola=f"fluidi/{rete.fluido}/tubo",
                    fonte="dato del progettista (I-288)",
                    perche="I metri dei tubi d'acqua non si ricavano dal grafo: li dice il progettista.",
                    calcolo="mancano i metri della rete",
                    da_definire=True,
                    domande=[
                        f"Rete «{rete.nome}»: quanti metri di tubo, di che diametro e come isolato (preisolato, o "
                        "nudo con guaina e il suo spessore)? Si scrivono nel blocco «distinta» del grafo."
                    ],
                    mancanti=[Mancante(DATI_DEI_TUBI, IMPIANTO, rete.id, rete.nome)],
                )
            )
            continue
        for tubo in dati_della_rete:
            sezione = _dicitura_del_tubo(str(tubo.get("tubo") or ""))
            metri = numero(tubo.get("metri"))
            isolamento = str(tubo.get("isolamento") or "")
            esito = da_quotare(metri or 0.0, della_regola, [])
            if principale is None or (metri or 0) > principale[0]:
                principale = (metri or 0.0, sezione, tubo)
            valori = {"sezione": sezione, "isolamento": isolamento or None, "rete": rete.nome}
            for voce in regola_del_fluido.get("voci", []):
                calcolo = voce["calcolo"]
                tipo = str(calcolo["tipo"])
                if tipo == "a_corpo":
                    continue
                se = voce.get("se_isolamento")
                if se is not None and not re.search(str(se), isolamento, re.IGNORECASE):
                    continue
                tranne = voce.get("tranne_isolamento")
                if tranne is not None and isolamento and re.search(str(tranne), isolamento, re.IGNORECASE):
                    continue
                if tipo == "metri":
                    quantita, conto = esito.da_quotare, f"{rete.nome}: {esito.calcolo}"
                elif tipo == "per_metro":
                    ogni, minimo = float(calcolo["ogni_m"]), int(calcolo.get("minimo", 0))
                    quantita = float(max(minimo, quante_volte(esito.da_quotare, ogni)))
                    conto = f"{rete.nome}: {in_parole(esito.da_quotare)} m / {in_parole(ogni)} m, almeno {minimo}"
                elif tipo == "fisso":
                    quantita, conto = float(calcolo["n"]), f"{rete.nome}: {in_parole(float(calcolo['n']))} per tubo"
                else:
                    raise ValueError(f"fluidi/{rete.fluido}/{voce['id']}: calcolo {tipo!r} sconosciuto per l'acqua")
                testo, mancanti = riempi(str(voce["testo"]), valori)
                chiave = (str(voce["sezione"]), testo, str(voce["um"]))
                riga = righe.get(chiave)
                if riga is None:
                    sezione_della_voce, fornitura = lavoro.sezione_e_fornitura(voce)
                    riga = Voce(
                        sezione=sezione_della_voce, testo=testo, um=str(voce["um"]), quantita=0.0, fornitura=fornitura,
                        regola=f"fluidi/{rete.fluido}/{voce['id']}", fonte=str(voce["fonte_in_parole"]),
                        perche=str(voce["perche"]), calcolo="", prezzo=prezzo_della_voce(voce, valori),
                    )
                    righe[chiave] = riga
                    lavoro.voci.append(riga)
                riga.quantita = (riga.quantita or 0.0) + quantita
                riga.calcolo = f"{riga.calcolo} + {conto}" if riga.calcolo else conto
                if "isolamento" in mancanti:
                    riga.da_definire = True
                    domanda = (
                        f"Rete «{rete.nome}», {sezione}: come si isola (preisolato, o nudo con guaina e il suo "
                        "spessore)? Si scrive in «isolamento» del tubo, nel blocco «distinta» del grafo."
                    )
                    if domanda not in riga.domande:
                        riga.domande.append(domanda)
                        riga.mancanti.append(Mancante("isolamento", IMPIANTO, rete.id, rete.nome))
    if principale is None:
        return
    _, sezione, tubo = principale
    for fluido in sorted(FLUIDI_D_ACQUA):
        regola_del_fluido = lavoro.regole.fluidi.get(fluido)
        for voce in (regola_del_fluido or {}).get("voci", []):
            if voce["calcolo"]["tipo"] != "a_corpo":
                continue
            nome_del_dato = str(voce["calcolo"].get("dato", "gomiti"))
            dato = numero(dati.get(nome_del_dato))
            n = dato if dato is not None else float(voce["calcolo"]["n"])
            valori = {"sezione": sezione}
            testo, _ = riempi(str(voce["testo"]), valori)
            sezione_della_voce, fornitura = lavoro.sezione_e_fornitura(voce)
            # I-288: i gomiti a corpo sono un'ipotesi, che si chiede in chat come i metri:
            # senza la risposta la voce porta l'ipotesi, e la domanda resta.
            chiesto = dato is None and nome_del_dato in DATI_DA_CHIEDERE
            lavoro.voci.append(
                Voce(
                    sezione=sezione_della_voce, testo=testo, um=str(voce["um"]), quantita=n, fornitura=fornitura,
                    regola=f"fluidi/{fluido}/{voce['id']}", fonte=str(voce["fonte_in_parole"]),
                    perche=str(voce["perche"]),
                    calcolo=f"{in_parole(n)} a corpo" + (" (ipotesi, da confermare dal progettista)" if chiesto else ""),
                    note="ipotesi da confermare" if chiesto else "",
                    da_definire=chiesto,
                    domande=[
                        f"Quanti gomiti a corpo per l'impianto? L'ipotesi è {in_parole(n)}; si scrive in «gomiti» "
                        "nel blocco «distinta» del grafo."
                    ] if chiesto else [],
                    mancanti=[Mancante(nome_del_dato, IMPIANTO, "", "l'impianto")] if chiesto else [],
                    prezzo=prezzo_della_voce(voce, valori),
                )
            )


# --- il corredo dei pezzi --------------------------------------------------------


def _sezione_al_pezzo(lavoro: _Lavoro, pezzo: str, fluido: str | None = None) -> str | None:
    """La sezione del primo tratto che passa per il pezzo. Un pezzo d'acqua con un
    attacco elettrico (circolatore, deviatrice) sta anche su una linea elettrica: il suo
    tubo e' quello dell'acqua (REL-020), e un fluido dato sceglie i soli suoi tratti."""
    tratte = [t for t in lavoro.tratte if pezzo in t.pezzi]
    if fluido is not None:
        tratte = [t for t in tratte if t.fluido == fluido]
    else:
        tratte = [t for t in tratte if t.fluido in FLUIDI_D_ACQUA] or tratte
    con_la_sezione = [t for t in tratte if t.sezione]
    if con_la_sezione:
        return con_la_sezione[0].sezione
    # REL-022: senza il tubo sul tratto, quello che il progettista ha detto per la rete,
    # se e' uno solo.
    for tratta in tratte:
        della_rete = [
            str(t.get("tubo")) for t in lavoro.dati_della_distinta.get("tubi") or []
            if isinstance(t, Mapping) and t.get("rete") == tratta.rete.id and t.get("tubo")
        ]
        if len(set(della_rete)) == 1:
            return _dicitura_del_tubo(della_rete[0])
    return None


def _vale_per_il_pezzo(voce: Mapping[str, Any], pezzo: Pezzo) -> bool:
    """Una voce del corredo che vale solo se un dato del pezzo dice qualcosa (REL-022):
    `se_dato` {"posa": "staff|muro"} e `tranne_dato`, espressioni sul testo del dato."""
    for chiave, deve in (("se_dato", True), ("tranne_dato", False)):
        for nome, espressione in (voce.get(chiave) or {}).items():
            valore = str(pezzo.proprieta.get(nome) or "")
            trovato = bool(valore) and re.search(str(espressione), valore, re.IGNORECASE) is not None
            if trovato != deve:
                return False
    return True


def _dicitura_del_tubo(sezione: str) -> str:
    """La sezione di un tubo d'acqua come la dice la tavola («multistrato MS 26×3»), se si
    legge; se no com'e' scritta."""
    from disegnatore_mep.diametri.tubi import tubo_dal_testo

    tubo = tubo_dal_testo(sezione)
    return tubo.dicitura if tubo else sezione


def _pollice_del_tubo(sezione: str | None) -> str | None:
    """Il pollice dei raccordi del tubo scritto nella sezione («MS 26×3» → «¾"»), dove il
    calcolo non l'ha dato al pezzo (REL-020: un pezzo a tre vie, o il tubo del progettista)."""
    from disegnatore_mep.diametri.tubi import tubo_dal_testo

    tubo = tubo_dal_testo(sezione)
    return tubo.pollici if tubo else None


@dataclass
class _Locale:
    """Un locale servito dalle bocchette: quello che conta per le griglie di transito."""

    nome: str
    pezzi: list[Pezzo]
    varco: bool
    """Il progettista ha dichiarato un varco aperto verso la ripresa: niente griglia."""
    dall_etichetta: bool
    """Il nome viene dall'etichetta della bocchetta, non dal dato `locale`."""


NON_E_UN_VARCO = frozenset({"", "no", "false", "0", "falso"})


def _ha_un_varco(pezzo: Pezzo) -> bool:
    valore = pezzo.proprieta.get("varco")
    if valore is None or valore is False:
        return False
    return str(valore).strip().casefold() not in NON_E_UN_VARCO


def _locale_della_bocchetta(pezzo: Pezzo) -> tuple[str, bool] | None:
    """Il locale che la bocchetta serve: il dato `locale`, o la sua etichetta senza le
    parentesi e senza la sua sigla in testa («B4 · Soggiorno-cucina» → «Soggiorno-cucina»,
    «Z3 Soggiorno (veletta)» → «Z3 Soggiorno»). `None` se non c'e' ne' l'uno ne' l'altra."""
    locale = pezzo.proprieta.get("locale")
    if isinstance(locale, str) and locale.strip():
        return " ".join(locale.split()), False
    etichetta = pezzo.proprieta.get("etichetta")
    if not isinstance(etichetta, str) or not etichetta.strip():
        return None
    testo = re.sub(r"\([^)]*\)", " ", etichetta)
    senza_sigla = re.sub(rf"^\s*{re.escape(pezzo.sigla)}\s*[·:\-–]\s*", "", testo)
    if senza_sigla.strip() and senza_sigla != testo:
        testo = senza_sigla
    testo = " ".join(testo.split()).strip(" ,;·-–")
    return (testo, True) if testo else None


def _locali_serviti(lavoro: _Lavoro, voce: str) -> tuple[list[_Locale], list[Pezzo]]:
    """I locali serviti dai pezzi di una voce di catalogo (le bocchette), nell'ordine del
    grafo: due bocchette dello stesso locale sono un locale (collaudo REL-012 t1, §2.4.2).
    Restituisce anche le bocchette di cui non si sa il locale."""
    locali: dict[str, _Locale] = {}
    senza: list[Pezzo] = []
    for pezzo in lavoro.impianto.pezzi.values():
        if pezzo.voce != voce:
            continue
        trovato = _locale_della_bocchetta(pezzo)
        if trovato is None:
            senza.append(pezzo)
            continue
        nome, dall_etichetta = trovato
        locale = locali.setdefault(nome.casefold(), _Locale(nome, [], False, dall_etichetta))
        locale.pezzi.append(pezzo)
        locale.varco = locale.varco or _ha_un_varco(pezzo)
    return list(locali.values()), senza


def _apparecchiature(lavoro: _Lavoro) -> None:
    compresi: dict[str, list[Pezzo]] = {}
    per_sigla = {p.sigla: p.id for p in lavoro.impianto.pezzi.values()}
    for pezzo in lavoro.impianto.pezzi.values():
        dentro = pezzo.proprieta.get("compreso_in")
        if dentro:
            bersaglio = str(dentro) if str(dentro) in lavoro.impianto.pezzi else per_sigla.get(str(dentro))
            if bersaglio is None:
                lavoro.avvisi.append(f"{pezzo.sigla}: «compreso_in» nomina {dentro}, che non c'e' nel grafo.")
            else:
                compresi.setdefault(bersaglio, []).append(pezzo)
    gruppi: dict[tuple[str, str, str], list[Pezzo]] = {}
    for pezzo in lavoro.impianto.pezzi.values():
        corredo = lavoro.regole.corredo.get(pezzo.voce)
        if not corredo or not corredo.get("apparecchiatura") or pezzo.proprieta.get("compreso_in"):
            continue
        chiave = (pezzo.voce, str(pezzo.proprieta.get("marca") or ""), str(pezzo.proprieta.get("modello") or ""))
        gruppi.setdefault(chiave, []).append(pezzo)
    for (voce, marca, modello), pezzi in gruppi.items():
        corredo = lavoro.regole.corredo[voce]
        nome = lavoro.nome_della_voce(voce)
        sigle = ", ".join(p.sigla for p in pezzi)
        note: list[str] = []
        primo = pezzi[0].proprieta
        if numero(primo.get("power_kw")) is not None:
            note.append(f"{in_parole(numero(primo.get('power_kw')) or 0)} kW")
        if numero(primo.get("flow_rate_m3h")) is not None:
            note.append(f"{in_parole(numero(primo.get('flow_rate_m3h')) or 0)} m³/h")
        for nota in _unici(str(p.proprieta.get("nota") or "") for p in pezzi):
            note.append(nota)
        for pezzo in pezzi:
            for compreso in compresi.get(pezzo.id, []):
                note.append(f"comprende {compreso.sigla} ({lavoro.nome_della_voce(compreso.voce)})")
        senza = not marca and not modello
        lavoro.voci.append(
            Voce(
                sezione="A",
                testo=f"{nome}: {f'{marca} {modello}'.strip()}" if not senza else f"{nome}: marca e modello {DA_DEFINIRE}",
                um="n",
                quantita=float(len(pezzi)),
                fornitura=lavoro.fornitura.valori["apparecchiature"],
                regola=f"corredo/{voce}/apparecchiatura",
                fonte=str(corredo["fonte_in_parole"]),
                perche=str(corredo["perche"]),
                calcolo=f"{len(pezzi)} nello schema ({sigle})",
                note="; ".join([sigle, *note]),
                da_definire=senza,
                domande=[f"{sigle} ({nome}): marca e modello li dà il progettista."] if senza else [],
                mancanti=[lavoro.del_pezzo(MARCA_E_MODELLO, p) for p in pezzi] if senza else [],
            )
        )


def _corredo(lavoro: _Lavoro) -> None:
    righe: dict[tuple[str, str, str, str], Voce] = {}
    per_locale: dict[int, tuple[list[_Locale], list[Pezzo]]] = {}
    """Le righe contate per locale, con i locali e le bocchette senza locale."""
    senza_corredo: dict[tuple[str, str | None], list[Pezzo]] = {}

    def aggiungi(
        pezzo: Pezzo, voce: Mapping[str, Any], valori: Mapping[str, Any], quantita: float, chi: str, senza_locale: bool
    ) -> None:
        calcolo = voce["calcolo"]
        testo, mancanti = riempi(str(voce["testo"]), valori)
        sezione, fornitura = lavoro.sezione_e_fornitura(voce)
        chiave = (sezione, testo, str(voce["um"]), fornitura)
        riga = righe.get(chiave)
        if riga is None:
            riga = Voce(
                sezione=chiave[0],
                testo=testo,
                um=chiave[2],
                quantita=0.0,
                fornitura=chiave[3],
                regola=f"corredo/{pezzo.voce}/{voce['id']}",
                fonte=str(voce["fonte_in_parole"]),
                perche=str(voce["perche"]),
                calcolo="",
                da_definire=bool(mancanti),
                prezzo=prezzo_della_voce(voce, valori),
            )
            righe[chiave] = riga
            lavoro.voci.append(riga)
        elif f"corredo/{pezzo.voce}/{voce['id']}" not in riga.regola.split(" + "):
            riga.regola += f" + corredo/{pezzo.voce}/{voce['id']}"
            if str(voce["fonte_in_parole"]) not in riga.fonte:
                riga.fonte += f"; {voce['fonte_in_parole']}"
        if calcolo["tipo"] == "per_locale":
            per_locale[id(riga)] = _locali_serviti(lavoro, pezzo.voce)
        riga.quantita = (riga.quantita or 0) + quantita
        riga.contributi.append((chi, quantita))
        for mancante in mancanti:
            if mancante in DATI_DEL_TUBO:
                # REL-020: il pollice e il tubo li da' il calcolo dei diametri, o il
                # progettista con la `sezione` del tratto: non sono dati del pezzo.
                domanda = (
                    f"{pezzo.sigla} ({lavoro.nome_della_voce(pezzo.voce)}): su che tubo sta? Il tubo del suo "
                    "tratto non c'e': i diametri non sono chiesti su quella rete, o il calcolo non ne ha la "
                    "portata. Serve la `sezione` del tratto (es. «MS 32×3»)."
                )
                if domanda not in riga.domande:
                    riga.domande.append(domanda)
                if not any(pezzo.id in t.pezzi and not t.sezione for t in lavoro.tratte):
                    # Il tubo dei suoi tratti c'e', ma non dice il pollice: si chiede sul pezzo.
                    riga.mancanti.append(lavoro.del_pezzo("sezione", pezzo))
                continue
            domanda = f"{pezzo.sigla} ({lavoro.nome_della_voce(pezzo.voce)}): manca il dato «{mancante}» per «{testo}»."
            riga.domande.append(domanda)
            riga.mancanti.append(lavoro.del_pezzo(mancante, pezzo))
        if senza_locale:
            riga.da_definire = True
            riga.domande.append(
                f"{pezzo.sigla} ({lavoro.nome_della_voce(pezzo.voce)}): che locale serve? Serve `locale` sulla "
                "bocchetta (o un'etichetta col nome del locale): le griglie di transito si contano per locale, "
                "e intanto questa bocchetta ne conta una sua."
            )
            riga.mancanti.append(lavoro.del_pezzo("locale", pezzo))

    for pezzo in lavoro.impianto.pezzi.values():
        corredo = lavoro.regole.corredo.get(pezzo.voce)
        if corredo is None:
            # Un accessorio in linea sull'acqua porta il pollice del suo tubo (I-279).
            senza_corredo.setdefault((pezzo.voce, lavoro.pollici.get(pezzo.id)), []).append(pezzo)
            continue
        valori: dict[str, Any] = {k: v for k, v in pezzo.proprieta.items() if v not in (None, "")}
        valori["sigla"] = pezzo.sigla
        valori.setdefault("sezione", _sezione_al_pezzo(lavoro, pezzo.id))
        if lavoro.pollici.get(pezzo.id):
            valori.setdefault("pollice", lavoro.pollici[pezzo.id])
        elif (pollice := _pollice_del_tubo(valori.get("sezione"))) is not None:
            valori.setdefault("pollice", pollice)
        for voce in corredo.get("voci", []):
            if not _vale_per_il_pezzo(voce, pezzo):
                continue
            calcolo = voce["calcolo"]
            n = float(calcolo["n"])
            chi = pezzo.sigla
            senza_locale = False
            if calcolo["tipo"] == "per_linea":
                linee = [
                    t for t in lavoro.tratte if t.fluido == calcolo["fluido"] and not t.diretta and pezzo.id in t.capi
                ]
                quantita = n * len(linee)
                if linee and "{sezione}" in str(voce["testo"]):
                    # REL-020: le linee che arrivano al pezzo possono avere tubi diversi, e
                    # ciascuna porta il suo: una riga per tubo.
                    per_sezione: dict[str | None, int] = {}
                    for linea in linee:
                        per_sezione[linea.sezione] = per_sezione.get(linea.sezione, 0) + 1
                    if len(per_sezione) > 1 or next(iter(per_sezione)) != valori.get("sezione"):
                        for sezione_della_linea, quante in per_sezione.items():
                            aggiungi(pezzo, voce, {**valori, "sezione": sezione_della_linea}, n * quante, chi, False)
                        continue
            elif calcolo["tipo"] == "per_locale":
                locali, _ = _locali_serviti(lavoro, pezzo.voce)
                suo = next((locale for locale in locali if pezzo in locale.pezzi), None)
                if suo is None:
                    quantita, senza_locale = n, True
                elif suo.pezzi[0] is pezzo and not suo.varco:
                    quantita, chi = n, suo.nome
                else:
                    quantita = 0.0
            else:
                quantita = n
            if not quantita:
                continue
            aggiungi(pezzo, voce, valori, quantita, chi, senza_locale)
    for riga in righe.values():
        if id(riga) in per_locale:
            locali, senza = per_locale[id(riga)]
            contati = [locale for locale in locali if not locale.varco]
            parti_del_conto = [f"{len(contati)} locali serviti ({', '.join(locale.nome for locale in contati)})"]
            if senza:
                parti_del_conto.append(
                    f"{len(senza)} bocchette senza locale, una ciascuna ({', '.join(p.sigla for p in senza)})"
                )
            con_varco = [locale.nome for locale in locali if locale.varco]
            if con_varco:
                parti_del_conto.append(f"nessuna dove il locale ha un varco: {', '.join(con_varco)}")
            if any(locale.dall_etichetta for locale in locali):
                parti_del_conto.append("il locale e' letto dall'etichetta della bocchetta")
            riga.calcolo = f"{in_parole(riga.quantita or 0)}: " + "; ".join(parti_del_conto)
            riga.note = ", ".join(s for s, _ in riga.contributi)
            continue
        parti = riga.contributi
        distinte = {q for _, q in parti}
        sigle = ", ".join(s for s, _ in parti)
        if len(distinte) == 1 and len(parti) > 1:
            q = next(iter(distinte))
            riga.calcolo = f"{len(parti)} pezzi × {in_parole(q)} = {in_parole(riga.quantita or 0)} ({sigle})"
            riga.note = sigle
        elif len(parti) == 1:
            riga.calcolo = f"{parti[0][0]}: {in_parole(parti[0][1])}"
            riga.note = parti[0][0]
        else:
            riga.calcolo = _elenco(parti)
            riga.note = ", ".join(f"{s} {in_parole(q)}" for s, q in parti)
    for (voce, pollice), pezzi in senza_corredo.items():
        nome = lavoro.nome_della_voce(voce) + (f" {pollice}" if pollice else "")
        sigle = ", ".join(p.sigla for p in pezzi)
        lavoro.voci.append(
            Voce(
                sezione="X",
                testo=f"{nome}: fornitura e corredo di posa {DA_DEFINIRE}",
                um="n",
                quantita=float(len(pezzi)),
                fornitura=DA_DEFINIRE,
                regola=f"corredo/{voce} (manca)",
                fonte="nessuna: la distinta non ha il corredo di questo pezzo",
                perche="Senza regola la distinta non inventa il corredo: conta i pezzi del grafo e chiede.",
                calcolo=f"{len(pezzi)} nello schema ({sigle})",
                note=sigle,
                da_definire=True,
                domande=[
                    f"«{nome}» ({sigle}) non ha corredo di posa nelle regole della distinta: chi lo fornisce e che "
                    "cosa porta con se'? Si scrive nelle regole della distinta (corredo)."
                ],
                mancanti=[Mancante("corredo", REGOLE, sigle, nome)],
            )
        )


# --- attivita', opere e varianti -------------------------------------------------


def _attivita(lavoro: _Lavoro) -> None:
    fluidi_presenti = {t.fluido for t in lavoro.tratte}
    valori: dict[str, Any] = {f"fornitura.{s}": lavoro.fornitura.testo(s) for s in lavoro.fornitura.scelte}
    for pezzo in lavoro.impianto.pezzi.values():
        valori[f"conta.{pezzo.voce}"] = str(lavoro.impianto.conta(pezzo.voce))
    for fluido in fluidi_presenti:
        valori[f"tratte.{fluido}"] = str(sum(1 for t in lavoro.tratte if t.fluido == fluido and not t.diretta))
    for voce in lavoro.regole.attivita:
        se = voce["se"]
        if "voci" in se:
            presenti = [v for v in se["voci"] if lavoro.impianto.conta(v)]
            vera = bool(presenti)
            perche_vera = f"nell'impianto: {', '.join(lavoro.nome_della_voce(v) for v in presenti)}"
        elif "fluidi" in se:
            presenti = [f for f in se["fluidi"] if f in fluidi_presenti]
            vera = bool(presenti)
            perche_vera = f"nell'impianto: {', '.join(lavoro.nome_del_fluido(f) for f in presenti)}"
        else:
            vera, perche_vera = bool(se["sempre"]), "sempre"
        if not vera:
            continue
        testo, mancanti = riempi(str(voce["testo"]), valori)
        variante = voce["sezione"] == "V"
        sezione, fornitura = lavoro.sezione_e_fornitura(voce)
        lavoro.voci.append(
            Voce(
                sezione=sezione,
                testo=testo,
                um=str(voce["um"]),
                quantita=None if variante else 1.0,
                fornitura=fornitura,
                regola=f"attivita/{voce['id']}",
                fonte=str(voce["fonte_in_parole"]),
                perche=str(voce["perche"]),
                calcolo=perche_vera + ("; solo prezzo unitario" if variante else ""),
                da_definire=bool(mancanti),
                domande=[f"manca il dato «{m}» per «{testo}»" for m in mancanti],
                mancanti=[Mancante(m, REGOLE, "", testo) for m in mancanti],
            )
        )


# --- la verifica -----------------------------------------------------------------


def area_della_sezione(sezione: str | None) -> float | None:
    """L'area lorda in m² di «Ø200» (diametro in mm) o «1000×250» (lati in mm)."""
    if not sezione:
        return None
    rettangolo = re.search(r"(\d+(?:[.,]\d+)?)\s*[×xX]\s*(\d+(?:[.,]\d+)?)", sezione)
    if rettangolo:
        a, b = (float(g.replace(",", ".")) / 1000 for g in rettangolo.groups())
        return a * b
    tondo = re.search(r"Ø\s*(\d+(?:[.,]\d+)?)", sezione)
    if tondo:
        d = float(tondo.group(1).replace(",", ".")) / 1000
        return math.pi * d * d / 4
    return None


def _verifica(lavoro: _Lavoro) -> tuple[list[EsitoDellaVerifica], dict[str, str]]:
    regole = lavoro.regole.verifica
    esiti: list[EsitoDellaVerifica] = []
    soglie = {str(s["fluido"]): s for s in regole.get("velocita", [])}
    for tratta in lavoro.tratte:
        soglia = soglie.get(tratta.fluido)
        if soglia is None or not tratta.num:
            continue
        portata = numero(tratta.dato("portata_m3h"))
        area = area_della_sezione(tratta.sezione)
        massima = float(soglia["massima_m_s"])
        if portata is None or area is None:
            manca = "la portata (`portata_m3h`)" if portata is None else "una sezione che si legge (Ø o lati)"
            if portata is None:
                lavoro.mancanti_della_verifica.append(lavoro.del_tratto("portata_m3h", tratta))
            elif tratta.sezione:
                lavoro.mancanti_della_verifica.append(lavoro.del_tratto("sezione", tratta))
            esiti.append(
                EsitoDellaVerifica(tratta.num, "velocità", f"manca {manca}", f"≤ {in_parole(massima)} m/s", "non verificabile", str(soglia["fonte_in_parole"]))
            )
            continue
        velocita = portata / 3600 / area
        esiti.append(
            EsitoDellaVerifica(
                tratta.num,
                "velocità",
                f"{in_parole(portata)} m³/h su {tratta.sezione}: {in_parole(velocita)} m/s",
                f"≤ {in_parole(massima)} m/s",
                "entro" if velocita <= massima + 1e-9 else "oltre",
                str(soglia["fonte_in_parole"]),
                misura=velocita,
            )
        )
    aree_di_transito: dict[str, str] = {}
    transito = regole.get("transito", {})
    if transito.get("velocita_m_s"):
        v_transito = float(transito["velocita_m_s"])

        def portata_della_bocchetta(pezzo: Pezzo) -> float | None:
            tratte = [t for t in lavoro.tratte if pezzo.id in t.capi and numero(t.dato("portata_m3h")) is not None]
            return numero(tratte[0].dato("portata_m3h")) if tratte else None

        # Per locale servito, con la portata di tutte le sue bocchette (§2.4.2); una
        # bocchetta di cui non si sa il locale fa locale da se'.
        locali, senza = _locali_serviti(lavoro, "air-supply-terminal")
        gruppi = [(locale.nome, locale.pezzi, locale.varco) for locale in locali]
        gruppi += [(pezzo.sigla, [pezzo], False) for pezzo in senza]
        for nome, pezzi, varco in gruppi:
            portate = [q for q in (portata_della_bocchetta(p) for p in pezzi) if q is not None]
            if not portate:
                continue
            portata = sum(portate)
            area = math.ceil(portata / 3600 / v_transito * 1000 - 1e-9) / 1000
            aree_di_transito[nome] = f"{in_parole(area, 3)} m²"
            esiti.append(
                EsitoDellaVerifica(
                    nome,
                    "varco verso la ripresa" if varco else "griglia di transito",
                    f"{in_parole(portata)} m³/h a {in_parole(v_transito)} m/s",
                    f"Aeff ≥ {in_parole(area, 3)} m²",
                    "da rispettare",
                    str(transito["fonte_in_parole"]),
                )
            )
    for tratta in lavoro.tratte:
        if not tratta.fluido.startswith("refrigerant") or tratta.diretta:
            continue
        macchina = _pezzo_con(lavoro, tratta, ("lunghezza_max_m",))
        massima_m = numero(macchina.proprieta.get("lunghezza_max_m")) if macchina else None
        if macchina is None or massima_m is None:
            # REL-016, D4: la verifica non si fa, e il dato si chiede con gli altri — anche
            # se manca la lunghezza, perche' le domande si fanno tutte nello stesso giro.
            # Si chiede alla macchina che ha gli altri dati della scheda, se c'e'.
            con_la_scheda = _pezzo_con(lavoro, tratta, DATI_DI_MACCHINA)
            macchine = [lavoro.impianto.pezzi[c] for c in tratta.capi if c in lavoro.impianto.pezzi]
            lavoro.mancanti_della_verifica.append(
                lavoro.del_pezzo("lunghezza_max_m", con_la_scheda)
                if con_la_scheda
                else Mancante("lunghezza_max_m", PEZZO, " o ".join(m.sigla for m in macchine), UNA_DELLE_MACCHINE)
            )
            continue
        if tratta.da_quotare_m is None:
            continue
        esiti.append(
            EsitoDellaVerifica(
                tratta.num,
                "lunghezza della linea frigorifera",
                f"{in_parole(tratta.da_quotare_m)} m da quotare",
                f"≤ {in_parole(massima_m)} m ({macchina.sigla})",
                "entro" if tratta.da_quotare_m <= massima_m else "oltre",
                str(regole["linea_frigorifera"]["fonte_in_parole"]),
            )
        )
    for tratta in lavoro.tratte:
        scritta = tratta.dato("scritta")
        trovata = re.search(r"L\s*(\d+(?:[.,]\d+)?)\s*m\b", str(scritta or ""))
        if not trovata or tratta.da_quotare_m is None:
            continue
        sulla_tavola = float(trovata.group(1).replace(",", "."))
        uguale = abs(sulla_tavola - tratta.da_quotare_m) < 0.01
        esiti.append(
            EsitoDellaVerifica(
                tratta.num,
                "scritta sulla tavola",
                f"«{scritta}»",
                f"L {in_parole(tratta.da_quotare_m)} m da quotare",
                "entro" if uguale else "oltre",
                str(regole["scritta"]["fonte_in_parole"]),
            )
        )
    for esito in esiti:
        if esito.esito == "oltre":
            lavoro.avvisi.append(f"{esito.dove}, {esito.controllo}: {esito.valore}, contro {esito.soglia}.")
    return esiti, aree_di_transito


# --- le note ---------------------------------------------------------------------


def _note(lavoro: _Lavoro, esiti: Sequence[EsitoDellaVerifica]) -> list[str]:
    regola = lavoro.regole.lunghezze["regola"]
    minimi = [
        f"{', '.join(lavoro.nome_del_fluido(f) for f in c['fluidi'])} {in_parole(float(c['minimo_m']))} m"
        for c in lavoro.regole.lunghezze.get("classi", [])
        if float(c.get("minimo_m", 0)) > 0
    ]
    note = [
        f"«L da quotare» = (L stimata + {in_parole(float(regola['aggiunta_m']))} m) × {in_parole(float(regola['fattore']))}, "
        f"per eccesso a {in_parole(float(regola['passo_m']))} m; minimi: {'; '.join(minimi)}. La L stimata è un dato "
        "del progettista, scritta su ogni tratto.",
        "Quantità indicative per un prezzo a corpo, fisso e invariabile: l'installatore le verifica nel sopralluogo "
        "obbligatorio prima dell'offerta; le varianti hanno solo il prezzo unitario.",
    ]
    for fluido in lavoro.regole.fluidi:
        velocita = [
            e.misura
            for e in esiti
            if e.misura is not None and any(t.num == e.dove and t.fluido == fluido for t in lavoro.tratte)
        ]
        if velocita:
            campo = (
                f"da {in_parole(min(velocita), 1)} a {in_parole(max(velocita), 1)}"
                if min(velocita) != max(velocita)
                else in_parole(velocita[0], 1)
            )
            note.append(
                f"Velocità nei tratti di {lavoro.nome_del_fluido(fluido)} {campo} m/s, sulla sezione lorda, dalle "
                "portate e dalle sezioni del progettista (verifica: segnala, non corregge)."
            )
    note.append(lavoro.fornitura.nota())
    note.append(
        "La distinta non progetta: lunghezze, sezioni, portate, protezioni, marca e modello sono dati del "
        "progettista; la distinta li maggiora e ne conta il corredo con regole scritte, ciascuna con la sua fonte."
    )
    return note


# --- tutto insieme ---------------------------------------------------------------


NON_DATO = "ND"
"""Come «Capire» scrive un dato del cartiglio che il progettista non ha dato: per la
distinta, come per il cartiglio della tavola, e' un dato che manca."""

CAMPI_DEL_PROGETTO = (
    "client",
    "address",
    "project_name",
    "commission_code",
    "revision",
    "issue_date",
    "sheet_number",
    "sheet_title",
)


def _dato_del_cartiglio(valore: object) -> str | None:
    """Il valore come lo legge il cartiglio della tavola: vuoto o «ND» non e' un dato."""
    if valore is None or isinstance(valore, bool):
        return None
    testo = str(valore).strip()
    return None if not testo or testo.upper() == NON_DATO else testo


def _progetto(grafo: Mapping[str, Any], metadati: Mapping[str, Any]) -> dict[str, str]:
    progetto = {c: v for c in CAMPI_DEL_PROGETTO if (v := _dato_del_cartiglio(metadati.get(c))) is not None}
    if "sheet_number" not in progetto:
        numeri = [
            n
            for tavola in grafo.get("sheets") or []
            if isinstance(tavola, Mapping) and (n := _dato_del_cartiglio(tavola.get("number"))) is not None
        ]
        if numeri:
            progetto["sheet_number"] = ", ".join(numeri)
    return progetto


def componi_la_distinta(
    grafo: Mapping[str, Any],
    regole: RegoleDellaDistinta,
    nomi_del_catalogo: Mapping[str, str] | None = None,
    nomi_dei_fluidi: Mapping[str, str] | None = None,
    sigle: Mapping[str, str] | None = None,
    fornitura: Fornitura | None = None,
    tubi: TubiDelloSchema | None = None,
) -> Distinta:
    """La distinta del grafo completo. `nomi_del_catalogo` e `nomi_dei_fluidi` danno i
    nomi in parole; senza, valgono quelli del corredo e gli id dei fluidi. `sigle` sono
    quelle dello schema (`grafo.sigle_dello_schema`): senza, valgono quelle scritte
    dall'ingegnere e poi le etichette. `fornitura` e' la scelta dell'offerta: senza,
    le predefinite delle regole, dichiarate da confermare. `tubi` sono i tubi d'acqua
    della tavola (`grafo.tubi_dello_schema`, I-279): la linea li dice come la tavola,
    «multistrato MS 32×3», e gli accessori in linea portano il pollice del tubo."""
    tubi = tubi or TubiDelloSchema()
    impianto = con_i_tubi(leggi_impianto(grafo, sigle, nomi_del_catalogo, nomi_dei_fluidi), tubi)
    passanti = [voce for voce, corredo in regole.corredo.items() if corredo.get("passante")]
    lavoro = _Lavoro(
        impianto=impianto,
        regole=regole,
        tratte=tratte_dell_impianto(impianto, passanti),
        nomi_del_catalogo=nomi_del_catalogo or {},
        nomi_dei_fluidi=nomi_dei_fluidi or {},
        fornitura=fornitura or la_fornitura(regole),
        pollici=tubi.pollici,
        dati_della_distinta=dict(grafo.get("distinta") or {}),
    )
    for tratta in lavoro.tratte:
        if tratta.fluido in FLUIDI_D_ACQUA and tratta.sezioni:
            # REL-020: «MS 26×3» del progettista e «multistrato MS 26×3» della tavola sono lo
            # stesso tubo, e fanno una riga sola.
            tratta.sezioni = tuple(dict.fromkeys(_dicitura_del_tubo(s) for s in tratta.sezioni))
    if impianto.esclusi:
        lavoro.avvisi.append(f"Esistenti, fuori dalla distinta: {', '.join(impianto.esclusi)}.")
    _ordina_e_numera(lavoro)
    _lunghezze(lavoro)
    _apparecchiature(lavoro)
    _voci_dei_fluidi(lavoro)
    _voci_dei_tubi_d_acqua(lavoro)
    _corredo(lavoro)
    _attivita(lavoro)
    esiti, aree_di_transito = _verifica(lavoro)
    for voce in lavoro.voci:
        if voce.regola.endswith("/griglia-di-transito") and aree_di_transito:
            locali = [chi for chi, _ in voce.contributi]
            voce.note = "Aeff min.: " + ", ".join(
                f"{s} {aree_di_transito[s]}" for s in locali if s in aree_di_transito
            )
    ordine = {lettera: indice for indice, lettera in enumerate(regole.lettere)}
    posizione = {id(voce): indice for indice, voce in enumerate(lavoro.voci)}
    lavoro.voci.sort(key=lambda v: (ordine.get(v.sezione, len(ordine)), posizione[id(v)]))
    contatori: dict[str, int] = {}
    for voce in lavoro.voci:
        contatori[voce.sezione] = contatori.get(voce.sezione, 0) + 1
        voce.rif = f"{voce.sezione}.{contatori[voce.sezione]}"
    progetto = _progetto(grafo, impianto.metadati)
    return Distinta(
        progetto=progetto,
        regole=regole,
        voci=lavoro.voci,
        tratte=lavoro.tratte,
        sigle=lavoro.sigle,
        nomi_dei_fluidi=dict(nomi_dei_fluidi or {}),
        verifica=esiti,
        avvisi=lavoro.avvisi,
        note=_note(lavoro, esiti),
        domande_dei_tratti=lavoro.domande_dei_tratti,
        mancanti_dei_tratti=lavoro.mancanti_dei_tratti,
        mancanti_della_verifica=lavoro.mancanti_della_verifica,
        da_confermare=[] if lavoro.fornitura.confermata else [lavoro.fornitura.in_parole()],
        fornitura=lavoro.fornitura.in_parole(),
    )

