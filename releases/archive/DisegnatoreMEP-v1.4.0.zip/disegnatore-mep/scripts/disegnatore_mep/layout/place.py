"""Dove va posato ciascun componente, che e' meta' della partita.

Il PM, guardando la prima tavola: «Sulle linee delle tubazioni e sulla
posizione delle apparecchiature si gioca la vera partita. La regola e'
minimizzare le curve disegnate, minimizzare gli attraversamenti tra linee e
minimizzare la lunghezza delle linee mantenendo pero' ordinamenti da sinistra a
destra.» E l'esempio: «Hai messo il circolatore in un punto e per far entrare la
linea hai fatto sali-scendi; bastava spostare tutte le apparecchiature a destra
e guadagnavi lo spazio che serviva.»

Le tre voci le paga l'instradamento, ma chi le rende pagabili e' il
posizionamento: una piega non si toglie instradando meglio, se i due attacchi
che collega stanno a quote diverse. Da qui tre regole.

**L'ordine da sinistra a destra e' quello del processo.** Le fasce funzionali
(D-041) lo danno all'ingrosso; dentro una fascia lo da' la profondita' lungo la
mandata, e i rami senza seguito precedono la dorsale che prosegue. Prima si
ordinava per profondita' topologica misurata da una sorgente qualsiasi, che in
un circuito chiuso non esiste: la valvola deviatrice finiva a sinistra della
pompa di calore che la alimenta.

**Dentro una fascia il cursore orizzontale e' uno solo.** Prima ce n'era uno per
livello, cosi' una valvola a mezz'aria poteva stare esattamente sopra la
macchina che la alimenta: geometricamente valido, e nessun ordine leggibile.

**Chi sta su una tubazione si allinea all'attacco che lo alimenta.** Portare il
proprio attacco d'ingresso sulla quota di chi lo serve toglie due pieghe per
componente, ed e' quello che un tecnico fa senza pensarci.

Gli accessori in linea **non** vengono posati qui: appartengono alla tratta su
cui stanno, e li posa `inline.py` dopo l'instradamento (D-027).
"""

from collections import defaultdict
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from math import ceil

from disegnatore_mep.catalog.registry import ComponentRegistry
from disegnatore_mep.graphics.frame import NOVE_C_A4, Rect, SheetFrame
from disegnatore_mep.graphics.symbol import PortFace, SymbolManifest
from disegnatore_mep.model.order import structural_order
from disegnatore_mep.model.project import PortRef, ProjectModel
from disegnatore_mep.model.types import BandRole, PortFlow

from .chains import CHAIN_PORT_GAP_MM, chain_room_mm, machine_chains
from .composition import Standing, levels_of, standing_of
from .errors import LayoutError
from .flow import (
    BOUNDARY_FUNCTION,
    GENERATOR_FUNCTIONS,
    LOAD_FUNCTIONS,
    STORE_FUNCTIONS,
    orient_trunks,
)
from .geometry import PlacedSymbol, Point
from .grid import GridSpace
from .inline import END_CLEARANCE_MM, MIN_SPACING_MM
from .partition import SheetPartition
from .trunks import Trunk

BAND_GUTTER_MM = 10.0
"""Distanza minima fra due fasce funzionali contigue."""

MAX_EXTRA_GUTTER_MM = 30.0
"""Quanto si allarga al massimo una gola quando sul foglio avanza spazio.

Lo spazio libero non si lascia tutto a destra: si distribuisce fra le fasce,
perche' e' li' che passano le tubazioni e stanno gli accessori in linea. E'
la mossa che il PM ha indicato — «bastava spostare tutte le apparecchiature a
destra e guadagnavi lo spazio che serviva» — resa sistematica. Il tetto evita
che un impianto di tre pezzi si stiri per mezza tavola.
"""

ROW_GAP_MM = 10.0
"""Distanza minima fra due componenti affiancati o sovrapposti.

Quattro passi di griglia, cioe' **tre corsie libere** fra un pezzo e il
successivo. Con cinque millimetri ne restava una sola, e bastavano due tratte
che dovessero passare nello stesso varco — la mandata che scende in un
accumulo e il ritorno che ne risale — perche' una delle due dovesse
sovrapporsi all'altra. Sovrapporsi per il lungo e' vietato, quindi il varco
deve essere largo abbastanza da non costringerci.
"""

ROUTING_MARGIN_MM = 7.5
"""Corridoio libero fra il bordo dell'area di disegno e la prima fascia.

Senza, un simbolo appoggiato al bordo sinistro ha le proprie porte rivolte a
sinistra irraggiungibili: la rotta dovrebbe arrivare da fuori pagina.

**Tre** passi di griglia per lato, non quattro. Quattro era un numero tondo, non
una misura: il corridoio serve a far girare una rotta intorno a un simbolo di
bordo, e tre colonne bastano — una per scendere, una per passare, una di
rispetto. I cinque millimetri recuperati sui due lati sono quelli che fanno
entrare l'impianto completo su una A3 invece di dividerlo in due tavole, e
dividere e' un costo di lettura che si paga quando serve (D-056).
"""

_HORIZONTAL_FACES = (PortFace.LEFT, PortFace.RIGHT)

_OPPOSITE: dict[PortFace, PortFace] = {
    PortFace.BOTTOM: PortFace.TOP,
    PortFace.TOP: PortFace.BOTTOM,
    PortFace.LEFT: PortFace.RIGHT,
    PortFace.RIGHT: PortFace.LEFT,
}
"""Dove sta un pezzo rispetto al proprio attacco: dalla parte opposta a dove
l'attacco guarda. Uno sfogo che si imbocca da sotto sta **sopra** il punto in
cui si innesta."""

CLEARANCE_STEPS = 2
"""Passi di stacco fra una linea e il bordo del simbolo da cui esce.

Un attacco rivolto in basso scarica su una corsia che deve **staccarsi** dal
riquadro: a un passo solo la linea corre a due millimetri e mezzo dal bordo e
sulla carta sembra disegnata sul simbolo.
"""

ZONED_FUNCTIONS = (
    GENERATOR_FUNCTIONS
    | STORE_FUNCTIONS
    | LOAD_FUNCTIONS
    | frozenset({"circulation", "distribution"})
)
"""Chi merita una zona, cioe' una colonna della fascia (D-120).

Il PM: «le zone servono solo per distribuire i **macro componenti**» —
generatori, accumuli, circolatori-collettori — e «le valvole che stanno in mezzo
possono finire dove vogliono, a cavallo fra le due zone o in una delle due».

Sono le **funzioni dichiarate dal catalogo**, mai un elenco di componenti
(D-090): chi genera, chi accumula o separa, chi utilizza, chi confina la rete,
chi spinge, chi ripartisce. Tutto il resto — raccordi, organi, strumenti — sta
sulla tratta a cui appartiene e non occupa un passo del processo.

**Il modo sbagliato di attuarlo e' gia' stato provato e buttato**, e vale la
pena non riprovarlo: far entrare la ferramenta *dentro* la colonna del proprio
pezzo grosso restringeva la tavola di centosessanta millimetri e faceva smettere
di uscire l'unica che usciva. La ferramenta non si comprime addosso a nessuno:
si toglie dalla fila e si posa dove la sua tratta passa.
"""


@dataclass(frozen=True)
class _Hanging:
    """Un accessorio che pende da uno stacco, e il pezzo da cui pende.

    Non e' un passo del processo e non merita una colonna sua: sta **accanto al
    proprio pezzo**, dalla parte in cui il suo unico attacco guarda. Prima
    veniva ordinato per profondita' come tutti gli altri, e finiva dove
    capitava: lo scarico del volano si e' ritrovato sessanta millimetri a
    sinistra del volano, con due macchine in mezzo, e la sua tratta non si e'
    piu' instradata su nessun formato, A0 compresa.
    """

    component_id: str
    parent_id: str
    parent_port_id: str
    port_id: str
    """L'attacco **dell'appeso** su questo stacco.

    Non e' sempre il primo del manifesto: un ponte fra due reti ha due attacchi
    e pende da quello che guarda il proprio raccordo. Da qui si legge da che
    parte l'appeso si sporge e su quale punto va allineato (DRAW-006-R1)."""

    room_mm: float
    """Il rettilineo che gli organi di chiusura dello stacco pretendono.

    Lo stacco e' corto per costruzione, ma non e' vuoto: la valvola che isola
    il vaso di espansione ci sta sopra, e se il pezzo si posa attaccato al
    proprio raccordo quella valvola non ha dove sedersi.
    """


def _file_order(project: ProjectModel) -> dict[str, int]:
    """Lo spareggio strutturale fra pezzi altrimenti pari: mai un nome (D-093).

    Era la posizione nel file, e la posizione nel file non sopravvive al JSON
    canonico, che riordina i pezzi per identificativo: la catena della CLI
    disegna quel file, e rinominare un pezzo cambiava la tavola. Adesso l'ordine
    si legge dalla **forma dell'impianto** — voce di catalogo e attacchi verso i
    vicini — e l'identificativo spareggia soltanto fra pezzi che nessun dato
    dell'impianto distingue (DRAW-006-R1, blocco A.2). Il conto vive in
    `layout.order`.
    """
    return structural_order(project)


def _hanging_accessories(
    project: ProjectModel,
    partition: SheetPartition,
    catalog: ComponentRegistry,
    placeable: frozenset[str],
    room_of: Callable[[Trunk, bool], float],
) -> dict[str, list[_Hanging]]:
    """Chi pende da uno stacco, raccolto sotto il pezzo che lo regge.

    Il criterio non nomina nessun componente e non guarda le funzioni: legge il
    **catalogo**, che gia' dichiara quali attacchi stanno fuori dal percorso del
    fluido (`stub` o `serves`, D-101). Chi sta all'altro capo di uno di quegli
    attacchi, e ha un attacco solo, e' un accessorio appeso. `room_of` dice
    quanto lo stacco deve essere lungo, data la tratta e la sua giacitura.
    """
    ports_of = {
        item.id: catalog.resolve(item.definition_id).definition.ports
        for item in project.components
        if item.id in placeable
    }
    functions_of = {
        item.id: frozenset(catalog.resolve(item.definition_id).definition.functions)
        for item in project.components
        if item.id in placeable
    }

    def off_the_run(component_id: str, port_id: str) -> bool:
        return any(
            port.id == port_id and port.off_the_run
            for port in ports_of.get(component_id, [])
        )

    def hangs_entirely(component_id: str) -> bool:
        """Ogni attacco di quel pezzo pende da uno stacco altrui.

        E' la forma generale di «ha un attacco solo»: un accessorio appeso ne
        ha uno, un **ponte fra due reti** ne ha due e pendono tutti e due — dal
        raccordo sul ritorno tecnico e da quello sull'acqua fredda. In nessuno
        dei due casi la tubazione principale attraversa il pezzo, ed e' quello
        che conta per la posa: non e' un passo del processo e non merita una
        colonna sua, sta accanto a cio' da cui pende (DRAW-006-R1, blocco D).
        """
        ports = ports_of.get(component_id, [])
        if not ports:
            return False
        holders = {
            (other.component_id, other.port_id)
            for trunk in partition.trunks
            for mine, other in ((trunk.start, trunk.end), (trunk.end, trunk.start))
            if mine.component_id == component_id
        }
        touched = {
            mine.port_id
            for trunk in partition.trunks
            for mine, _ in ((trunk.start, trunk.end), (trunk.end, trunk.start))
            if mine.component_id == component_id
        }
        # Un **ingresso di rete** che regge una porta conta come uno stacco:
        # non ha una posizione propria (§A.2), quindi non puo' portare con se'
        # il pezzo dentro la lettura. Senza questa riga il gruppo di
        # riempimento, che da DRAW-009 prende l'acqua dal proprio ingresso
        # invece che dalla linea di un altro, smetteva di essere un appeso e si
        # prendeva una colonna in testa al foglio.
        return len(touched) == len(ports) and bool(holders) and all(
            off_the_run(owner, port_id) or is_an_inlet(owner)
            for owner, port_id in holders
        )

    def is_an_inlet(component_id: str) -> bool:
        """Un confine di rete **da cui il fluido entra**: un ingresso.

        Lo dichiara il catalogo con la propria funzione e con il verso del
        proprio attacco, come ogni altra cosa: un ingresso non si riconosce da
        un nome ne' da un elenco nel motore. Un attacco solo, perche' di la'
        dal confine non c'e' impianto.

        Un **prelievo** e' un confine anche lui, ma e' dove il fluido se ne va
        (D-098): e' l'ultimo passo della lettura e sta in fondo, come ogni
        utilizzatore. La distinzione e' la stessa che il progetto fa gia'
        altrove, e non e' un'eccezione aperta qui.
        """
        ports = ports_of.get(component_id, [])
        return (
            len(ports) == 1
            and ports[0].flow is PortFlow.OUT
            and BOUNDARY_FUNCTION in functions_of.get(component_id, frozenset())
        )

    def is_the_mounting_side(component_id: str, port_id: str) -> bool:
        """Il pezzo e' montato sul circuito in cui **sbocca**.

        Un ponte porta acqua da una rete all'altra: la sua sede e' quella di
        arrivo — il gruppo di riempimento sta in centrale, sul ritorno tecnico,
        e l'acqua fredda ce la si porta. Con un attacco solo la domanda non si
        pone e la risposta e' sempre vera.
        """
        ports = ports_of.get(component_id, [])
        if len(ports) < 2:
            return True
        return any(
            port.id == port_id and port.flow is PortFlow.OUT for port in ports
        )

    hanging: dict[str, list[_Hanging]] = defaultdict(list)
    claimed: set[str] = set()
    for trunk in partition.trunks:
        for parent, child in ((trunk.start, trunk.end), (trunk.end, trunk.start)):
            if parent.component_id == child.component_id:
                continue
            if child.component_id in claimed:
                continue
            if child.component_id not in placeable or parent.component_id not in placeable:
                continue
            # **Un ingresso di rete non ha una posizione propria** (I-061,
            # DRAW-009 §A.2). Esiste per immettere, e va posato nelle immediate
            # vicinanze dell'utente che serve, con la propria tratta dritta e
            # senza attraversamenti. Prima era un passo del processo come un
            # altro: l'acquedotto apriva la lettura, il proprio utente stava
            # cinque passi piu' a valle, e la sua linea attraversava il foglio
            # inchiodando ogni pezzo che toccava — il bollitore non si spostava
            # di un passo di griglia senza che l'acqua fredda smettesse di
            # instradarsi. Un ingresso che traversa il foglio e' un difetto
            # **anche quando l'utente e' uno solo**, ed e' per questo che la
            # regola non guarda quanti utenti ci sono.
            if not is_an_inlet(child.component_id):
                if not hangs_entirely(child.component_id):
                    continue
                if not is_the_mounting_side(child.component_id, child.port_id):
                    continue
                if not off_the_run(parent.component_id, parent.port_id):
                    continue
            elif is_an_inlet(parent.component_id):
                # Due confini affacciati non si appendono l'uno all'altro:
                # nessuno dei due e' l'utente dell'altro.
                continue
            face = catalog.resolve(
                next(
                    item.definition_id
                    for item in project.components
                    if item.id == child.component_id
                )
            ).symbol.manifest.port(child.port_id).face
            hanging[parent.component_id].append(
                _Hanging(
                    component_id=child.component_id,
                    parent_id=parent.component_id,
                    parent_port_id=parent.port_id,
                    port_id=child.port_id,
                    room_mm=room_of(trunk, face in (PortFace.LEFT, PortFace.RIGHT)),
                )
            )
            claimed.add(child.component_id)
            break

    # Una figura puo' essere **profonda**: il gruppo di riempimento pende dal
    # raccordo sul ritorno tecnico e dal gruppo pende il proprio ingresso
    # dell'acqua fredda. Chi la posa scende lungo la catena (`hang` si richiama
    # su cio' che ha appena posato), e le misure di ingombro la percorrono tutta.
    # Cio' che non si ammette e' un **anello**: due pezzi che pendono l'uno
    # dall'altro non li posa nessuno, perche' nessuno dei due e' posato per
    # primo. Un anello si scioglie, e i suoi membri riprendono il proprio posto
    # in fila.
    parent_of = {
        item.component_id: parent_id
        for parent_id, items in hanging.items()
        for item in items
    }
    for start in list(parent_of):
        seen: set[str] = set()
        walk: str | None = start
        while walk is not None and walk not in seen:
            seen.add(walk)
            walk = parent_of.get(walk)
        if walk is None:
            continue
        for member in seen:
            parent_id = parent_of.pop(member, None)
            if parent_id is None:
                continue
            hanging[parent_id] = [
                item for item in hanging[parent_id] if item.component_id != member
            ]
            if not hanging[parent_id]:
                hanging.pop(parent_id)
            claimed.discard(member)
    rank = _file_order(project)
    return {
        key: sorted(value, key=lambda item: rank.get(item.component_id, 0))
        for key, value in hanging.items()
    }


@dataclass(frozen=True)
class _RunChain:
    """Una catena di pezzi che stanno su una tratta, e i pezzi grossi che tocca."""

    members: tuple[str, ...]
    """In ordine di percorrenza, dal capo che tocca il primo estremo."""

    anchors: tuple[str, ...]
    """I pezzi grossi ai capi: possono essere piu' di due — una confluenza di
    due macchine su un accumulo ne tocca tre."""

    head_anchors: tuple[str, ...]
    """Quelli attaccati al primo della catena: dicono da che parte si comincia."""

    levels: tuple[int, ...] = ()
    """Il passo di percorrenza di ciascun membro, dai pezzi grossi a monte:
    lungo un cammino semplice cresce di uno a ogni pezzo; dove la catena si
    biforca, due rami paralleli stanno allo **stesso** passo (DRAW-005-R1) e
    la posa li affianca invece di metterli in fila."""


def _ordered(
    chain: set[str],
    neighbours: dict[str, set[str]],
    rank: Callable[[str], int],
    upstream: frozenset[str] = frozenset(),
) -> tuple[tuple[str, ...], tuple[int, ...]]:
    """La catena in ordine di percorrenza, se e' un cammino semplice.

    Dove non lo e' — una catena che si biforca — non esiste un solo «lungo la
    tubazione»: si va per **distanza dai pezzi grossi a monte** (DRAW-005-R1),
    cioe' per passi di tubazione da chi genera verso chi riceve, e a pari
    distanza l'ordine del modello tiene il risultato ripetibile. Con due
    macchine che portano ciascuna il raccordo della propria sicurezza prima
    della confluenza (I-043), l'ordine del modello da solo metteva la
    confluenza prima dei raccordi che la alimentano, e la posa nasceva al
    contrario. Senza pezzi a monte dichiarati resta l'ordine del modello.
    """
    ends = sorted((item for item in chain if len(neighbours[item] & chain) <= 1), key=rank)
    if ends:
        order = [ends[0]]
        walked = {ends[0]}
        while True:
            forward = sorted((neighbours[order[-1]] & chain) - walked, key=rank)
            if len(forward) != 1:
                break
            order.append(forward[0])
            walked.add(forward[0])
        if len(order) == len(chain):
            return tuple(order), tuple(range(1, len(order) + 1))
    if not upstream:
        members = tuple(sorted(chain, key=rank))
        return members, tuple(range(1, len(members) + 1))
    distance: dict[str, int] = {}
    frontier = sorted((item for item in chain if neighbours[item] & upstream), key=rank)
    steps = 1
    while frontier:
        following: list[str] = []
        for item in frontier:
            if item in distance:
                continue
            distance[item] = steps
            following.extend(sorted((neighbours[item] & chain) - set(distance), key=rank))
        frontier = following
        steps += 1
    members = tuple(
        sorted(chain, key=lambda item: (distance.get(item, len(chain) + 1), rank(item)))
    )
    return members, tuple(distance.get(item, len(chain) + 1) for item in members)


def _facing_edges(
    head: list[PlacedSymbol],
    tail: list[PlacedSymbol],
    *,
    horizontal: bool,
) -> tuple[tuple[float, float], tuple[float, float]]:
    """I due bordi che si guardano fra due gruppi di pezzi gia' posati.

    Non i centri: fra due macchine affiancate il centro della piu' lontana sta
    **dietro** l'altra, e una catena che partisse da li' nascerebbe addosso alla
    macchina di mezzo. Si parte dal bordo piu' avanzato del gruppo che sta
    prima, e si arriva al bordo piu' arretrato del gruppo che sta dopo.
    """

    def centre(items: list[PlacedSymbol]) -> tuple[float, float]:
        return (
            sum((item.origin.x_mm + item.right_mm) / 2.0 for item in items) / len(items),
            sum((item.origin.y_mm + item.bottom_mm) / 2.0 for item in items) / len(items),
        )

    head_centre, tail_centre = centre(head), centre(tail)
    if horizontal:
        forward = tail_centre[0] >= head_centre[0]
        start = (
            max(item.right_mm for item in head)
            if forward
            else min(item.origin.x_mm for item in head)
        )
        finish = (
            min(item.origin.x_mm for item in tail)
            if forward
            else max(item.right_mm for item in tail)
        )
        return (start, head_centre[1]), (finish, tail_centre[1])
    forward = tail_centre[1] >= head_centre[1]
    start = (
        max(item.bottom_mm for item in head)
        if forward
        else min(item.origin.y_mm for item in head)
    )
    finish = (
        min(item.origin.y_mm for item in tail)
        if forward
        else max(item.bottom_mm for item in tail)
    )
    return (head_centre[0], start), (tail_centre[0], finish)


def _pieces_on_the_run(
    partition: SheetPartition,
    placeable: frozenset[str],
    hung: frozenset[str],
    is_zoned: Callable[[str], bool],
    rank: Callable[[str], int],
    stage: Callable[[str], int] | None = None,
    joins_two_media: Callable[[str], bool] | None = None,
) -> list[_RunChain]:
    """Chi esce dalla fila delle colonne, e a quali pezzi e' legato (D-120).

    Un raccordo non e' un passo del processo: e' un punto della tubazione, e sta
    **fra i pezzi che unisce**. Finche' prendeva una colonna della fascia veniva
    letto come se fosse una macchina, e finiva dove lo mandava l'ordine del
    processo: sull'impianto 1 la confluenza dei due ritorni stava all'estrema
    sinistra del foglio, **prima delle due pompe di calore da cui quei ritorni
    arrivano**, e il ritorno attraversava la tavola due volte.

    Non si prova a metterlo «in mezzo a due estremi»: una confluenza di due
    macchine su un accumulo di estremi ne ha **tre**, e il posto giusto e' il
    baricentro di ciò a cui e' legato, qualunque sia il loro numero.

    Due condizioni, conservative apposta: il pezzo dev'essere legato ad
    **almeno due** altri — chi ne ha uno solo pende, e lo posa gia' `hang` — e
    la sua catena deve toccare **almeno un pezzo grosso**, o non ci sarebbe
    niente a cui appoggiarsi. Chi non le soddisfa tiene la propria colonna.
    """
    neighbours: dict[str, set[str]] = defaultdict(set)
    for trunk in partition.trunks:
        first, second = trunk.start.component_id, trunk.end.component_id
        if first == second or first not in placeable or second not in placeable:
            continue
        neighbours[first].add(second)
        neighbours[second].add(first)

    # Chi mette in comunicazione **due fluidi** non sta in una catena: una
    # catena e' un tratto di tubazione fra due pezzi grossi, e un ponte non e'
    # un tratto — e' il punto in cui due reti si toccano. Lasciarcelo entrare
    # cuciva insieme la fila del ritorno tecnico e quella dell'acqua fredda, e
    # le prese dell'acqua fredda finivano all'altro capo del foglio
    # (DRAW-006-R1, blocco D).
    free = {
        item
        for item in placeable
        if item not in hung
        and not is_zoned(item)
        and len(neighbours[item]) > 1
        and not (joins_two_media is not None and joins_two_media(item))
    }
    seen: set[str] = set()
    result: list[_RunChain] = []
    for start in sorted(free, key=rank):
        if start in seen:
            continue
        chain: set[str] = set()
        stack = [start]
        while stack:
            current = stack.pop()
            if current in chain:
                continue
            chain.add(current)
            stack.extend((neighbours[current] & free) - chain)
        seen |= chain
        anchors = sorted(
            {
                other
                for item in chain
                for other in neighbours[item]
                if other not in chain and is_zoned(other) and other not in hung
            },
            key=rank,
        )
        if len(anchors) < 2:
            # Con un estremo solo non c'e' un «in mezzo»: la catena tiene le
            # proprie colonne, che e' il comportamento di prima.
            continue
        # I pezzi grossi **a monte** della catena: quelli al passo di processo
        # piu' basso fra i suoi estremi — chi genera prima di chi accumula,
        # chi accumula prima di chi utilizza. Da loro si conta la percorrenza
        # quando la catena si biforca.
        upstream: frozenset[str] = frozenset()
        if stage is not None:
            lowest = min(stage(item) for item in anchors)
            upstream = frozenset(item for item in anchors if stage(item) == lowest)
        members, levels = _ordered(chain, neighbours, rank, upstream)
        # I pezzi grossi di testa sono quelli attaccati al **primo passo** della
        # catena: uno solo lungo un cammino semplice, tutti i rami paralleli
        # dove la catena si biforca — o la campata partirebbe da una macchina e
        # finirebbe sull'altra, invece che sull'accumulo.
        first_step = {item for item, level in zip(members, levels, strict=True) if level == levels[0]}
        heads = {
            other
            for item in first_step
            for other in neighbours[item]
            if other in anchors
        }
        result.append(
            _RunChain(
                members=members,
                anchors=tuple(anchors),
                head_anchors=tuple(sorted(heads, key=rank)),
                levels=levels,
            )
        )
    return result


def _band_by_subsystem(project: ProjectModel, sheet_id: str) -> dict[str, BandRole]:
    for sheet in project.sheets:
        if sheet.id == sheet_id:
            return {item.subsystem_id: item.band for item in sheet.band_assignments}
    return {}


def _assign_bands(
    project: ProjectModel,
    partition: SheetPartition,
    placeable: list[str],
    depth_of: Callable[[str], int],
    _process_rank: Callable[[str], int],
) -> dict[str, BandRole]:
    band_of_subsystem = _band_by_subsystem(project, partition.sheet_id)
    bands: dict[str, BandRole] = {}
    if band_of_subsystem:
        for subsystem in project.subsystems:
            band = band_of_subsystem.get(subsystem.id)
            if band is None:
                continue
            for component_id in subsystem.component_ids:
                bands[component_id] = band
        missing = sorted(set(placeable) - set(bands))
        if missing:
            raise LayoutError(
                f"the pagination plan of sheet {partition.sheet_id} assigns no band to "
                f"{missing}: every component needs a band, or it would not be drawn"
            )
        return bands

    roles = list(BandRole)
    # Senza piano dichiarato, l'ordine delle fasce e' quello del **processo**:
    # chi genera sta a sinistra, poi chi accumula, poi chi utilizza. Lo dicono
    # le **funzioni dichiarate dal catalogo**, mai il nome di un sottosistema o
    # di un componente (D-090).
    #
    # Prima contava l'ordine in cui i sottosistemi comparivano nel file, che e'
    # quanto dire l'ordine alfabetico dei loro nomi: con `accumulo`,
    # `distribuzione`, `generazione` le due pompe di calore finivano
    # all'estrema destra e l'impianto si leggeva al contrario. Un ordine di
    # lettura deciso dal nome di un sottosistema non e' un ordine (D-093), e il
    # PM chiede l'opposto: le macchine principali a sinistra (D-111).
    if project.subsystems:
        ranked = sorted(
            project.subsystems,
            key=lambda item: (
                min(
                    (_process_rank(component_id) for component_id in item.component_ids),
                    default=len(roles),
                ),
                min(
                    (depth_of(component_id) for component_id in item.component_ids),
                    default=len(project.components),
                ),
                project.subsystems.index(item),
            ),
        )
        for index, subsystem in enumerate(ranked):
            role = roles[min(index, len(roles) - 1)]
            for component_id in subsystem.component_ids:
                bands[component_id] = role
        for component_id in placeable:
            bands.setdefault(component_id, roles[-1])
        return bands

    for component_id in placeable:
        bands[component_id] = roles[0]
    return bands


class _Process:
    """L'ordine del processo lungo la mandata: chi viene prima di chi.

    Si costruisce sulle tratte gia' orientate (D-059), quindi legge il verso
    reale del fluido e non la geometria di un disegno che ancora non esiste.
    """

    def __init__(
        self,
        project: ProjectModel,
        partition: SheetPartition,
        catalog: ComponentRegistry,
    ) -> None:
        trunks = list(partition.trunks)
        oriented = orient_trunks(project, catalog, trunks)
        self.feed: dict[str, tuple[PortRef, PortRef]] = {}
        self.position = _file_order(project)
        stubs = {
            (item.id, port.id)
            for item in project.components
            for port in catalog.get(item.definition_id).ports
            if port.off_the_run
        }
        successors: dict[str, list[str]] = defaultdict(list)
        members: set[str] = set()
        for trunk in trunks:
            members.update({trunk.start.component_id, trunk.end.component_id})
            # Uno **stacco va sempre dal percorso a cio' che vi pende**, e mai
            # al contrario: e' una derivazione, non un passo del processo, e
            # chi la regge non viene dopo di lei. Il verso della corsa qui non
            # decide niente — prendendolo alla lettera, il raccordo che regge
            # un ponte fra due reti finiva in fondo alla fila e il gruppo di
            # riempimento tirava la propria presa sull'acqua fredda all'altro
            # capo del foglio (DRAW-006-R1, blocco D).
            hangs = [
                (ref, other)
                for ref, other in ((trunk.start, trunk.end), (trunk.end, trunk.start))
                if (ref.component_id, ref.port_id) in stubs
            ]
            if hangs:
                holder, hung = hangs[0]
                if holder.component_id != hung.component_id:
                    successors[holder.component_id].append(hung.component_id)
                    self.feed.setdefault(hung.component_id, (holder, hung))
                continue
            if oriented.get(trunk.connection_ids) is not True:
                continue
            source, target = trunk.start.component_id, trunk.end.component_id
            if source == target:
                continue
            successors[source].append(target)
            self.feed.setdefault(target, (trunk.start, trunk.end))

        self.depth = dict.fromkeys(members, 0)
        # Rilassamento sul cammino piu' lungo. Il grafo di mandata e' aciclico
        # per costruzione — l'anello si chiude sui ritorni — ma il numero di
        # passate resta limitato, perche' un modello sbagliato non deve
        # bloccare il disegno.
        for _ in range(len(members)):
            changed = False
            for source in sorted(successors):
                for target in sorted(successors[source]):
                    if self.depth[target] <= self.depth[source]:
                        self.depth[target] = self.depth[source] + 1
                        changed = True
            if not changed:
                break

        self.downstream: dict[str, int] = {}
        for component_id in members:
            seen: set[str] = set()
            frontier = list(successors[component_id])
            while frontier:
                current = frontier.pop()
                if current in seen:
                    continue
                seen.add(current)
                frontier.extend(successors[current])
            self.downstream[component_id] = len(seen)

    def order_of(self, component_id: str) -> tuple[int, int, int]:
        """Piu' e' a valle piu' sta a destra; a pari profondita' prima i rami morti.

        L'ultimo spareggio e' la posizione nel modello, non il nome (D-093).
        """
        return (
            self.depth.get(component_id, 0),
            self.downstream.get(component_id, 0),
            self.position.get(component_id, 0),
        )


def _port_of(manifest: SymbolManifest, port_id: str) -> tuple[float, float, PortFace]:
    for port in manifest.ports:
        if port.id == port_id:
            return port.x_mm, port.y_mm, port.face
    raise LayoutError(
        f"symbol {manifest.id} has no port {port_id}: the catalogue definition and "
        f"the symbol manifest disagree on the component's connections"
    )


def _outward(distance: int) -> tuple[int, ...]:
    """0, 1, -1, 2, -2, ...: la quota esatta, poi le piu' vicine."""
    return (0,) if distance == 0 else (distance, -distance)


def _slots(
    order: list[str],
    feeder_of: dict[str, str],
    stackable: dict[str, bool],
    *,
    ground: frozenset[str] = frozenset(),
    heights: dict[str, float] | None = None,
    linked: frozenset[tuple[str, str]] = frozenset(),
    headroom_mm: float = float("inf"),
) -> list[list[str]]:
    """Raggruppa in colonne: i rami paralleli si impilano invece di affiancarsi.

    Due zone servite dallo stesso collettore sono lo stesso passo del processo,
    non due passi in fila: metterle una sopra l'altra e' come le disegna
    chiunque, accorcia la tavola e ne usa l'altezza, che altrimenti resta
    bianca. Vale solo per chi sta su una tubazione: due accumuli appoggiati a
    terra non si possono impilare, e restano affiancati.

    `ground` e' il tentativo di recupero di D-072/D-073, e arriva popolato
    solo quando le fasce non entrano in larghezza: anche chi sta a terra puo'
    allora salire sopra un compagno di fascia — «il serbatoio ACS e il volano
    termico non in fila uno dopo l'altro ma uno sopra l'altro» — in coppie,
    il piu' basso sopra il piu' alto. Non si impila su chi e' collegato da una
    tratta (`linked`): l'ordine del processo resta leggibile in orizzontale.
    Chi sale scavalca le colonne fra la propria e quella ospite, quindi anche
    verso gli scavalcati non deve correre nessuna tratta.
    """
    slots: list[list[str]] = []
    for component_id in order:
        feeder = feeder_of.get(component_id)
        same_branch = (
            slots
            and stackable.get(component_id, False)
            and stackable.get(slots[-1][-1], False)
            and feeder is not None
            and feeder_of.get(slots[-1][-1]) == feeder
        )
        if same_branch:
            slots[-1].append(component_id)
        else:
            slots.append([component_id])
    if not ground:
        return slots

    tall = heights or {}
    merged: list[list[str]] = []
    open_indices: list[int] = []
    for slot in slots:
        if len(slot) != 1 or slot[0] not in ground:
            merged.append(slot)
            continue
        here = slot[0]

        def may_host(index: int, here: str = here) -> bool:
            mate = merged[index][0]
            if (
                tall.get(mate, 0.0) + ROW_GAP_MM + tall.get(here, 0.0)
                > headroom_mm + 1e-9
            ):
                return False
            jumped = [mate] + [
                item for others in merged[index + 1 :] for item in others
            ]
            return not any(
                tuple(sorted((item, here))) in linked for item in jumped
            )

        host = next((index for index in open_indices if may_host(index)), None)
        if host is None:
            merged.append(slot)
            open_indices.append(len(merged) - 1)
            continue
        mate = merged[host][0]
        # Il piu' alto resta a terra, il piu' basso gli sale sopra; a pari
        # altezza l'ordine di processo decide, e chi viene prima resta giu'.
        pair = [here, mate] if tall.get(here, 0.0) > tall.get(mate, 0.0) else [mate, here]
        merged[host] = pair
        open_indices.remove(host)
    return merged


def place_sheet(
    project: ProjectModel,
    partition: SheetPartition,
    catalog: ComponentRegistry,
    frame: SheetFrame,
    inline_component_ids: frozenset[str],
) -> list[PlacedSymbol]:
    """Dispone i componenti non in linea, a fasce, sulla griglia.

    Deterministico: stessa partizione e stesso piano danno la stessa geometria,
    e l'ordine di uscita segue le fasce da sinistra a destra.
    """
    drawing = frame.drawing_rect_mm
    # Il posizionamento lavora dentro un rettangolo piu' piccolo dell'area di
    # disegno: il bordo resta libero perche' l'instradamento possa raggiungere
    # le porte rivolte verso l'esterno.
    area = Rect(
        x_mm=drawing.x_mm + ROUTING_MARGIN_MM,
        y_mm=drawing.y_mm + ROUTING_MARGIN_MM,
        width_mm=drawing.width_mm - 2 * ROUTING_MARGIN_MM,
        height_mm=drawing.height_mm - 2 * ROUTING_MARGIN_MM,
    )
    grid = GridSpace(origin=area, standard=frame.standard)
    step = grid.step_mm

    # I pezzi si posano nell'ordine **strutturale**, non in quello in cui il
    # file li elenca: il JSON canonico li riordina per identificativo, e la posa
    # e' greedy — chi si posa prima prende il posto migliore (DRAW-006-R1, §A.2).
    seats = structural_order(project)
    placeable = sorted(
        (item for item in partition.component_ids if item not in inline_component_ids),
        key=lambda item: seats.get(item, 0),
    )
    if not placeable:
        raise LayoutError(
            f"sheet {partition.sheet_id} carries only inline accessories: an "
            f"accessory sits on a run, so there is nothing to draw it against"
        )

    tags = {item.id: item.tag for item in project.components}
    process = _Process(project, partition, catalog)
    functions_of = {
        item.id: frozenset(catalog.resolve(item.definition_id).definition.functions)
        for item in project.components
    }

    def process_rank(component_id: str) -> int:
        """Che passo del processo e' un pezzo: genera, accumula, utilizza.

        Sono le stesse tre classi che gia' orientano le tratte (`flow.py`) e che
        danno il nome alle linee: qui decidono su quale fascia si posa un
        sottosistema, cioe' quanto a sinistra si legge.
        """
        functions = functions_of.get(component_id, frozenset())
        if functions & GENERATOR_FUNCTIONS:
            return 0
        if functions & STORE_FUNCTIONS:
            return 1
        if functions & LOAD_FUNCTIONS:
            return 2
        return 3

    bands = _assign_bands(
        project,
        partition,
        placeable,
        lambda item: process.depth.get(item, 0),
        process_rank,
    )
    order_hint = {
        item.subsystem_id: item.order
        for sheet in project.sheets
        if sheet.id == partition.sheet_id
        for item in sheet.band_assignments
    }
    subsystem_of = {
        component_id: subsystem.id
        for subsystem in project.subsystems
        for component_id in subsystem.component_ids
    }

    resolved = {
        item: catalog.resolve(
            next(c.definition_id for c in project.components if c.id == item)
        )
        for item in placeable
    }

    def _room_for(trunk_component_ids: tuple[str, ...]) -> float:
        """Il rettilineo che gli accessori di una tratta pretenderanno.

        E' lo stesso conto che `inline.py` fara' dopo l'instradamento: ogni
        accessorio vuole la propria interruzione piu' uno stacco dal vicino, e
        la fila intera vuole due stacchi dai componenti agli estremi.
        """
        accessories = [
            item for item in project.components if item.id in trunk_component_ids
        ]
        if not accessories:
            return 0.0
        return sum(
            (catalog.resolve(item.definition_id).symbol.manifest.inline_gap_mm or 0.0)
            + 2 * MIN_SPACING_MM
            for item in accessories
        ) + 2 * END_CLEARANCE_MM

    hanging = _hanging_accessories(
        project,
        partition,
        catalog,
        frozenset(placeable),
        lambda trunk, horizontal: stub_minimum_mm(project, catalog, trunk, horizontal, step),
    )
    hung = {item.component_id for group in hanging.values() for item in group}

    def joins_two_media(component_id: str) -> bool:
        """Il pezzo tocca piu' di un fluido: e' un ponte fra due reti."""
        found = resolved.get(component_id)
        if found is None:
            return False
        return len({port.medium for port in found.definition.ports}) > 1

    def is_zoned(component_id: str) -> bool:
        return bool(functions_of.get(component_id, frozenset()) & ZONED_FUNCTIONS)

    chains = _pieces_on_the_run(
        partition,
        frozenset(placeable),
        frozenset(hung),
        is_zoned,
        lambda item: process.position.get(item, 0),
        process_rank,
        joins_two_media,
    )
    on_the_run = {item for chain in chains for item in chain.members}
    standing_columns = [
        item for item in placeable if item not in hung and item not in on_the_run
    ]
    if not standing_columns:
        # Un foglio di soli raccordi non esiste, ma se esistesse non avrebbe
        # nessun pezzo grosso a cui appoggiarli: si torna alla fila.
        chains, on_the_run = [], set()
        standing_columns = [item for item in placeable if item not in hung]

    def default_rotation(component_id: str) -> int:
        allowed = resolved[component_id].symbol.manifest.allowed_rotations_deg
        return 0 if 0 in allowed else min(allowed)

    def _sits_toward(component_id: str) -> PortFace:
        """Da che parte del proprio punto di attacco sta un accessorio appeso.

        Lo decide il **suo unico attacco**: chi ce l'ha in basso si posa sopra il
        punto in cui si innesta, chi ce l'ha in alto si posa sotto, e cosi' di
        fianco.
        """
        manifest = resolved[component_id].symbol.manifest.rotated(
            default_rotation(component_id)
        )
        return _OPPOSITE[manifest.ports[0].face]

    def rotation_for(component_id: str) -> int:
        """Come va girato un pezzo, e perche' non e' sempre come sta in libreria.

        Un raccordo con lo stacco rivolto in su e un vaso di espansione che si
        imbocca dall'alto non si possono unire con una linea diritta: il tubo
        dovrebbe uscire in su, scavalcare il raccordo e ridiscendere. Quattro
        pieghe per un pezzo che sta a cinque millimetri, e il primo corridoio
        stretto le rende impossibili — e' cosi' che il vaso e il gruppo di
        riempimento facevano fallire l'instradamento.

        La libreria dichiara le rotazioni ammesse: si prende quella che porta lo
        stacco **dalla parte in cui l'accessorio deve stare**, purche' i due capi
        del percorso restino orizzontali — un raccordo che tira su la strada
        invece che di lato non e' piu' un raccordo in linea.
        """
        manifest = resolved[component_id].symbol.manifest
        preferred = default_rotation(component_id)
        wanted = {
            item.parent_port_id: _sits_toward(item.component_id)
            for item in hanging.get(component_id, ())
        }
        if not wanted:
            return preferred
        for angle in sorted(
            manifest.allowed_rotations_deg, key=lambda item: (item != preferred, item)
        ):
            turned = manifest.rotated(angle)
            if any(
                turned.port(port_id).face is not face
                for port_id, face in wanted.items()
            ):
                continue
            if any(
                port.face not in _HORIZONTAL_FACES
                for port in turned.ports
                if port.id not in wanted
            ):
                continue
            return angle
        return preferred

    manifests = {
        item: resolved[item].symbol.manifest.rotated(rotation_for(item))
        for item in placeable
    }
    standings = {
        item: standing_of(
            manifests[item].height_mm,
            frozenset(resolved[item].definition.functions),
            resolved[item].is_inline,
        )
        for item in placeable
    }

    reading = {role: index for index, role in enumerate(BandRole)}

    def continues_rightwards(component_id: str) -> int:
        """Vero se questo pezzo e' legato a qualcosa di una fascia successiva.

        Chi prosegue va posato **per ultimo** nella propria fascia, qualunque sia
        la sua profondita': altrimenti fra lui e la fascia che alimenta si
        infilano i rami morti, e la tratta che li collega — con i suoi accessori
        — si ritrova senza rettilineo. E' capitato al volano, separato dal
        collettore dalle utenze sanitarie.
        """
        here = reading.get(bands.get(component_id, BandRole.GENERATION), 0)
        for trunk in partition.trunks:
            ends = {trunk.start.component_id, trunk.end.component_id}
            if component_id not in ends:
                continue
            for other in ends - {component_id}:
                if reading.get(bands.get(other, BandRole.GENERATION), 0) > here:
                    return 1
        return 0

    columns: dict[BandRole, list[str]] = defaultdict(list)
    for component_id in standing_columns:
        columns[bands[component_id]].append(component_id)
    for role in columns:
        columns[role].sort(
            key=lambda item: (
                order_hint.get(subsystem_of.get(item, ""), 0),
                continues_rightwards(item),
                *process.order_of(item),
            )
        )

    def snap_up(value_mm: float, origin_mm: float) -> float:
        """Il primo nodo di griglia non prima di `value_mm`.

        Misurato **dall'origine dell'area di disegno**, non dallo zero del
        foglio: l'area comincia a 16 mm dal bordo, che non e' un multiplo del
        passo, e snappare in assoluto porterebbe fuori griglia ogni simbolo.
        """
        offset = value_mm - origin_mm
        steps = int(offset / step) + (1 if offset % step > 1e-9 else 0)
        return origin_mm + step * steps

    def on_grid(value_mm: float, origin_mm: float) -> float:
        return origin_mm + round((value_mm - origin_mm) / step) * step

    def chain_room_of_port(component_id: str, port_id: str, horizontal: bool) -> float:
        """Il rettilineo che la catena della macchina occupa da quell'attacco
        (I-044): lo stesso che l'instradatore imporra' uscendo dalla porta."""
        return chain_room_of_port_mm(
            project,
            catalog,
            partition.trunks,
            PortRef(component_id=component_id, port_id=port_id),
            horizontal,
        )

    def facing_room(here: set[str], there: set[str]) -> float:
        """Il rettilineo che gli attacchi di una colonna rivolti verso l'altra
        pretendono davanti a se' per la catena della macchina (I-044), da
        qualunque parte vada poi la tratta: la tratta esce dritta dalla porta
        per quel tratto, e un vicino piu' vicino di cosi' la mura."""
        found = 0.0
        for members, face in ((here, PortFace.RIGHT), (there, PortFace.LEFT)):
            for component_id in members:
                for port in manifests[component_id].ports:
                    if port.face is face:
                        found = max(found, chain_room_of_port(component_id, port.id, True))
        # La cella in cui la tratta gira, e il bordo del vicino che conta come
        # cella occupata: due passi in piu', o il rettilineo finirebbe dentro
        # di lui.
        return found + 2 * step if found > 0 else 0.0

    # Le catene davanti agli attacchi allargano le gole **finche' la fila entra
    # nel foglio** (I-046): sono un fatto locale, e non possono deformare la
    # composizione — la cascata di tre macchine, con le gole gonfiate, non
    # entrava piu' e si impilava fino a non posarsi. Se la fila non entra si
    # ripiega sulle gole di sempre, e il rettilineo lo lasciano il corridoio
    # davanti alla porta e l'instradatore, e lo compra il ciclo spostando le
    # macchine.
    chain_rooms_in_gutters = [True]

    def inline_room(here: set[str], there: set[str]) -> float:
        """Quanto rettilineo vogliono gli accessori delle tratte fra due colonne.

        Da quando le regole completano l'impianto, una tratta fra due componenti
        affiancati puo' ritrovarsi a portare tre accessori: fra la pompa di
        calore e la sua valvola deviatrice ci stanno termometro, separatore
        d'aria e valvola di sicurezza. Dieci millimetri non bastano, e a
        scoprirlo sarebbe `inline.py` dopo l'instradamento, quando spostare
        qualcosa non e' piu' possibile.

        Solo le tratte **fra queste due colonne**: quelle che vengono da lontano
        hanno gia' il proprio rettilineo lungo la strada. Piu' il rettilineo
        che gli attacchi rivolti verso l'altra colonna pretendono per la
        catena della macchina, ovunque vada la loro tratta (DRAW-005-R1),
        finche' la fila entra nel foglio.
        """
        between = max(
            (
                _room_for(trunk.inline_component_ids)
                for trunk in partition.trunks
                if {trunk.start.component_id, trunk.end.component_id} & here
                and {trunk.start.component_id, trunk.end.component_id} & there
            ),
            default=0.0,
        )
        if not chain_rooms_in_gutters[0] or not here or not there:
            return between
        return max(between, facing_room(here, there))

    used_roles = [role for role in BandRole if columns.get(role)]

    def chain_want_mm(chain: _RunChain) -> float:
        """Quanto rettilineo vuole una catena di raccordi stesa fra i propri
        capi: i pezzi con il loro ingombro, e fra un pezzo e il successivo il
        rettilineo che la tratta pretende per i propri accessori, mai sotto lo
        stacco fra pezzi. E' lo stesso conto con cui la posa la stende, letto
        prima che le colonne prendano posto."""
        members = chain.members
        stops: tuple[tuple[str, ...], ...] = (
            chain.head_anchors,
            *((item,) for item in members),
        )
        wanted = sum(manifests[item].width_mm for item in members)
        for index, group in enumerate((*((item,) for item in members), chain.anchors)):
            load = max(
                (
                    _room_for(trunk.inline_component_ids)
                    for trunk in partition.trunks
                    for item in stops[index]
                    for other in group
                    if {trunk.start.component_id, trunk.end.component_id} == {item, other}
                ),
                default=0.0,
            )
            wanted += max(load, ROW_GAP_MM)
        return wanted

    def chain_gutter_deficits(
        gutters: list[float], widths: dict[BandRole, float]
    ) -> list[float]:
        """Quanto manca, gola per gola, alle catene di raccordi che le
        attraversano (I-046).

        Un raccordo si posa fra i due pezzi grossi che la sua tratta unisce
        (D-120); se fra quei due pezzi non ci sta la fila — i raccordi, e il
        rettilineo che ogni tratta pretende per i propri accessori — il
        raccordo scivola oltre il pezzo grosso, dalla parte sbagliata, e la
        tratta torna indietro a prenderlo. Si guarda percio' allo spazio che
        ci sara' davvero fra i due capi: le gole attraversate piu' le fasce in
        mezzo. Dove basta, il bisogno e' zero e **niente si allarga**: e' un
        criterio per dare a chi ha bisogno lo spazio che avanza, non per
        deformare la composizione.
        """
        position = {role: index for index, role in enumerate(used_roles)}
        found = [0.0] * len(gutters)
        for chain in chains:
            spots = sorted(
                {position[bands[item]] for item in chain.anchors if item in bands}
            )
            if len(spots) < 2:
                continue
            crossed = list(range(spots[0], spots[-1]))
            available = sum(gutters[index] for index in crossed) + sum(
                widths[used_roles[index]] for index in range(spots[0] + 1, spots[-1])
            )
            missing = chain_want_mm(chain) - available
            if missing <= 0:
                continue
            share = missing / len(crossed)
            found = [
                max(item, share) if index in crossed else item
                for index, item in enumerate(found)
            ]
        return found

    feeder_of = {
        component_id: feed[0].component_id
        for component_id, feed in process.feed.items()
    }
    stackable = {item: standings[item] is Standing.RAIL for item in placeable}
    # Le quote si misurano sull'**area di disegno**, non sul rettangolo ridotto
    # in cui si impaccano le fasce: il corridoio di instradamento restringe
    # dove si posa, non dove passa la linea di terra.
    levels = levels_of(drawing.y_mm, drawing.height_mm, step)
    linked = frozenset(
        (trunk.start.component_id, trunk.end.component_id)
        if trunk.start.component_id <= trunk.end.component_id
        else (trunk.end.component_id, trunk.start.component_id)
        for trunk in partition.trunks
    )
    heights = {item: manifests[item].height_mm for item in placeable}

    def hangs_toward(item: _Hanging) -> PortFace:
        """Da che parte l'appeso si sporge rispetto a chi lo regge.

        Dall'attacco **con cui pende da quel raccordo**, non dal primo del
        manifesto: un ponte fra due reti ne ha due, e prendere sempre il primo
        lo appendeva per l'attacco sbagliato — la tubazione girava attorno al
        pezzo per raggiungerlo dal lato opposto (DRAW-006-R1, blocco D).
        """
        return _OPPOSITE[_port_of(manifests[item.component_id], item.port_id)[2]]

    def hanging_gap(item: _Hanging) -> float:
        """Quanto lo stacco e' lungo: il minimo su griglia (I-046), gia' letto
        dalla tratta. Se quel posto e' preso, `hang` si allontana un passo per
        volta; se una riga deve passarci, il ciclo lo allunga e ne paga la
        lunghezza. Nessun franco, nessuna costante."""
        return item.room_mm

    def sideways(component_id: str) -> tuple[float, float]:
        """Quanto un pezzo sporge a sinistra e a destra per cio' che gli pende.

        La figura si percorre **tutta**: da un appeso puo' pendere a sua volta
        qualcosa — dal gruppo di riempimento pende il proprio ingresso — e un
        conto fermo al primo livello lascerebbe il nipote fuori dalla colonna.
        """
        left = right = 0.0
        for item in hanging.get(component_id, ()):
            side = hangs_toward(item)
            below = sideways(item.component_id)
            width = (
                manifests[item.component_id].width_mm
                + hanging_gap(item)
                + (below[0] if side is PortFace.LEFT else below[1])
            )
            if side is PortFace.LEFT:
                left += width
            elif side is PortFace.RIGHT:
                right += width
        return left, right

    def overhang(component_id: str, side: PortFace) -> float:
        """Quanto un pezzo sporge, sopra o sotto, per cio' che gli pende.

        Non e' decorazione: fra il pezzo e cio' che gli pende passa il tubo che
        li unisce, e quel corridoio va **riservato**. Senza, impilare due colonne
        mette il pezzo di sotto proprio nel varco dello stacco di quello di
        sopra, e la tratta piu' corta della tavola non si instrada piu'. Come
        per i fianchi, la figura si percorre tutta.
        """
        return max(
            (
                hanging_gap(item)
                + manifests[item.component_id].height_mm
                + overhang(item.component_id, side)
                for item in hanging.get(component_id, ())
                if hangs_toward(item) is side
            ),
            default=0.0,
        )

    def lift_above_ground(component_id: str) -> float:
        """Di quanto una macchina si stacca da terra per cio' che le pende sotto.

        Un serbatoio con lo scarico sul fondo appoggiato **esattamente** sulla
        linea di terra non ha dove metterlo: sotto la terra non si instrada, e
        l'unica cella libera sotto l'attacco e' gia' pavimento. Su una tavola
        vera il serbatoio sta su un basamento e lo scarico si disegna sotto di
        lui, sopra il pavimento. Qui e' la stessa cosa, misurata.
        """
        return overhang(component_id, PortFace.BOTTOM)

    def footprint_width(component_id: str) -> float:
        """La larghezza che un pezzo occupa **con cio' che gli pende accanto**.

        Chi pende sopra o sotto non allarga niente; chi pende di fianco si',
        e dimenticarlo farebbe sbordare la colonna dentro la successiva.
        """
        left, right = sideways(component_id)
        own = manifests[component_id].width_mm
        stacked = max(
            (
                manifests[item.component_id].width_mm
                for item in hanging.get(component_id, ())
                if hangs_toward(item) in (PortFace.TOP, PortFace.BOTTOM)
            ),
            default=0.0,
        )
        return left + max(own, stacked) + right

    definition_of = {
        item.id: catalog.resolve(item.definition_id).definition
        for item in project.components
    }
    adjacency: dict[str, set[str]] = defaultdict(set)
    for trunk in partition.trunks:
        first, second = trunk.start.component_id, trunk.end.component_id
        if first != second:
            adjacency[first].add(second)
            adjacency[second].add(first)

    def is_a_fitting(component_id: str) -> bool:
        definition = definition_of.get(component_id)
        return definition is not None and definition.is_a_fitting

    def neighbours_of(component_id: str) -> frozenset[str]:
        """A cosa un pezzo e' attaccato **davvero**, guardando attraverso i raccordi.

        Serve a `may_stack`, che riconosce il parallelo da un fatto solo: due
        cose sono in parallelo quando pendono dalle stesse cose. Perche' quel
        fatto si veda, i vicini vanno contati **come li conta un disegnatore**,
        e un disegnatore non dice che due pompe sono diverse perche' ciascuna
        ha il proprio T.

        Due categorie si attraversano, e per la stessa ragione:

        * **cio' che pende da uno stacco** viaggia col proprio pezzo — due
          pompe identiche non smettono di essere in parallelo perche' una ha
          lo sfiato e l'altra no;
        * **i raccordi**, che D-118 ha gia' tolto dalla fila del processo
          («raccordi, organi e strumenti escono dalla fila: non allargano la
          fascia e non occupano un passo del processo») e che `is_a_fitting`
          descrive come cio' che «il fluido attraversa e basta». Il T che porta
          la valvola di sicurezza di una pompa e' equipaggiamento di quella
          pompa, non un passo che la distingue dalle altre.

        **Misurato sulla cascata di tre pompe il 19 settembre**, prima di questa
        riga. I vicini erano:

            pdc-1: cascata-ritorno-a, tee-valve-safety-pdc-1-water-supply
            pdc-2: cascata-ritorno-b, tee-valve-safety-pdc-2-water-supply
            pdc-3: cascata-ritorno-b, tee-valve-safety-pdc-3-water-supply

        Tre insiemi diversi su tre macchine identiche in parallelo, quindi
        `may_stack` le rifiutava **sempre** e nascevano in fila — con il PO che
        guardava la tavola e chiedeva perche' i generatori non fossero
        incolonnati. La regola c'era (**D-041 + D-118**, «generatori a
        sinistra, impilati in verticale se sono piu' di uno»), era scritta,
        era implementata, ed era **irraggiungibile**.
        """
        found: set[str] = set()
        seen = {component_id}
        frontier = sorted(adjacency[component_id])
        while frontier:
            current = frontier.pop()
            if current in seen:
                continue
            seen.add(current)
            if current in hung or is_a_fitting(current):
                frontier.extend(sorted(adjacency[current] - seen))
                continue
            found.add(current)
        return frozenset(found)

    def column_height(slot: list[str]) -> float:
        """Quanto e' alta una colonna con i suoi pezzi uno sopra l'altro.

        Ogni pezzo porta con se' cio' che gli pende sopra e sotto, corridoio
        dello stacco compreso: dimenticarlo faceva entrare la colonna nei conti
        e non nel foglio.
        """
        return sum(
            overhang(item, PortFace.TOP) + heights[item] + overhang(item, PortFace.BOTTOM)
            for item in slot
        ) + ROW_GAP_MM * (len(slot) - 1)

    def may_stack(over: list[str], under: list[str]) -> bool:
        """Se due colonne contigue possono diventare una sola, impilate.

        Si impila **cio' che sta in parallelo, mai cio' che sta in fila.** Due
        zone servite dallo stesso collettore sono lo **stesso passo** del
        processo e una sopra l'altra si leggono come sono; due raccordi che si
        susseguono sulla stessa linea sono **due passi in fila**, e impilarli
        spezza la lettura da sinistra a destra che il PM ha chiesto — oltre a
        costringere la linea a scendere e risalire proprio nel varco dove passa
        lo stacco del primo.

        Il parallelo si riconosce da un fatto solo: **due cose sono in parallelo
        quando pendono dalle stesse cose.** Due pompe di calore attaccate allo
        stesso collettore di mandata e allo stesso collettore di ritorno hanno gli
        stessi vicini; due raccordi in fila sulla stessa linea no — il primo
        guarda il volume, il secondo guarda il collettore. La profondita' lungo
        la mandata non basta a dirlo: il ritorno non e' orientato, e tutto cio'
        che ci sta sopra risulterebbe alla stessa profondita'.

        E vale anche qui che chi appoggia a terra e chi pende da una tubazione
        stanno a due quote diverse e non si impilano l'uno sull'altro.
        """
        if any(
            tuple(sorted((first, second))) in linked
            for first in over
            for second in under
        ):
            return False
        # **I candidati non si contano fra i propri vicini.** «In parallelo»
        # vuol dire *pendere dalle stesse cose*, e tre pompe sullo stesso
        # collettore pendono dalle stesse cose: il fatto che ciascuna veda
        # anche le altre due le rende diverse **solo per esclusione di se
        # stesse**, che e' un artefatto del conto e non una differenza del
        # disegno. Misurato sulla cascata di tre pompe: dopo aver guardato
        # attraverso i raccordi i tre insiemi coincidevano in tutto tranne che
        # in questo, e le tre macchine restavano in fila lo stesso.
        insieme = frozenset((*over, *under))
        if len({neighbours_of(item) - insieme for item in insieme}) != 1:
            return False
        if len({standings[item] for item in (*over, *under)}) != 1:
            return False
        return (
            column_height(over) + ROW_GAP_MM + column_height(under)
            <= levels.ground_mm - area.y_mm + 1e-9
        )

    def compress(
        slots: dict[BandRole, list[list[str]]], budget_mm: float
    ) -> dict[BandRole, list[list[str]]]:
        """Impila una colonna sulla precedente finche' la fila entra nel foglio.

        E' la mossa che D-111 chiede e che mancava: «serve che il collocatore
        possa mettere le cose anche **una sotto l'altra** e non solo una a fianco
        all'altra, e che sappia scegliere fra le disposizioni possibili». Il
        foglio e' un'area da ripartire, non una striscia.

        Si sceglie a ogni giro l'accoppiamento che **restringe di piu'**, e ci si
        ferma appena la fila entra: fra le disposizioni possibili si prende la
        prima che basta, non la piu' compressa, perche' comprimere oltre il
        bisogno accorcia la tavola e la impoverisce. A parita' di guadagno decide
        l'ordine delle fasce e poi quello delle colonne, quindi il risultato non
        dipende da come il file elenca i pezzi.
        """
        current = {role: [list(slot) for slot in slots[role]] for role in used_roles}

        def copy(
            plan: dict[BandRole, list[list[str]]],
        ) -> dict[BandRole, list[list[str]]]:
            return {role: [list(slot) for slot in plan[role]] for role in used_roles}

        def moves(
            plan: dict[BandRole, list[list[str]]],
        ) -> list[tuple[int, int, int, dict[BandRole, list[list[str]]]]]:
            """Le mosse possibili: impilare, oppure scambiare due colonne.

            Lo scambio e' la seconda mossa che D-112 chiede — «cambiare il loro
            ordine relativo quando la topologia lo consente» — e paga piu' di
            quanto sembri: due colonne che si toccano si portano dietro il
            rettilineo degli accessori della tratta che le unisce, e allontanarle
            lo fa pagare alla strada, che quel rettilineo ce l'ha gia'.
            Si scambiano solo colonne che **nessuna tratta collega**, o si
            invertirebbe il verso di lettura del processo.
            """
            found: list[tuple[int, int, int, dict[BandRole, list[list[str]]]]] = []
            for position, role in enumerate(used_roles):
                for index in range(1, len(plan[role])):
                    before, after = plan[role][index - 1], plan[role][index]
                    if may_stack(before, after):
                        trial = copy(plan)
                        trial[role][index - 1] = [*before, *after]
                        del trial[role][index]
                        found.append((0, position, index, trial))
                    joined = any(
                        tuple(sorted((first, second))) in linked
                        for first in before
                        for second in after
                    )
                    if not joined:
                        trial = copy(plan)
                        trial[role][index - 1], trial[role][index] = after, before
                        found.append((1, position, index, trial))
            return found

        while measure(current)[-1] > budget_mm + 1e-9:
            before_mm = measure(current)[-1]
            best: tuple[float, int, int, int] | None = None
            chosen: dict[BandRole, list[list[str]]] | None = None
            for kind, position, index, trial in moves(current):
                saved = before_mm - measure(trial)[-1]
                if saved <= 0:
                    continue
                key = (-saved, kind, position, index)
                if best is None or key < best:
                    best, chosen = key, trial
            if chosen is None:
                return current
            current = chosen
        return current

    def measure(
        slots: dict[BandRole, list[list[str]]],
    ) -> tuple[
        dict[BandRole, list[float]],
        dict[BandRole, float],
        list[float],
        float,
    ]:
        """Stacchi, larghezze, gole e larghezza totale di una disposizione."""
        gaps = {
            role: [
                max(
                    ROW_GAP_MM,
                    snap_up(
                        inline_room(
                            set(slots[role][index]), set(slots[role][index + 1])
                        ),
                        0.0,
                    ),
                )
                for index in range(len(slots[role]) - 1)
            ]
            for role in used_roles
        }
        widths = {
            role: snap_up(
                area.x_mm
                + sum(
                    max(footprint_width(item) for item in slot)
                    for slot in slots[role]
                )
                + sum(gaps[role]),
                area.x_mm,
            )
            - area.x_mm
            for role in used_roles
        }
        # Una gola non e' larga soltanto per estetica: e' li' che corrono le
        # tratte fra una fascia e l'altra. Vale lo stesso criterio degli
        # stacchi interni — si guarda alle **colonne che si toccano**, l'ultima
        # di una fascia e la prima della successiva. Provare a provvedere per
        # ogni tratta che attraversa il confine sovrastimava di ottanta
        # millimetri: una tratta fra componenti lontani viaggia a lungo e il
        # proprio rettilineo ce l'ha gia'.
        gutters = [
            max(
                BAND_GUTTER_MM,
                snap_up(
                    inline_room(
                        set(slots[used_roles[index]][-1]),
                        set(slots[used_roles[index + 1]][0]),
                    ),
                    0.0,
                ),
            )
            for index in range(len(used_roles) - 1)
        ]
        return gaps, widths, gutters, sum(widths.values()) + sum(gutters)

    def pack(
        stacked_ground: frozenset[str],
    ) -> tuple[
        dict[BandRole, list[list[str]]],
        dict[BandRole, list[float]],
        dict[BandRole, float],
        list[float],
        float,
    ]:
        """Colonne, stacchi, larghezze e gole per un dato insieme impilabile.

        Un solo cursore per fascia: la fascia e' larga quanto le sue colonne in
        fila, qualunque quota occupino, e una colonna e' larga quanto il suo
        pezzo piu' largo. Gli stacchi si calcolano **una volta sola** e si
        riusano nel posizionamento: calcolarli due volte con formule diverse
        faceva sbordare una fascia dentro la successiva.
        """
        slots = {
            role: _slots(
                columns[role],
                feeder_of,
                stackable,
                ground=stacked_ground,
                heights=heights,
                linked=linked,
                headroom_mm=levels.ground_mm - area.y_mm,
            )
            for role in used_roles
        }
        # **Cio' che sta in parallelo si impila, sempre — non solo quando manca
        # la larghezza** (D-041 + D-118): «generatori a sinistra, impilati in
        # verticale se sono piu' di uno». Non e' una compressione, e' come si
        # disegna una centrale: due macchine in parallelo hanno gli stessi
        # vicini, e messe in fila costringono il collettore che le serve a stare
        # da una parte sola — di qua o di la' — con il ritorno della seconda che
        # attraversa la tavola per raggiungerlo. Prima capitava per caso: le due
        # pompe si impilavano solo perche' la fila non entrava nel foglio, e
        # appena la tavola si e' allargata si sono affiancate e il ritorno si e'
        # rotto.
        for role in used_roles:
            index = 1
            while index < len(slots[role]):
                before, after = slots[role][index - 1], slots[role][index]
                if may_stack(before, after):
                    slots[role][index - 1] = [*before, *after]
                    del slots[role][index]
                    continue
                index += 1
        return slots, *measure(slots)

    slots, gaps, widths, gutters, total = pack(frozenset())
    if total > area.width_mm + 1e-9:
        # Prima di impilare, via le catene dalle gole (I-046): sono locali.
        chain_rooms_in_gutters[0] = False
        slots, gaps, widths, gutters, total = pack(frozenset())
    if total > area.width_mm + 1e-9:
        # Prima di dividere si impila (D-072): il criterio di divisione non e'
        # «il contenuto non ci sta come l'ho disposto», ma «anche disponendolo
        # meglio non ci sta». Si riprova una volta lasciando salire anche chi
        # sta a terra (D-073); solo se nemmeno cosi' entra, l'errore e' quello
        # originale, con la larghezza misurata della disposizione in fila.
        # **Si impila prima di salire di formato**, su ogni foglio tranne il piu'
        # piccolo. La riga di prima faceva il tentativo solo sul formato piu'
        # grande, perche' li' fallire voleva dire **dividere** la tavola mentre
        # sotto voleva dire solo salire. Con D-148 la scala arriva all'A1, e
        # quella riga ha smesso di fare quel che diceva: su A3 il tentativo
        # spariva, l'impianto saliva di foglio invece di impilare, e usciva un
        # disegno perso dentro un foglio grande — che e' esattamente cio' che
        # il PO ha bocciato il 19 settembre guardando la cascata su A1.
        #
        # L'A4 resta escluso, ed e' la ragione originale: impilare li'
        # comprimerebbe su una A4 un disegno che D-058 manda in A3. **E' l'A4,
        # non «il foglio piu' piccolo»**: il 25 settembre 2026 D-186 ha tolto
        # l'A4 dalla scala, e con la formula di prima il piu' piccolo sarebbe
        # diventato l'A3 — che smetteva di impilare. Misurato: la posa della
        # centrale a quattro fasce su A3 falliva, e su `main` impilava.
        overflow = LayoutError(
            f"the {len(used_roles)} functional bands need {total:g}mm but the drawing "
            f"area is {area.width_mm:g}mm wide: symbols are never shrunk to fit, "
            f"split the plant across more sheets"
        )
        if frame.standard.usable_width_mm <= NOVE_C_A4.standard.usable_width_mm + 1e-9:
            raise overflow
        ground_ids = frozenset(
            item for item in placeable if standings[item] is Standing.GROUND
        )
        slots, gaps, widths, gutters, total = pack(ground_ids)
        if total > area.width_mm + 1e-9:
            # Ultimo tentativo prima di arrendersi: il foglio ha anche
            # un'altezza, e finora nessuno la usava (D-111).
            slots = compress(slots, area.width_mm)
            gaps, widths, gutters, total = measure(slots)
        if total > area.width_mm + 1e-9:
            raise overflow
    if gutters:
        # Lo spazio che avanza si divide **secondo il bisogno, poi in parti
        # uguali** (I-046): prima alle gole che devono ospitare una catena di
        # raccordi fra due pezzi grossi, e solo per quel che manca loro; il
        # resto a tutte, col tetto di sempre. Cosi' la composizione non si
        # allarga di un millimetro — la larghezza totale e' la stessa — e il
        # raccordo trova posto fra i due pezzi che la sua tratta unisce invece
        # di scivolare oltre.
        spare = area.width_mm - total
        deficits = chain_gutter_deficits(gutters, widths) if chain_rooms_in_gutters[0] else []
        given = [0.0] * len(gutters)
        for index in sorted(range(len(deficits)), key=lambda item: -deficits[item]):
            share = int(max(0.0, min(deficits[index], spare)) / step) * step
            given[index], spare = share, spare - share
        even = min(int((spare / len(gutters)) / step) * step, MAX_EXTRA_GUTTER_MM)
        gutters = [item + given[index] + even for index, item in enumerate(gutters)]
    placed: list[PlacedSymbol] = []
    boxes: list[tuple[float, float, float, float]] = []

    stanze_delle_catene: StanzeDelleCatene = {}

    def corridors() -> list[tuple[float, float, float, float]]:
        """Il rettilineo che la catena della macchina pretende davanti a ogni
        attacco gia' posato (I-044), come area da lasciare libera."""
        return port_corridors(
            project, catalog, partition.trunks, placed, step, stanze_delle_catene
        )

    def off_the_corridors(left: float, top: float, width: float, height: float) -> bool:
        return not any(
            left < x1 - 1e-9 and x0 < left + width - 1e-9 and top < y1 - 1e-9 and y0 < top + height - 1e-9
            for x0, y0, x1, y1 in corridors()
        )

    def free_of_boxes(left: float, top: float, width: float, height: float) -> bool:
        """Nessun simbolo posato a meno dello stacco minimo fra pezzi."""
        return not any(
            left < x1 + ROW_GAP_MM
            and x0 - ROW_GAP_MM < left + width
            and top < y1 + ROW_GAP_MM
            and y0 - ROW_GAP_MM < top + height
            for x0, y0, x1, y1 in boxes
        )

    def free_of_symbols(left: float, top: float, width: float, height: float) -> bool:
        return off_the_corridors(left, top, width, height) and free_of_boxes(
            left, top, width, height
        )

    def corridor_is_clear(from_x: float, to_x: float, row: float) -> bool:
        """Nessun simbolo gia' posato taglia il rettilineo che porta all'attacco.

        Il bordo del riquadro conta come dentro, perche' cosi' lo tratta
        l'instradamento: una corsia che passa esattamente sul filo di un
        simbolo per lui e' occupata, e la linea diritta che qui si credeva di
        aver trovato diventa un gomito in piu'.
        """
        low, high = min(from_x, to_x), max(from_x, to_x)
        return not any(
            y0 <= row <= y1 and x0 < high and low < x1 for x0, y0, x1, y1 in boxes
        )

    def aligned_top(component_id: str, left: float, floor: float) -> float | None:
        """La quota che porta l'attacco d'ingresso sulla linea che lo alimenta."""
        feed = process.feed.get(component_id)
        if feed is None:
            return None
        source, target = feed
        feeder = next(
            (item for item in placed if item.component_id == source.component_id), None
        )
        source_manifest = manifests.get(source.component_id)
        if feeder is None or source_manifest is None:
            return None
        source_x, source_y, source_face = _port_of(source_manifest, source.port_id)
        _, target_y, target_face = _port_of(manifests[component_id], target.port_id)
        if target_face not in _HORIZONTAL_FACES:
            return None
        exit_y = feeder.origin.y_mm + source_y
        if source_face is PortFace.BOTTOM:
            exit_y += CLEARANCE_STEPS * step
        elif source_face is PortFace.TOP:
            exit_y -= CLEARANCE_STEPS * step
        exit_x = feeder.origin.x_mm + source_x
        wanted = on_grid(max(exit_y - target_y, floor), area.y_mm)
        manifest = manifests[component_id]
        # La quota esatta vale anche se il posto e' preso, purche' la linea
        # fino a li' sia libera: chi sta su una tubazione poi **scorre lungo
        # la tubazione** fino al primo posto libero, e la linea resta diritta.
        # Salire di quota per scansare un vicino in fila costava due pieghe
        # a ogni raccordo (I-046).
        if (
            wanted + manifest.height_mm <= levels.ground_mm + 1e-9
            and wanted >= floor - 1e-9
            and corridor_is_clear(exit_x, left, wanted + target_y)
        ):
            return wanted
        # Altrimenti si prova la quota esatta, poi quelle sempre piu' lontane:
        # se un altro componente sta gia' li', o gli sta in mezzo, la linea
        # diritta non c'e' comunque, e tanto vale cercarla dove c'e' posto.
        for distance in range(int(area.height_mm / step)):
            for offset in _outward(distance):
                top = wanted + offset * step
                if top < area.y_mm - 1e-9 or top < floor - 1e-9:
                    continue
                if top + manifest.height_mm > levels.ground_mm + 1e-9:
                    continue
                if not free_of_symbols(left, top, manifest.width_mm, manifest.height_mm):
                    continue
                if not corridor_is_clear(exit_x, left, top + target_y):
                    continue
                return top
        return None

    def clear_of_symbols(
        left: float,
        top: float,
        width: float,
        height: float,
        parent_left: float,
        parent_top: float,
        parent: SymbolManifest,
    ) -> bool:
        """Il riquadro non tocca nessun simbolo, tranne il proprio pezzo.

        Il proprio pezzo si esclude perche' e' quello a cui si appende: gli sta
        vicino per costruzione, e chiedergli lo stesso stacco degli estranei lo
        manderebbe a spasso.
        """
        own = (
            parent_left,
            parent_top,
            parent_left + parent.width_mm,
            parent_top + parent.height_mm,
        )
        return off_the_corridors(left, top, width, height) and not any(
            box != own
            and left < box[2] + step
            and box[0] - step < left + width
            and top < box[3] + step
            and box[1] - step < top + height
            for box in boxes
        )

    def hanging_seat(
        parent_id: str, parent_left: float, parent_top: float, item: _Hanging
    ) -> tuple[float, float, float, float]:
        """Il posto **preferito** di cio' che pende, prima di allontanarsi.

        E' il conto che `hang` fa per primo: l'attacco da cui pende, lo stacco
        minimo, e i due bordi che nessuno scavalca — l'area di disegno e la
        terra. Vive a parte perche' lo guarda anche chi deve decidere **dove
        posare il raccordo**: un raccordo che sta bene lui ma che manda il
        proprio appeso dentro un corridoio non e' un buon posto.
        """
        parent = manifests[parent_id]
        child = manifests[item.component_id]
        stub_x, stub_y, _ = _port_of(parent, item.parent_port_id)
        port_x, port_y, _ = _port_of(child, item.port_id)
        gap = hanging_gap(item)
        side = hangs_toward(item)
        if side is PortFace.TOP:
            child_left = parent_left + stub_x - port_x
            child_top = parent_top - gap - child.height_mm
        elif side is PortFace.BOTTOM:
            child_left = parent_left + stub_x - port_x
            child_top = min(
                parent_top + parent.height_mm + gap,
                levels.ground_mm - child.height_mm,
            )
        elif side is PortFace.RIGHT:
            child_left = parent_left + parent.width_mm + gap
            child_top = parent_top + stub_y - port_y
        else:
            child_left = parent_left - gap - child.width_mm
            child_top = parent_top + stub_y - port_y
        child_left = on_grid(child_left, area.x_mm)
        child_top = on_grid(child_top, area.y_mm)
        child_left = min(max(child_left, area.x_mm), area.right_mm - child.width_mm)
        child_top = min(max(child_top, area.y_mm), levels.ground_mm - child.height_mm)
        return child_left, child_top, child.width_mm, child.height_mm

    stub_lanes: dict[str, tuple[float, float, float, float]] = {}
    """La corsia dello stacco con cui ogni appeso e' stato collegato al proprio
    pezzo: li' passa un tubo, non e' spazio libero.

    Serve alle figure **profonde**: chi pende da un appeso non deve sedersi sullo
    stacco con cui l'appeso e' attaccato al proprio pezzo. Senza, l'ingresso
    dell'acqua fredda del gruppo di riempimento si posava esattamente in mezzo
    allo stacco che lega il gruppo al raccordo del ritorno, e quella tratta non
    si instradava piu'.
    """

    def off_the_stub_lane(
        parent_id: str, left: float, top: float, width: float, height: float
    ) -> bool:
        lane = stub_lanes.get(parent_id)
        if lane is None:
            return True
        return not (
            left < lane[2] - 1e-9
            and lane[0] < left + width - 1e-9
            and top < lane[3] - 1e-9
            and lane[1] < top + height - 1e-9
        )

    def hanging_place(
        parent_id: str, parent_left: float, parent_top: float, item: _Hanging
    ) -> tuple[float, float, float, float]:
        """Dove l'appeso **finisce davvero**: il posto preferito, e da li'
        l'allontanamento lungo il proprio stacco finche' non e' libero.

        Il foglio e' condiviso: se al posto preferito c'e' gia' qualcuno ci si
        allontana lungo lo stacco, un passo per volta, fino al bordo del foglio
        o alla terra. Il conto vive qui perche' lo fanno in due — chi posa e chi
        deve decidere **dove posare il raccordo** — e due conti che devono dare
        lo stesso numero divergono.
        """
        child_left, child_top, width, height = hanging_seat(
            parent_id, parent_left, parent_top, item
        )
        parent = manifests[parent_id]
        side = hangs_toward(item)
        reach = (
            area.bottom_mm - area.y_mm
            if side in (PortFace.TOP, PortFace.BOTTOM)
            else area.width_mm
        )
        away = {
            PortFace.TOP: (0.0, -step),
            PortFace.BOTTOM: (0.0, step),
            PortFace.RIGHT: (step, 0.0),
            PortFace.LEFT: (-step, 0.0),
        }[side]
        for _ in range(int(reach / step)):
            if clear_of_symbols(
                child_left, child_top, width, height, parent_left, parent_top, parent
            ) and off_the_stub_lane(parent_id, child_left, child_top, width, height):
                break
            moved_left = child_left + away[0]
            moved_top = child_top + away[1]
            if (
                moved_left < area.x_mm - 1e-9
                or moved_left + width > area.right_mm + 1e-9
                or moved_top < area.y_mm - 1e-9
                or moved_top + height > levels.ground_mm + 1e-9
            ):
                break
            child_left, child_top = moved_left, moved_top
        return child_left, child_top, width, height

    def hanging_is_walled(parent_id: str, left: float, top: float) -> bool:
        """Cio' che pende da qui finirebbe **dentro un corridoio**.

        Il rettilineo che la catena di una macchina pretende davanti alla
        propria porta e' un contratto duro (I-044): occuparlo rende la posa non
        instradabile, su nessun formato. Un appeso che ci finisce dentro di
        solito se ne allontana lungo il proprio stacco — ma lo stacco puo'
        essere murato in fondo, dalla terra o dal bordo del foglio, e allora non
        ha dove andare. Quel posto per il raccordo non e' un posto: se ne cerca
        un altro, e solo se non ce n'e' nessuno si scende agli ultimi ripieghi.
        """
        for item in hanging.get(parent_id, ()):
            child_left, child_top, width, height = hanging_place(
                parent_id, left, top, item
            )
            if not off_the_corridors(child_left, child_top, width, height):
                return True
            if hanging_is_walled(item.component_id, child_left, child_top):
                return True
        return False

    def hang(parent_id: str, parent_left: float, parent_top: float) -> None:
        """Posa cio' che pende dal pezzo appena posato, accanto a lui.

        L'ancoraggio e' l'**attacco** da cui pende, non il centro del pezzo:
        uno scarico sul fondo di un accumulo scende dal punto in cui il fondo lo
        dichiara, e non dalla mezzeria del serbatoio.

        **Nulla scende sotto la linea di terra**: sotto c'e' il pavimento e la
        fascia dei richiami, e l'instradamento non ci passa. Chi dovrebbe finirci
        risale fin dove ci sta, e chi lo regge si e' gia' alzato quanto basta.
        Dove il posto e' preso ci si allontana lungo lo stacco: il conto lo fa
        `hanging_place`, lo stesso che guarda chi sceglie il posto del raccordo.
        """
        for item in hanging.get(parent_id, ()):
            child = manifests[item.component_id]
            child_left, child_top, _, _ = hanging_place(
                parent_id, parent_left, parent_top, item
            )
            placed.append(
                PlacedSymbol(
                    component_id=item.component_id,
                    symbol_id=child.id,
                    rotation_deg=rotation_for(item.component_id),
                    origin=Point(x_mm=child_left, y_mm=child_top),
                    width_mm=child.width_mm,
                    height_mm=child.height_mm,
                    tag=tags.get(item.component_id),
                    port_flows=resolved[item.component_id].glyph_flows,
                )
            )
            boxes.append(
                (
                    child_left,
                    child_top,
                    child_left + child.width_mm,
                    child_top + child.height_mm,
                )
            )
            # La corsia dello stacco appena disegnato, perche' chi pende da
            # questo appeso non ci si sieda sopra.
            holder_x, holder_y, _ = _port_of(
                manifests[parent_id], item.parent_port_id
            )
            own_x, own_y, _ = _port_of(child, item.port_id)
            here = (parent_left + holder_x, parent_top + holder_y)
            there = (child_left + own_x, child_top + own_y)
            stub_lanes[item.component_id] = (
                min(here[0], there[0]),
                min(here[1], there[1]),
                max(here[0], there[0]),
                max(here[1], there[1]),
            )
            # E cio' che pende dall'appeso appena posato: la figura si posa
            # tutta, non solo il primo livello.
            hang(item.component_id, child_left, child_top)

    position_of = {role: index for index, role in enumerate(used_roles)}
    x_mm = area.x_mm
    for role in used_roles:
        cursor = x_mm
        for position, slot in enumerate(slots[role]):
            left = on_grid(cursor + max(sideways(item)[0] for item in slot), area.x_mm)
            floor = area.y_mm
            ground_top: float | None = None
            for component_id in slot:
                manifest = manifests[component_id]
                if standings[component_id] is Standing.GROUND:
                    if ground_top is None:
                        top = on_grid(
                            levels.ground_mm
                            - manifest.height_mm
                            - lift_above_ground(component_id),
                            area.y_mm,
                        )
                    else:
                        # La coppia impilata del tentativo di recupero (D-073):
                        # il secondo lascia la terra e sale sopra il primo,
                        # allineato a sinistra, con lo stacco di fascia. Sopra
                        # il primo c'e' anche **cio' che gli pende sopra**: lo
                        # sfogo di un volano sta fuori dal suo riquadro, e chi
                        # gli saliva addosso ci finiva sopra.
                        top = on_grid(
                            ground_top - ROW_GAP_MM - manifest.height_mm, area.y_mm
                        )
                    ground_top = top - overhang(component_id, PortFace.TOP)
                else:
                    found = aligned_top(component_id, left, floor)
                    if found is None:
                        fallback = (
                            levels.auxiliary_mm
                            if standings[component_id] is Standing.AUXILIARY
                            else levels.lower_supply_mm - manifest.height_mm / 2
                        )
                        found = on_grid(max(fallback, floor), area.y_mm)
                        while (
                            not free_of_symbols(
                                left, found, manifest.width_mm, manifest.height_mm
                            )
                            and found + manifest.height_mm < levels.ground_mm
                        ):
                            found += ROW_GAP_MM
                    top = found
                if (
                    top < area.y_mm - 1e-9
                    or top + manifest.height_mm > area.bottom_mm + 1e-9
                ):
                    raise LayoutError(
                        f"component {component_id} does not fit between the drawing "
                        f"area and the ground line: symbols are never shrunk to fit"
                    )
                placed.append(
                    PlacedSymbol(
                        component_id=component_id,
                        symbol_id=manifest.id,
                        rotation_deg=rotation_for(component_id),
                        origin=Point(x_mm=left, y_mm=top),
                        width_mm=manifest.width_mm,
                        height_mm=manifest.height_mm,
                        tag=tags.get(component_id),
                        # Il verso dell'acqua sulle porte con freccia, dal
                        # catalogo (I-032): la posa lo scrive, il renderer lo legge.
                        port_flows=resolved[component_id].glyph_flows,
                    )
                )
                boxes.append(
                    (left, top, left + manifest.width_mm, top + manifest.height_mm)
                )
                hang(component_id, left, top)
                # Il prossimo della colonna sta sotto questo, non accanto — e
                # sotto anche a cio' che gli pende, corridoio compreso.
                floor = (
                    top
                    + manifest.height_mm
                    + overhang(component_id, PortFace.BOTTOM)
                    + ROW_GAP_MM
                )
            widest = max(footprint_width(item) for item in slot)
            gap = gaps[role][position] if position < len(gaps[role]) else 0.0
            cursor = on_grid(cursor, area.x_mm) + widest + gap
        x_mm += widths[role]
        if position_of[role] < len(gutters):
            x_mm += gutters[position_of[role]]

    # Chi sta sulla tratta si posa **alla fine**, fra i due pezzi grossi che
    # quella tratta unisce (D-120): non ha una colonna, quindi non allarga la
    # fascia, e non ha un posto nel processo, quindi non sposta nessuno. Puo'
    # benissimo trovarsi a cavallo di due zone — e' proprio cio' che il PM
    # chiede.
    settled = {item.component_id: item for item in placed}

    def room_between(first_id: str, second_id: str) -> float:
        """Il rettilineo che vuole la tratta fra due pezzi, se ne esiste una."""
        return max(
            (
                _room_for(trunk.inline_component_ids)
                for trunk in partition.trunks
                if {trunk.start.component_id, trunk.end.component_id}
                == {first_id, second_id}
            ),
            default=0.0,
        )

    def centre_of(component_id: str) -> tuple[float, float] | None:
        item = settled.get(component_id)
        if item is None:
            return None
        return (
            (item.origin.x_mm + item.right_mm) / 2.0,
            (item.origin.y_mm + item.bottom_mm) / 2.0,
        )

    def settle_on_the_run(
        component_id: str,
        centre_x: float,
        centre_y: float,
        along: tuple[float, float],
        forward: int,
        span: tuple[float, float] | None = None,
    ) -> PlacedSymbol:
        manifest = manifests[component_id]
        left = on_grid(centre_x - manifest.width_mm / 2.0, area.x_mm)
        top = on_grid(centre_y - manifest.height_mm / 2.0, area.y_mm)
        left = min(max(left, area.x_mm), area.right_mm - manifest.width_mm)
        top = min(max(top, area.y_mm), levels.ground_mm - manifest.height_mm)
        # Il posto giusto e' quello; se ci sta gia' qualcuno ci si allontana
        # **in avanti lungo la tubazione**, mai all'indietro: tornare indietro
        # scavalcherebbe il pezzo precedente della catena, e la fila si
        # leggerebbe al contrario. E' successo: cercando il primo posto libero,
        # un raccordo e' finito trenta millimetri **prima** della confluenza che
        # lo precede.
        # Chi sta su una tubazione si allinea **all'attacco che lo alimenta**:
        # e' la regola che toglie due pieghe per pezzo, e vale per un raccordo
        # quanto per una macchina. Solo se quella quota non esiste si tiene
        # quella interpolata lungo la campata.
        aligned = aligned_top(component_id, left, area.y_mm)
        if aligned is not None:
            top = aligned
        base_left, base_top = left, top
        # Avanti lungo la tubazione, che tiene l'ordine della fila; e se avanti
        # non c'e' posto, indietro — **due simboli non si sovrappongono mai**,
        # e un ordine invertito e' un difetto minore di due pezzi disegnati uno
        # sull'altro.
        # I corridoi davanti alle porte sono **locali** (I-046): si preferisce
        # un posto fuori dai rettilinei delle catene, ma se lungo la tubazione
        # non ce n'e' nessuno il pezzo si siede lo stesso, fuori dagli altri
        # simboli. Prima il corridoio murava la posa — la cascata di tre
        # macchine non si posava piu' — e una posa che non c'e' non la
        # migliora nessuno; una posa che stringe una catena la scarta il
        # ciclo, e prova a spostare le macchine.
        # E si resta **fra i due pezzi grossi** che la tratta unisce (D-120):
        # un raccordo che scivola oltre il capo della campata finisce dalla
        # parte sbagliata della macchina, e la fila si legge al contrario.
        # Solo se dentro la campata non c'e' posto nemmeno fra i simboli si
        # esce, che e' meglio di due pezzi uno sull'altro.
        # L'ordine dei ripieghi. Il posto del raccordo e' **dentro la campata**
        # fra i due pezzi grossi che la sua tratta unisce (D-120): fuori di li'
        # la tratta torna indietro a prenderlo. Ma il rettilineo che una catena
        # pretende davanti a una porta e' un contratto duro (I-044) —
        # occuparlo rende la posa non instradabile — mentre uscire di poco
        # dalla campata e' un difetto che il ciclo paga e corregge. Percio':
        # dentro e fuori dai corridoi; poi fuori dalla campata, ma sempre fuori
        # dai corridoi; e solo alla fine dentro un corridoio.
        seated = False
        horizontal = along[0] != 0.0
        for within_the_span, respecting_corridors in (
            (True, True),
            (False, True),
            (True, False),
            (False, False),
        ):
            if seated or (within_the_span and span is None):
                continue
            # **Il posto piu' vicino a quello giusto**, non il primo che si
            # incontra andando avanti: si allarga un passo per volta da dove
            # il pezzo dovrebbe stare, provando prima il verso di percorrenza.
            # Cercando fino in fondo in una direzione sola, un raccordo che
            # non trovava posto avanti finiva all'altro capo della tavola.
            for distance in range(int(max(area.width_mm, area.height_mm) / step)):
                if seated:
                    break
                for direction in (forward, -forward):
                    moved_left = base_left + along[0] * distance * direction
                    moved_top = base_top + along[1] * distance * direction
                    if (
                        moved_left < area.x_mm - 1e-9
                        or moved_left + manifest.width_mm > area.right_mm + 1e-9
                        or moved_top < area.y_mm - 1e-9
                        or moved_top + manifest.height_mm > levels.ground_mm + 1e-9
                    ):
                        continue
                    if within_the_span and span is not None:
                        low = moved_left if horizontal else moved_top
                        high = low + (manifest.width_mm if horizontal else manifest.height_mm)
                        if low < min(span) - 1e-9 or high > max(span) + 1e-9:
                            continue
                    free = (
                        free_of_symbols(
                            moved_left, moved_top, manifest.width_mm, manifest.height_mm
                        )
                        and not hanging_is_walled(component_id, moved_left, moved_top)
                        if respecting_corridors
                        else free_of_boxes(
                            moved_left, moved_top, manifest.width_mm, manifest.height_mm
                        )
                    )
                    if free:
                        left, top, seated = moved_left, moved_top, True
                        break
                    if distance == 0:
                        break
        # Ultimo ripiego, prima di arrendersi: **accanto** alla tubazione invece
        # che lungo di essa. La tratta ci arriva con una piega in piu' — e il
        # ciclo la paga e la corregge — ma un pezzo posato accanto al proprio
        # tubo e' sempre meglio di una tavola che non si posa (I-046, criterio
        # 11). Non si sovrappone comunque a nessuno.
        if not seated:
            aside = (0.0, step) if horizontal else (step, 0.0)
            for distance in range(1, int(max(area.width_mm, area.height_mm) / step)):
                for sign in (-1.0, 1.0):
                    moved_left = base_left + aside[0] * distance * sign
                    moved_top = base_top + aside[1] * distance * sign
                    if (
                        moved_left < area.x_mm - 1e-9
                        or moved_left + manifest.width_mm > area.right_mm + 1e-9
                        or moved_top < area.y_mm - 1e-9
                        or moved_top + manifest.height_mm > levels.ground_mm + 1e-9
                    ):
                        continue
                    if free_of_boxes(
                        moved_left, moved_top, manifest.width_mm, manifest.height_mm
                    ):
                        left, top, seated = moved_left, moved_top, True
                        break
                if seated:
                    break
        if not seated:
            raise LayoutError(
                f"component {component_id} sits on a run and finds no free spot "
                f"along it: symbols are never shrunk to fit, give the run room"
            )
        placed.append(
            PlacedSymbol(
                component_id=component_id,
                symbol_id=manifest.id,
                rotation_deg=rotation_for(component_id),
                origin=Point(x_mm=left, y_mm=top),
                width_mm=manifest.width_mm,
                height_mm=manifest.height_mm,
                tag=tags.get(component_id),
                port_flows=resolved[component_id].glyph_flows,
            )
        )
        boxes.append((left, top, left + manifest.width_mm, top + manifest.height_mm))
        settled[component_id] = placed[-1]
        hang(component_id, left, top)
        return placed[-1]

    def chain_rank(item: str) -> int:
        return process.position.get(item, 0)

    for chain in chains:
        ends = [
            place for place in (centre_of(item) for item in chain.anchors)
            if place is not None
        ]
        if len(ends) < 2:
            raise LayoutError(
                f"the run pieces {chain.members} sit between {chain.anchors}, "
                f"which were never placed: a junction needs the pieces it joins"
            )
        # I capi della campata sono i due estremi **piu' lontani**: se una
        # confluenza unisce due macchine affiancate a un accumulo, la campata e'
        # quella che va dalle macchine all'accumulo, non quella fra le due
        # macchine.
        # `capo` e `coda` si chiamavano `first` e `last`, e in questa
        # funzione quei due nomi erano gia' presi da due **identificativi**
        # (riga 1370): `mypy --strict` ne deduceva `str` e segnalava undici
        # errori su questo blocco. Sono rinominati qui, e **niente altro**
        # cambia: il difetto era nei nomi, non nel conto (DRAW-015).
        capo = min(ends, key=lambda place: (place[0], place[1]))
        coda = max(ends, key=lambda place: (place[0], place[1]))
        horizontal = abs(coda[0] - capo[0]) >= abs(coda[1] - capo[1])
        along = (step, 0.0) if horizontal else (0.0, step)
        # La catena si percorre dal capo attaccato all'estremo da cui parte la
        # campata, o la fila si legge al contrario.
        members = chain.members
        head_ids = set(chain.head_anchors)
        head = [
            place
            for place in (centre_of(item) for item in sorted(head_ids, key=chain_rank))
            if place is not None
        ]
        if head and min(
            abs(place[0] - capo[0]) + abs(place[1] - capo[1]) for place in head
        ) > (abs(coda[0] - capo[0]) + abs(coda[1] - capo[1])) / 2.0:
            members = tuple(reversed(members))
            head_ids = {
                item for item in chain.anchors if item not in chain.head_anchors
            } or head_ids
        # **La campata si misura sui bordi, non sui centri.** Fra due pompe di
        # calore affiancate il centro della piu' lontana sta dietro l'altra, e
        # la catena partiva da li': il primo raccordo si ritrovava a dieci
        # millimetri dalla macchina, e la valvola di intercettazione della sua
        # tratta non aveva dove sedersi.
        tail_ids = {item for item in chain.anchors if item not in head_ids} or head_ids
        head_placed = [
            settled[item] for item in sorted(head_ids, key=chain_rank) if item in settled
        ]
        tail_placed = [
            settled[item] for item in sorted(tail_ids, key=chain_rank) if item in settled
        ]
        if head_placed and tail_placed:
            capo, coda = _facing_edges(
                head_placed, tail_placed, horizontal=horizontal
            )
        span_x, span_y = coda[0] - capo[0], coda[1] - capo[1]
        # Lo spazio non si divide in parti uguali: si divide **secondo il
        # bisogno**. Ogni tratta della catena porta i propri accessori in linea
        # e vuole il proprio rettilineo; una tratta vuota non vuole niente.
        # Dividere a passi uguali dava dieci millimetri a chi ne chiedeva
        # quindici e quindici a chi non ne chiedeva nessuno, e l'accessorio non
        # trovava dove sedersi.
        # I membri si posano **per passo di percorrenza** (DRAW-005-R1): due
        # rami paralleli — i raccordi delle sicurezze di due macchine in
        # parallelo — stanno allo stesso passo e prendono la stessa ascissa
        # lungo la campata, ciascuno alla quota del proprio attacco; il
        # cursore avanza solo quando il passo cambia. Lungo un cammino
        # semplice ogni pezzo e' un passo, ed e' la fila di prima.
        steps = chain.levels if len(chain.levels) == len(members) else tuple(
            range(1, len(members) + 1)
        )
        if members != chain.members:
            steps = tuple(reversed(steps))
        groups: list[list[str]] = []
        for component_id, step_of_member in zip(members, steps, strict=True):
            if groups and steps[members.index(groups[-1][0])] == step_of_member:
                groups[-1].append(component_id)
            else:
                groups.append([component_id])
        sizes = [
            max(
                manifests[item].width_mm if horizontal else manifests[item].height_mm
                for item in group
            )
            for group in groups
        ]
        stops: tuple[tuple[str, ...], ...] = (chain.head_anchors, *(tuple(group) for group in groups))
        loads = [
            max(
                (room_between(item, other) for item in stops[index] for other in group),
                default=0.0,
            )
            for index, group in enumerate((*(tuple(group) for group in groups), tuple(chain.anchors)))
        ]
        # Fra due pezzi in fila non si scende sotto lo stacco fra pezzi, anche
        # se la tratta fra loro e' vuota: appoggiati l'uno all'altro, il
        # secondo scappava in verticale per trovare posto e la dorsale
        # piegava due volte.
        needs = [max(item, ROW_GAP_MM) for item in loads]
        span_mm = abs(span_x) if horizontal else abs(span_y)
        wanted = sum(sizes) + sum(needs)
        scale = min(1.0, span_mm / wanted) if wanted > 0 else 1.0
        # Lo spazio che avanza va **dove c'e' qualcosa da posare** (I-046): a
        # una tratta che porta accessori, non fra due raccordi che non hanno
        # nulla in mezzo. Prima si divideva in parti uguali, e il raccordo
        # della sicurezza finiva a meta' strada fra la confluenza a cui e'
        # attaccato e la valvola della riserva: attaccato a nulla. Se nessuna
        # tratta chiede niente, si divide come prima.
        loaded = [index for index, need in enumerate(loads) if need > 0.0]
        spare_total = max(0.0, span_mm - wanted)
        spares = [
            spare_total / len(loaded) if index in loaded else 0.0
            if loaded
            else spare_total / (len(needs) or 1)
            for index in range(len(needs))
        ]
        forward = 1 if (span_x if horizontal else span_y) >= 0 else -1
        cursor = 0.0
        for index, group in enumerate(groups):
            # La fila conserva l'ordine: un membro non torna indietro oltre
            # dove il precedente e' finito, e non scavalca il capo della
            # campata.
            behind = (capo[0] if horizontal else capo[1]) + forward * cursor
            ahead = coda[0] if horizontal else coda[1]
            cursor += needs[index] * scale + spares[index]
            share = (cursor + sizes[index] / 2.0) / span_mm if span_mm else 0.5
            reached = cursor + sizes[index] * scale
            for component_id in group:
                item = settle_on_the_run(
                    component_id,
                    capo[0] + span_x * share,
                    capo[1] + span_y * share,
                    along,
                    forward,
                    (behind, ahead),
                )
                # Il cursore riparte da **dove il pezzo e' finito davvero**, non
                # da dove lo si voleva: se ha dovuto scansare qualcuno, chi
                # viene dopo ne tiene conto invece di ripetere lo scarto.
                reached = max(
                    reached,
                    (item.right_mm if forward > 0 else -item.origin.x_mm) - capo[0] * forward
                    if horizontal
                    else (item.bottom_mm if forward > 0 else -item.origin.y_mm)
                    - capo[1] * forward,
                )
            cursor = reached

    return placed


# ---------------------------------------------------------------------------
# Cio' che il miglioratore legge della posa (DRAW-002)
#
# Il ciclo che rivede la disposizione muove **figure**, non pezzi: chi pende da
# uno stacco viaggia col proprio pezzo, e una catena di raccordi sulla tratta si
# rimette in fila tutta insieme. Le tre letture che gli servono sono le stesse
# con cui questo modulo posa, esposte qui perche' non vengano riscritte in due
# modi diversi.
# ---------------------------------------------------------------------------


def stub_minimum_mm(
    project: ProjectModel,
    catalog: ComponentRegistry,
    trunk: Trunk,
    horizontal: bool,
    step_mm: float,
) -> float:
    """Quanto e' lungo uno stacco: **il minimo su griglia**, e non un franco (I-046).

    Il PO: «gli stacchi degli accessori sono troppo lunghi». Uno stacco vuoto
    — la sicurezza, lo sfogo, il vaso, il manometro senza organi in mezzo —
    e' lungo **due passi**: la cella riservata davanti all'attacco del
    raccordo e quella davanti all'attacco di chi pende (D-113), ciascuna
    libera dall'altro simbolo — con un passo solo i due attacchi si
    dividerebbero la stessa cella, e uno dei due si siederebbe sulla soglia
    dell'altro. E' anche la distanza con cui due simboli si leggono come due.
    Uno stacco con organi in mezzo — la valvola del manometro, del gruppo di
    riempimento, del vaso — e' lungo quanto la fila dei pezzi fra le **due
    soglie**: da ciascun attacco la soglia piu' un passo, perche' un simbolo
    che tocca il nodo della soglia la occupa (D-113, D-120), poi ogni pezzo
    con un passo dal vicino. E' la stessa distanza fissa che la catena della
    macchina tiene dalla porta (I-044), letta da tutti e due i capi: lo
    stacco ha una porta a ciascun capo. Ogni millimetro oltre questo e'
    lunghezza di tubo, e la lunghezza costa: e' il ciclo che decide se
    allungarlo, non una costante.
    """
    if trunk.inline_component_ids:
        # La fila dalla porta di chi pende, passo di coda compreso; al posto
        # del passo di coda, la soglia piu' un passo dell'altra porta.
        room = (
            chain_room_mm(project, catalog, trunk.inline_component_ids, horizontal)
            - MIN_SPACING_MM
            + CHAIN_PORT_GAP_MM
        )
    else:
        room = 0.0
    wanted = max(2 * step_mm, room)
    return ceil(wanted / step_mm - 1e-9) * step_mm


CapiDelleTratte = dict[tuple[str, str], tuple[Trunk, bool]]
"""Ogni attacco che fa da capo a una tratta: la tratta e se ne e' l'inizio."""


def capi_delle_tratte(trunks: Sequence[Trunk]) -> CapiDelleTratte:
    """Gli attacchi che fanno da capo alle tratte, ciascuno con la **prima** tratta che
    lo tocca, e con l'inizio prima della fine: lo stesso ordine in cui
    `chain_room_of_port_mm` le scorreva una per una.

    **Misurato il 3 ottobre 2026** (REL-009, punto 7): sul caso reale — 137 tratte — la
    posa d'inventario chiedeva la catena di un attacco 460 mila volte, e ogni domanda
    rileggeva tutte le tratte confrontando gli attacchi come modelli: 74 milioni di
    confronti, quasi tutto il minuto e mezzo del disegna. Letti una volta in un indice,
    la risposta e' la stessa.
    """
    found: CapiDelleTratte = {}
    for trunk in trunks:
        found.setdefault((trunk.start.component_id, trunk.start.port_id), (trunk, True))
        found.setdefault((trunk.end.component_id, trunk.end.port_id), (trunk, False))
    return found


def chain_room_of_port_mm(
    project: ProjectModel,
    catalog: ComponentRegistry,
    trunks: Sequence[Trunk],
    ref: PortRef,
    horizontal: bool,
    capi: CapiDelleTratte | None = None,
) -> float:
    """Il rettilineo che la catena della macchina occupa da quell'attacco
    (I-044): lo stesso che l'instradatore imporra' uscendo dalla porta. Zero
    dove l'attacco non regge una catena.

    `capi` e' l'indice di `capi_delle_tratte` per quelle stesse tratte, per chi lo
    chiede per molti attacchi di fila."""
    capo = (capi if capi is not None else capi_delle_tratte(trunks)).get(
        (ref.component_id, ref.port_id)
    )
    if capo is None:
        return 0.0
    trunk, inizio = capo
    head, tail = machine_chains(project, catalog, trunk)
    return chain_room_mm(project, catalog, head if inizio else tail, horizontal)


StanzeDelleCatene = dict[tuple[str, str, bool], float]
"""Il rettilineo della catena di ogni attacco gia' chiesto — `(pezzo, attacco,
orizzontale)` —, per chi chiede i corridoi molte volte con le stesse tratte."""


def port_corridors(
    project: ProjectModel,
    catalog: ComponentRegistry,
    trunks: Sequence[Trunk],
    placed: Sequence[PlacedSymbol],
    step_mm: float,
    stanze: StanzeDelleCatene | None = None,
) -> list[tuple[float, float, float, float]]:
    """Il rettilineo che la catena della macchina pretende davanti a ogni
    attacco gia' posato (I-044), come aree `(x0, y0, x1, y1)` da lasciare libere.

    L'instradatore fara' uscire la tratta dritta dalla porta per quel tratto:
    un simbolo posato li' — un accessorio appeso a un raccordo, un vicino —
    la murerebbe, e la posa non sarebbe una candidata. Meglio non posarcelo.
    Una cella per lato, come la corsia della linea. Sono aree **locali**: si
    stendono davanti alla porta e non oltre, e non deformano la composizione
    (I-046) — chi non ci sta si allontana lungo il proprio stacco, e il ciclo
    poi paga o compra quella lunghezza.
    """
    return list(
        port_corridors_by_port(project, catalog, trunks, placed, step_mm, stanze).values()
    )


def port_corridors_by_port(
    project: ProjectModel,
    catalog: ComponentRegistry,
    trunks: Sequence[Trunk],
    placed: Sequence[PlacedSymbol],
    step_mm: float,
    stanze: StanzeDelleCatene | None = None,
) -> dict[tuple[str, str], tuple[float, float, float, float]]:
    """Gli stessi corridoi di `port_corridors`, ciascuno col proprio attacco:
    `(pezzo, attacco fisico)`.

    Serve a chi deve sapere **di chi** e' un corridoio: il corridoio davanti
    alla porta di un appeso sta **lungo il suo stesso stacco**, e per l'appeso
    non e' un posto occupato — e' la strada da cui arriva (A4).

    `stanze` lo passa chi chiede i corridoi molte volte con lo stesso modello e
    le stesse tratte — la posa, a ogni posto che prova —: la catena di un attacco
    non cambia da una domanda all'altra, e si conta una volta (REL-009, punto 7).
    """
    definitions = {item.id: item.definition_id for item in project.components}
    capi = capi_delle_tratte(trunks)
    found: dict[tuple[str, str], tuple[float, float, float, float]] = {}
    for item in placed:
        manifest = catalog.resolve(definitions[item.component_id]).symbol.manifest.rotated(
            item.rotation_deg, item.specchiato
        )
        for port in manifest.ports:
            horizontal = port.face in (PortFace.LEFT, PortFace.RIGHT)
            chiave = (item.component_id, port.id, horizontal)
            room = stanze.get(chiave) if stanze is not None else None
            if room is None:
                ref = PortRef(component_id=item.component_id, port_id=port.id)
                room = chain_room_of_port_mm(project, catalog, trunks, ref, horizontal, capi)
                if stanze is not None:
                    stanze[chiave] = room
            if room <= 0:
                continue
            # Le celle obbligate, la cella in cui la tratta gira, e il bordo
            # del vicino che conta come cella occupata: due passi in piu'.
            room += 2 * step_mm
            px, py = item.origin.x_mm + port.x_mm, item.origin.y_mm + port.y_mm
            key = (item.component_id, port.id)
            if port.face is PortFace.RIGHT:
                found[key] = (px, py - step_mm, px + room, py + step_mm)
            elif port.face is PortFace.LEFT:
                found[key] = (px - room, py - step_mm, px, py + step_mm)
            elif port.face is PortFace.BOTTOM:
                found[key] = (px - step_mm, py, px + step_mm, py + room)
            else:
                found[key] = (px - step_mm, py - room, px + step_mm, py)
    return found


def inline_room_mm(
    project: ProjectModel, catalog: ComponentRegistry, inline_ids: tuple[str, ...]
) -> float:
    """Il rettilineo che gli accessori in linea di una tratta pretendono.

    E' lo stesso conto che `inline.py` fara' dopo l'instradamento: ogni
    accessorio vuole la propria interruzione piu' uno stacco dal vicino, e la
    fila intera vuole due stacchi dai componenti agli estremi. Una tratta senza
    accessori non pretende niente.
    """
    accessories = [item for item in project.components if item.id in inline_ids]
    if not accessories:
        return 0.0
    return sum(
        (catalog.resolve(item.definition_id).symbol.manifest.inline_gap_mm or 0.0)
        + 2 * MIN_SPACING_MM
        for item in accessories
    ) + 2 * END_CLEARANCE_MM


def hanging_children(
    project: ProjectModel,
    partition: SheetPartition,
    catalog: ComponentRegistry,
    placeable: frozenset[str],
) -> dict[str, tuple[tuple[str, str], ...]]:
    """Chi pende da uno stacco, per pezzo che lo regge: `(figlio, attacco)`.

    Lo stesso criterio della posa (D-101): chi sta all'altro capo di un attacco
    fuori dal percorso del fluido, e ha un attacco solo, e' un accessorio appeso
    e si muove col proprio pezzo.
    """
    found = _hanging_accessories(
        project, partition, catalog, placeable, lambda _trunk, _horizontal: 0.0
    )
    return {
        parent: tuple((item.component_id, item.parent_port_id) for item in items)
        for parent, items in found.items()
    }


def hanging_ports(
    project: ProjectModel,
    partition: SheetPartition,
    catalog: ComponentRegistry,
    placeable: frozenset[str],
) -> dict[str, str]:
    """Per ogni appeso, **il proprio** attacco con cui pende.

    Non e' sempre il primo del manifesto: un ponte fra due reti ne ha due e
    pende da quello in cui sbocca. Chi lo riappende deve sapere quale, o lo
    rimette allineato sull'attacco sbagliato e il pezzo scivola dalla parte
    opposta del proprio stacco (DRAW-006-R1, blocco D).
    """
    found = _hanging_accessories(
        project, partition, catalog, placeable, lambda _trunk, _horizontal: 0.0
    )
    return {
        item.component_id: item.port_id
        for items in found.values()
        for item in items
    }


def run_chains(
    project: ProjectModel,
    partition: SheetPartition,
    catalog: ComponentRegistry,
    placeable: frozenset[str],
) -> list[tuple[str, ...]]:
    """Le catene di pezzi che stanno sulla tratta fra due pezzi grossi (D-120).

    In ordine di percorrenza, come la posa le legge: un raccordo non e' un passo
    del processo e si rimette in fila con i suoi compagni di tratta.
    """
    functions_of = {
        item.id: frozenset(catalog.resolve(item.definition_id).definition.functions)
        for item in project.components
    }
    media_of = {
        item.id: frozenset(
            port.medium for port in catalog.get(item.definition_id).ports
        )
        for item in project.components
    }
    hung = frozenset(
        child
        for items in hanging_children(project, partition, catalog, placeable).values()
        for child, _ in items
    )
    rank = _file_order(project)

    def stage(component_id: str) -> int:
        """Lo stesso passo di processo con cui `place_sheet` legge le fasce:
        chi genera, chi accumula, chi utilizza, il resto."""
        functions = functions_of.get(component_id, frozenset())
        if functions & GENERATOR_FUNCTIONS:
            return 0
        if functions & STORE_FUNCTIONS:
            return 1
        if functions & LOAD_FUNCTIONS:
            return 2
        return 3

    chains = _pieces_on_the_run(
        partition,
        placeable,
        hung,
        lambda item: bool(functions_of.get(item, frozenset()) & ZONED_FUNCTIONS),
        lambda item: rank.get(item, 0),
        stage,
        lambda item: len(media_of.get(item, frozenset())) > 1,
    )
    return [chain.members for chain in chains]
