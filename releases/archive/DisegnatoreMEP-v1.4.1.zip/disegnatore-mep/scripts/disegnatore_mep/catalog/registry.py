from pathlib import Path

from pydantic import ValidationError

from disegnatore_mep.graphics.registry import SymbolRegistry
from disegnatore_mep.model.types import PortFlow

from .errors import CatalogError
from .resolved import ResolvedComponent
from .schema import ComponentDefinition

# CatalogError vive in .errors, ma resta esportato da qui: e' il nome con cui
# il resto del progetto lo importa da quando esisteva un solo modulo a sollevarlo.
__all__ = ["CatalogError", "ComponentRegistry", "ResolvedComponent"]


class ComponentRegistry:
    def __init__(
        self,
        definitions: list[ComponentDefinition],
        symbols: SymbolRegistry | None = None,
    ) -> None:
        self._symbols = symbols
        self._definitions: dict[str, ComponentDefinition] = {}
        for definition in definitions:
            if definition.id in self._definitions:
                raise CatalogError(f"duplicate component definition: {definition.id}")
            if symbols is not None:
                self._check_symbol(definition, symbols)
            self._definitions[definition.id] = definition
        for definition in self._definitions.values():
            self._check_variant(definition)

    def _check_variant(self, definition: ComponentDefinition) -> None:
        """Una variante e' la stessa macchina della sua voce base (D-188).

        Stessi mestieri e stessi attacchi — e' quello che rende la scelta una
        questione di parole del testo e non di collegamenti —, un simbolo
        diverso, e una base che non sia a sua volta una variante: altrimenti
        chi sceglie non saprebbe da quale voce partire."""
        variant = definition.variant
        if variant is None:
            return
        base = self._definitions.get(variant.of)
        if base is None:
            raise CatalogError(
                f"{definition.id} e' variante di {variant.of}, che non e' nel catalogo"
            )
        if base.variant is not None:
            raise CatalogError(
                f"{definition.id} e' variante di {variant.of}, che e' a sua volta una "
                f"variante: la voce base dev'essere una sola"
            )
        if set(base.functions) != set(definition.functions):
            raise CatalogError(
                f"{definition.id} e' variante di {variant.of} ma non fa gli stessi "
                f"mestieri: {sorted(definition.functions)} contro {sorted(base.functions)}"
            )
        ports = sorted(definition.ports, key=lambda item: item.id)
        if ports != sorted(base.ports, key=lambda item: item.id):
            raise CatalogError(
                f"{definition.id} e' variante di {variant.of} ma non ha gli stessi "
                f"attacchi: una variante si collega come la sua voce base"
            )
        if base.symbol_id == definition.symbol_id:
            raise CatalogError(
                f"{definition.id} e' variante di {variant.of} con lo stesso simbolo: "
                f"una variante esiste per disegnarsi diversa"
            )

    @staticmethod
    def _check_symbol(definition: ComponentDefinition, symbols: SymbolRegistry) -> None:
        if not symbols.contains(definition.symbol_id):
            raise CatalogError(
                f"unknown symbol {definition.symbol_id} for {definition.id}"
            )
        manifest = symbols.get(definition.symbol_id).manifest
        if definition.port_ids != manifest.port_ids:
            raise CatalogError(
                f"port ids do not match symbol {definition.symbol_id} "
                f"for {definition.id}: {sorted(definition.port_ids)} "
                f"vs {sorted(manifest.port_ids)}"
            )

    @classmethod
    def from_directory(
        cls, directory: Path, symbols: SymbolRegistry | None = None
    ) -> "ComponentRegistry":
        if not directory.is_dir():
            raise CatalogError(f"catalog directory not found: {directory}")
        definitions: list[ComponentDefinition] = []
        for path in sorted(directory.glob("*.json")):
            try:
                definitions.append(
                    ComponentDefinition.model_validate_json(path.read_text("utf-8"))
                )
            except (OSError, ValidationError, ValueError) as exc:
                raise CatalogError(f"invalid catalog file {path}: {exc}") from exc
        # Duplicate detection stays outside the loop: CatalogError subclasses
        # ValueError, so raising it inside would be re-wrapped by the except above.
        return cls(definitions, symbols)

    def get(self, definition_id: str) -> ComponentDefinition:
        try:
            return self._definitions[definition_id]
        except KeyError as exc:
            raise CatalogError(f"unknown component definition: {definition_id}") from exc

    def contains(self, definition_id: str) -> bool:
        return definition_id in self._definitions

    def all(self) -> tuple[ComponentDefinition, ...]:
        return tuple(self._definitions[key] for key in sorted(self._definitions))

    def serving(self, function: str, medium: str) -> tuple[ComponentDefinition, ...]:
        """Le voci che portano quella funzione su quel fluido, in ordine.

        «Su quel fluido» vuol dire **tutte** le porte su quel fluido: un
        accessorio si cala dentro una tubazione, e una voce con una porta su
        un altro fluido non ci sta dentro — e' una macchina che li mette in
        comunicazione, non un pezzo da infilare in una tratta.
        """
        return tuple(
            definition
            for definition in self.all()
            if function in definition.functions
            and all(port.medium == medium for port in definition.ports)
        )

    def bridging(
        self, function: str, source_medium: str, target_medium: str
    ) -> tuple[ComponentDefinition, ...]:
        """Le voci che portano quella funzione **da** un fluido **a** un altro.

        E' l'altra meta' di `serving`, e le due non si sovrappongono: li' tutte
        le porte stanno sullo stesso fluido, perche' il pezzo si cala dentro una
        tubazione; qui il pezzo e' un ponte, entra da un fluido e esce
        sull'altro, e nessuna tubazione lo contiene. Il verso e' parte
        dell'identita': si entra da una porta che **entra** sul fluido di
        partenza e si esce da una che **esce** su quello di arrivo.
        """
        if source_medium == target_medium:
            return ()
        return tuple(
            definition
            for definition in self.all()
            if function in definition.functions
            and {port.medium for port in definition.ports}
            == {source_medium, target_medium}
            and any(
                port.medium == source_medium and port.flow is PortFlow.IN
                for port in definition.ports
            )
            and any(
                port.medium == target_medium and port.flow is PortFlow.OUT
                for port in definition.ports
            )
        )

    def bridge(
        self, function: str, source_medium: str, target_medium: str
    ) -> ComponentDefinition:
        """L'unica voce che porta quella funzione da un fluido all'altro."""
        found = self.bridging(function, source_medium, target_medium)
        if not found:
            raise CatalogError(
                f"no catalogue definition bridges {function!r} from "
                f"{source_medium!r} to {target_medium!r}"
            )
        if len(found) > 1:
            raise CatalogError(
                f"{len(found)} catalogue definitions bridge {function!r} from "
                f"{source_medium!r} to {target_medium!r} "
                f"({', '.join(item.id for item in found)}): which one a rule "
                f"means would be the programme's choice, not the catalogue's"
            )
        return found[0]

    def providing(self, function: str, medium: str) -> ComponentDefinition:
        """L'unica voce che porta quella funzione su quel fluido.

        E' cio' che tiene **una** regola dove prima ce n'erano tre, una per
        fluido: la regola dice quale funzione deve comparire, il catalogo dice
        con quale pezzo si ottiene sull'acqua di riscaldamento, sulla fredda o
        sulla sanitaria. Se le voci sono zero o piu' d'una la scelta sarebbe
        del programma, e allora si ferma invece di sceglierne una.

        **Una variante non la propone mai una regola** (D-188): si sceglie solo
        quando il testo la nomina. Lo sfiato senza rubinetto fa il mestiere dello
        sfiato con il rubinetto, e la regola che vuole uno sfogo d'aria propone il
        secondo (I-211).
        """
        found = tuple(item for item in self.serving(function, medium) if item.variant is None)
        if not found:
            raise CatalogError(
                f"no catalogue definition provides {function!r} on {medium!r}: a "
                f"rule that asks for it would have nothing to propose"
            )
        if len(found) > 1:
            raise CatalogError(
                f"{len(found)} catalogue definitions provide {function!r} on "
                f"{medium!r} ({', '.join(item.id for item in found)}): which one "
                f"a rule means would be the programme's choice, not the "
                f"catalogue's"
            )
        return found[0]

    def resolve(self, definition_id: str) -> ResolvedComponent:
        """La definizione insieme alla propria geometria.

        Richiede la libreria dei simboli. Resta separato da `get` perche'
        `symbols` e' opzionale per scelta: il validatore topologico lavora sulla
        sola semantica e non deve pretendere la libreria sotto mano.
        """
        if self._symbols is None:
            raise CatalogError(
                f"cannot resolve {definition_id}: the catalog was loaded without a "
                f"symbol library; pass symbols=SymbolRegistry.from_directory(...) "
                f"to ComponentRegistry.from_directory"
            )
        definition = self.get(definition_id)
        return ResolvedComponent(
            definition=definition, symbol=self._symbols.get(definition.symbol_id)
        )
