"""Il preflight di qualita': non «questa tavola sta in piedi?» ma «e' disegnata bene?».

`geometry.py` misura la **correttezza** — simboli sovrapposti, testi addosso ai
pezzi, segmenti obliqui, oggetti fuori area, rimandi spaiati — e blocca. Questo
modulo misura la **qualita'**: le righe che `docs/QUALITA_GRAFICA.md` marca «da
misurare», cioe' il livello 1 della verifica a tre livelli di D-063, il
preflight deterministico che gira dentro la pipeline e non nei test.

Ogni misura e' una funzione pura che riceve la geometria e restituisce
`ValidationIssue`, lo stesso tipo e la stessa scala di severita' del validatore
di correttezza: un difetto e' un difetto, e chi legge il rapporto non deve
imparare due lessici. `preflight_drawing` le esegue nell'ordine dichiarato da
`MEASURE_ORDER`, e l'ordine dell'esito e' quello.

Le soglie sono costanti nominate con la propria fonte accanto. Dove la fonte e'
una regola scritta — la carta del colpo d'occhio, una decisione del registro —
il commento la cita; dove il numero e' una **taratura**, il commento lo dichiara
tale, perche' un valore tarato si rivede sulle tavole reali e un valore normato
no (D-083: vietato inventare, e vietato far passare una taratura per una norma).
"""

import math
from collections.abc import Iterable

from disegnatore_mep.catalog.errors import CatalogError
from disegnatore_mep.catalog.registry import ComponentRegistry
from disegnatore_mep.diametri.tratti import tratti_da_etichettare
from disegnatore_mep.graphics.frame import ORDINARY_FRAMES, Rect, SheetFrame
from disegnatore_mep.layout.autostrade import (
    AutostradaInTavola,
    autostrade_del_progetto,
    e_autostrada,
    pieghe_della_tratta,
)
from disegnatore_mep.layout.diametri import (
    FRANCO_DELLA_STACCATA_EM,
    riquadri_delle_frecce,
    riquadro_del_diametro,
)
from disegnatore_mep.layout.geometry import (
    SHEET_FILL_MAX_RATIO,
    SHEET_MARGIN_MIN_MM,
    STACCO_DALLA_TABELLA_MM,
    DrawingGeometry,
    PlacedLabel,
    Point,
    RoutedTrunk,
    SheetGeometry,
    TabellaDelleApparecchiature,
    attaches_to,
    border_margin_mm,
    box_of,
    distance_to_box,
    fill_ratio,
    ink_area_mm2,
    margin_allowed_mm,
    moves_of,
    overshoot_mm,
    quadrants_of,
)
from disegnatore_mep.layout.labels import (
    ETICHETTA,
    LINE_CLEARANCE_MM,
    riquadro_della_scritta,
    riquadro_di_rispetto,
    segmenti_del_richiamo,
    segments_cross,
    text_width_mm,
)
from disegnatore_mep.model.project import ProjectModel
from disegnatore_mep.model.types import IssueSeverity

from .geometry import TOLERANCE_MM
from .issues import ValidationIssue

BENDS_PER_RUN_MAX = 3
"""Cambi di direzione ammessi su una tratta prima dell'avviso (B4, D-060).

Il numero viene dalla geometria, non da una taratura: per unire due porte su
una griglia ortogonale servono zero pieghe se sono allineate, una per una elle,
due per uno scarto, tre per la graffa fra due porte sulla stessa faccia. Oltre
la terza la piega non la chiede il collegamento: la chiede un ostacolo, cioe'
una posizione da correggere (D-078).
"""

SHARED_EDGES_MAX = 0
"""Spigoli di griglia percorsi da due tratte diverse: divieto, non costo (D-062).

«Vietato sovrapporre longitudinalmente le linee, sempre separate e ben
distinte.» Due linee sullo stesso tratto sono una linea sola: non e' una
penalita' da pagare, e' un esito bloccante.
"""

SHARED_EDGES_AT_A_SHARED_PORT = 1
"""L'unica eccezione che D-062 dichiara, trascritta alla lettera.

«Unica eccezione: l'ultimo tratto contro una porta condivisa da due tratte, che
sulla tavola e' una derivazione ed e' lungo un passo di griglia.» Vale solo se
lo spigolo condiviso e' uno e tocca una porta che e' capo di **entrambe** le
tratte: fuori da questa condizione la sovrapposizione resta bloccante.
"""

U_TURN_OVERSHOOT_MAX_MM = 0.0
"""Quanto una tratta puo' superare la propria porta di arrivo: niente (B12, D-078).

«La linea supera l'oggetto, scende e torna indietro a prenderlo. Va spostato
l'oggetto, non allungata la linea.» Tolleranza zero per costruzione.
"""

# Le due tarature del riempimento vivono accanto alla misura, in
# `layout.geometry`, perche' da D-111 le legge anche il collocatore: qui si
# guarda la tavola finita, li' si dispone per ottenerla, e il numero deve
# essere lo stesso. Il valore si rivede sulle tavole reali (carta, §«Come
# cresce questa carta», terza sorgente); l'esito resta un avviso proprio per
# questo.

NEXT_SHEET_FILL_MIN_RATIO = 0.40
"""Riempimento minimo di una tavola successiva alla prima (D-072, A2).

**Taratura**, ed e' il «riempimento minimo dichiarato» che D-072 chiede senza
fissarlo: «non ha senso separare in due fogli con il secondo completamente
vuoto». Sotto questa quota la seconda tavola sembra un ritaglio e doveva stare
sulla prima: esito bloccante, perche' D-072 e' un divieto di divisione, non un
consiglio.
"""

LEADER_ANGLE_DEG = 45
"""L'unica giacitura ammessa per un richiamo di etichetta (D-075, D2).

«Quando il testo non ci sta o interferisce, e solo allora, si allontana con un
richiamo **in diagonale a 45 gradi**.» Non e' una taratura: e' l'angolo che
nessuna tubazione puo' avere, ed e' per questo che e' stato scelto.
"""

INVENTED_SOURCE = "CONV-GRAFICA-001"
"""La convenzione grafica interna: una fonte inventata, non una fonte (D-081, D-083).

Un simbolo che la cita non ha una fonte vera: nessuna tavola normata, nessuno
schema di produttore, nessuna decisione del PM. E' esattamente il difetto che
WP1 ha chiuso, e questa misura impedisce che rientri.
"""

GRID_ROUNDING_DIGITS = 3
"""Cifre decimali con cui si arrotondano i nodi di griglia prima di confrontarli.

Serve a far coincidere due percorsi calcolati per strade diverse: senza, due
tratte sullo stesso spigolo non risultano sullo stesso spigolo per un errore in
fondo alla mantissa.
"""

QUADRANT_NAMES: tuple[str, ...] = (
    "in alto a sinistra",
    "in alto a destra",
    "in basso a sinistra",
    "in basso a destra",
)
"""I quattro quadranti dell'area di disegno, in ordine di lettura."""

MEASURE_ORDER: tuple[str, ...] = (
    "unresolved_runs",
    "bends_per_run",
    "longitudinal_overlap",
    "clearances",
    "u_turns",
    "orthogonality_of_leaders",
    "labels_on_runs",
    "leader_crossings",
    "omitted_tags",
    "omitted_free_labels",
    "diameter_tags",
    "text_spacing",
    "equipment_table",
    "sheet_fill",
    "next_sheet_fill",
    "symbol_sources",
)
"""L'ordine in cui `preflight_drawing` esegue le misure, e quindi l'ordine
dell'esito: prima **cio' che manca**, poi le linee, poi i testi, poi il foglio,
infine le fonti. La tratta non risolta apre l'elenco perche' e' l'unica che
dice che la tavola non e' finita (D-150), e non va cercata in fondo.
Dichiararlo qui rende l'ordine una scelta leggibile invece di un effetto della
sequenza delle chiamate.
"""


def _finding(
    code: str, severity: IssueSeverity, message: str, entity_ids: list[str]
) -> ValidationIssue:
    return ValidationIssue(
        code=code, severity=severity, message=message, entity_ids=entity_ids
    )


def _stretches(polyline: list[Point]) -> list[tuple[Point, Point]]:
    """Le coppie di punti consecutivi, degeneri comprese."""
    return list(zip(polyline, polyline[1:], strict=False))


# Quante volte la spezzata di una tratta cambia direzione lo conta
# `layout.autostrade.pieghe_della_tratta`, e lo conta **una volta sola**: da
# quando il controllo di B1 misura le stesse pieghe sulla catena intera, due
# implementazioni direbbero prima o poi due cose diverse sulla stessa tratta.


def _walk(before: Point, after: Point, ratio: float) -> tuple[float, float]:
    return (
        round(before.x_mm + (after.x_mm - before.x_mm) * ratio, GRID_ROUNDING_DIGITS),
        round(before.y_mm + (after.y_mm - before.y_mm) * ratio, GRID_ROUNDING_DIGITS),
    )


def _steps(before: Point, after: Point, grid_mm: float) -> int:
    span = abs(after.x_mm - before.x_mm) + abs(after.y_mm - before.y_mm)
    return int(round(span / grid_mm))


def _edges(
    polyline: list[Point], grid_mm: float
) -> set[tuple[tuple[float, float], tuple[float, float]]]:
    """Gli spigoli di griglia **percorsi**, non i nodi toccati.

    E' la distinzione fra un incrocio e una sovrapposizione: due tratte che si
    tagliano condividono un nodo, due tratte che corrono insieme condividono
    degli spigoli.
    """
    walked: set[tuple[tuple[float, float], tuple[float, float]]] = set()
    for before, after in _stretches(polyline):
        steps = _steps(before, after, grid_mm)
        for index in range(steps):
            first = _walk(before, after, index / steps)
            second = _walk(before, after, (index + 1) / steps)
            walked.add((first, second) if first <= second else (second, first))
    return walked


def _run_polylines(sheet: SheetGeometry) -> list[tuple[int, RoutedTrunk, list[Point]]]:
    """Ogni spezzata con la tratta cui appartiene, in ordine di dichiarazione."""
    return [
        (index, route, segment)
        for index, route in enumerate(sheet.routes)
        for segment in route.segments
    ]


def _run_name(route: RoutedTrunk) -> str:
    return ", ".join(route.connection_ids) if route.connection_ids else route.network_id


def _run_ids(sheet: SheetGeometry, route: RoutedTrunk) -> list[str]:
    return [sheet.sheet_id, *route.connection_ids]


def _clearance_severity(distance_mm: float, minimum_mm: float) -> IssueSeverity | None:
    """Sotto la distanza minima si blocca, esattamente sulla soglia si avvisa."""
    if distance_mm < minimum_mm - TOLERANCE_MM:
        return IssueSeverity.BLOCKING
    if distance_mm <= minimum_mm + TOLERANCE_MM:
        return IssueSeverity.WARNING
    return None


def _parallel_distance(
    first: tuple[Point, Point], second: tuple[Point, Point]
) -> float | None:
    """Distanza fra due tratti paralleli che corrono affiancati, altrimenti niente.

    Due tratti sono affiancati se hanno la stessa giacitura e le loro proiezioni
    sull'asse comune si sovrappongono per un tratto vero: due tubi allineati che
    si toccano in un punto non corrono affiancati, si incontrano.
    """
    horizontal = (
        abs(first[0].y_mm - first[1].y_mm) <= TOLERANCE_MM
        and abs(second[0].y_mm - second[1].y_mm) <= TOLERANCE_MM
    )
    vertical = (
        abs(first[0].x_mm - first[1].x_mm) <= TOLERANCE_MM
        and abs(second[0].x_mm - second[1].x_mm) <= TOLERANCE_MM
    )
    if horizontal:
        along = (first[0].x_mm, first[1].x_mm, second[0].x_mm, second[1].x_mm)
        across = abs(first[0].y_mm - second[0].y_mm)
    elif vertical:
        along = (first[0].y_mm, first[1].y_mm, second[0].y_mm, second[1].y_mm)
        across = abs(first[0].x_mm - second[0].x_mm)
    else:
        return None
    shared = min(max(along[0], along[1]), max(along[2], along[3])) - max(
        min(along[0], along[1]), min(along[2], along[3])
    )
    if shared <= TOLERANCE_MM:
        return None
    return across


def _rect(area: Rect) -> tuple[float, float, float, float]:
    """Il rettangolo come quaterna, che e' la forma che le misure condivise usano."""
    return (area.x_mm, area.y_mm, area.right_mm, area.bottom_mm)


def _fill_ratio(sheet: SheetGeometry, area: Rect) -> float:
    """Il riempimento della tavola, con la formula condivisa col collocatore.

    La misura vive in `layout.geometry` perche' da D-111 il collocatore la usa
    come **obiettivo** mentre dispone, e non basta che le due somiglino: devono
    essere la stessa (e' la lezione dell'andata e ritorno, misurata due volte
    con due formule diverse).
    """
    return fill_ratio(sheet.symbols, sheet.routes, _rect(area))


NOMI_DEI_FORMATI: tuple[str, ...] = ("A3", "A2", "A1")
"""I nomi dei formati ordinari, nell'ordine di `graphics.frame.ORDINARY_FRAMES`.

Sono gli stessi di `piano.formato.FORMATI_ORDINARI`: qui servono per **nominare**
il foglio piu' piccolo che conterrebbe il disegno (D3, **D-170**). Dal 25
settembre 2026 il piu' piccolo e' l'A3 (**D-186**): su un A3 questo rilievo non
si accende piu'.
"""


def _drawing_bounds(sheet: SheetGeometry) -> tuple[float, float, float, float] | None:
    """L'ingombro dell'inchiostro: simboli e tubazioni, niente cornice.

    `None` se la tavola e' vuota. Serve a D3 (**D-170**) per dire se il disegno
    ci starebbe su un foglio piu' piccolo — che dal 22 settembre 2026 e' **la
    sola cosa** che D3 misura.
    """
    x: list[float] = []
    y: list[float] = []
    for item in sheet.symbols:
        x.extend((item.origin.x_mm, item.right_mm))
        y.extend((item.origin.y_mm, item.bottom_mm))
    for route in sheet.routes:
        for parte in route.segments:
            for punto in parte:
                x.append(punto.x_mm)
                y.append(punto.y_mm)
    if not x:
        return None
    return (min(x), min(y), max(x), max(y))


def _quadrants(area: Rect) -> list[Rect]:
    return [
        Rect(x_mm=item[0], y_mm=item[1], width_mm=item[2] - item[0], height_mm=item[3] - item[1])
        for item in quadrants_of(_rect(area))
    ]


def _ink_area_mm2(sheet: SheetGeometry, area: Rect, line_mm: float) -> float:
    return ink_area_mm2(sheet.symbols, sheet.routes, _rect(area), line_mm)


def bends_per_run(
    drawing: DrawingGeometry, autostrade: Iterable[AutostradaInTavola] = ()
) -> list[ValidationIssue]:
    """B4 — una linea cambia direzione solo per una ragione.

    Si conta per **tratta**, non per spezzata: una tratta interrotta dai propri
    accessori in linea resta una tratta sola, e le sue pieghe si sommano.

    **La piega di un'autostrada non e' la piega di uno stacchetto** (**D-151**),
    e da **D-171** non si misura affatto qui. Una tratta di autostrada si
    giudica sulla **catena intera** e contro le pieghe che **i suoi simboli le
    impongono**: lo fa `regole.autostrade_storte`, che e' il controllo di **B1**
    e vede i crocevia. Contarla anche qui, per tratta e contro un numero,
    sarebbe contarla due volte e contro il metro sbagliato — fino al 22
    settembre 2026 il metro era `curve_ammesse`, zero o uno, che il PO ha
    tolto: «non c'e' un numero massimo».

    Resta quella di sempre per ogni **altra** tratta — le tre pieghe di **B4**,
    che il PO non ha toccato — ed e' la condizione che tiene in piedi le prove
    che la precedono.
    """
    findings: list[ValidationIssue] = []
    conosciute = tuple(autostrade)
    for sheet in drawing.sheets:
        for route in sheet.routes:
            if e_autostrada(route, conosciute) is not None:
                continue
            total = pieghe_della_tratta(route)
            if total <= BENDS_PER_RUN_MAX:
                continue
            findings.append(
                _finding(
                    "RUN_WITH_TOO_MANY_BENDS",
                    IssueSeverity.WARNING,
                    f"la tratta {_run_name(route)} cambia direzione {total} "
                    f"{'volta' if total == 1 else 'volte'}, oltre le "
                    f"{BENDS_PER_RUN_MAX} pieghe che bastano a unire due porte: "
                    f"la piega in piu' la chiede un ostacolo, e l'ostacolo si "
                    f"sposta (B4, D-078)",
                    _run_ids(sheet, route),
                )
            )
    return findings


def longitudinal_overlap(
    drawing: DrawingGeometry, frame: SheetFrame
) -> list[ValidationIssue]:
    """B2, D-062 — vietato sovrapporre longitudinalmente: divieto, non costo.

    Si misurano gli **spigoli** percorsi in comune, non i nodi toccati: due
    tratte che si tagliano condividono un nodo e non si sovrappongono. L'unica
    eccezione ammessa e' quella che D-062 dichiara — un solo passo di griglia
    contro una porta condivisa dalle due tratte, che sulla tavola e' una
    derivazione.
    """
    findings: list[ValidationIssue] = []
    grid_mm = frame.standard.grid_mm
    for sheet in drawing.sheets:
        walked = [
            (index, route, segment, _edges(segment, grid_mm))
            for index, route, segment in _run_polylines(sheet)
        ]
        for first in range(len(walked)):
            for second in range(first + 1, len(walked)):
                one, other = walked[first], walked[second]
                if one[0] == other[0]:
                    continue
                shared = one[3] & other[3]
                if len(shared) <= SHARED_EDGES_MAX:
                    continue
                if len(shared) <= SHARED_EDGES_AT_A_SHARED_PORT and _at_a_shared_port(
                    one[2], other[2], shared
                ):
                    continue
                findings.append(
                    _finding(
                        "RUNS_OVERLAP_LENGTHWISE",
                        IssueSeverity.BLOCKING,
                        f"le tratte {_run_name(one[1])} e {_run_name(other[1])} corrono "
                        f"sovrapposte per {len(shared) * grid_mm:g} mm: due linee sullo "
                        f"stesso tratto sono una linea sola (B2, D-062)",
                        sorted({*_run_ids(sheet, one[1]), *_run_ids(sheet, other[1])}),
                    )
                )
    return findings


def _at_a_shared_port(
    first: list[Point],
    second: list[Point],
    shared: set[tuple[tuple[float, float], tuple[float, float]]],
) -> bool:
    """L'eccezione di D-062: lo spigolo comune tocca una porta capo di entrambe."""
    ends = {
        (round(point.x_mm, GRID_ROUNDING_DIGITS), round(point.y_mm, GRID_ROUNDING_DIGITS))
        for point in (first[0], first[-1])
    } & {
        (round(point.x_mm, GRID_ROUNDING_DIGITS), round(point.y_mm, GRID_ROUNDING_DIGITS))
        for point in (second[0], second[-1])
    }
    return any(edge[0] in ends or edge[1] in ends for edge in shared)


def clearances(drawing: DrawingGeometry, frame: SheetFrame) -> list[ValidationIssue]:
    """B5, B6 — le linee non sfiorano i simboli e non si affiancano troppo.

    Sotto la distanza minima dello standard grafico si blocca; esattamente sulla
    soglia si avvisa, perche' un valore che tocca il limite lo supera al primo
    ritocco. La distanza zero fra due paralleli non si conta qui: quella e' una
    sovrapposizione, e la misura sua e' `longitudinal_overlap`.
    """
    findings: list[ValidationIssue] = []
    minimum = frame.standard.min_clearance_mm
    for sheet in drawing.sheets:
        findings.extend(_symbol_clearances(sheet, minimum))
        findings.extend(_parallel_clearances(sheet, minimum))
    return findings


def _symbol_clearances(sheet: SheetGeometry, minimum: float) -> list[ValidationIssue]:
    """B5 — le linee non sfiorano i simboli cui non si attaccano."""
    findings: list[ValidationIssue] = []
    for _, route, segment in _run_polylines(sheet):
        moves = moves_of(segment)
        if not moves:
            continue
        for symbol in sheet.symbols:
            box = box_of(symbol)
            if attaches_to(segment, box):
                continue
            gap = min(distance_to_box(before, after, box) for before, after in moves)
            severity = _clearance_severity(gap, minimum)
            if severity is None:
                continue
            findings.append(
                _finding(
                    "RUN_TOO_CLOSE_TO_A_SYMBOL",
                    severity,
                    f"la tratta {_run_name(route)} passa a {gap:g} mm dal simbolo "
                    f"{symbol.component_id}, cui non si attacca: la distanza di "
                    f"rispetto e' {minimum:g} mm (B5)",
                    sorted({*_run_ids(sheet, route), symbol.component_id}),
                )
            )
    return findings


def _parallel_clearances(sheet: SheetGeometry, minimum: float) -> list[ValidationIssue]:
    """B6 — due linee affiancate corrono a distanza dichiarata, non a filo."""
    findings: list[ValidationIssue] = []
    alongside = [
        (index, route, move)
        for index, route, segment in _run_polylines(sheet)
        for move in moves_of(segment)
    ]
    for first in range(len(alongside)):
        for second in range(first + 1, len(alongside)):
            one, other = alongside[first], alongside[second]
            if one[0] == other[0]:
                continue
            gap = _parallel_distance(one[2], other[2])
            if gap is None or gap <= TOLERANCE_MM:
                continue
            severity = _clearance_severity(gap, minimum)
            if severity is None:
                continue
            findings.append(
                _finding(
                    "PARALLEL_RUNS_TOO_CLOSE",
                    severity,
                    f"le tratte {_run_name(one[1])} e {_run_name(other[1])} corrono "
                    f"affiancate a {gap:g} mm: la distanza di rispetto e' "
                    f"{minimum:g} mm (B6)",
                    sorted({*_run_ids(sheet, one[1]), *_run_ids(sheet, other[1])}),
                )
            )
    return findings


def u_turns(drawing: DrawingGeometry, frame: SheetFrame) -> list[ValidationIssue]:
    """B12, D-078 — nessuna andata e ritorno per raggiungere un pezzo.

    Il capo di una spezzata e' una porta, e l'ultimo tratto dice da che parte le
    si arriva. Se la spezzata era gia' stata **oltre** quella porta lungo l'asse
    di arrivo, l'ha superata e ci e' tornata indietro: si sposta l'oggetto, non
    si allunga la linea. La misura vale su entrambi i capi, perche' il verso in
    cui una spezzata e' scritta e' una convenzione dell'instradatore e il
    difetto non lo e'.

    Il passo di griglia entra nella misura perche' l'imbocco di una porta rivolta
    all'indietro cade per forza un passo oltre la porta: quello e' l'attacco, non
    un giro, e `geometry.overshoot_mm` lo distingue.
    """
    findings: list[ValidationIssue] = []
    for sheet in drawing.sheets:
        for _, route, segment in _run_polylines(sheet):
            overshoot = overshoot_mm(segment, frame.standard.grid_mm)
            if overshoot <= U_TURN_OVERSHOOT_MAX_MM + TOLERANCE_MM:
                continue
            findings.append(
                _finding(
                    "RUN_OVERSHOOTS_ITS_PORT",
                    IssueSeverity.BLOCKING,
                    f"la tratta {_run_name(route)} supera di {overshoot:g} mm la "
                    f"propria porta di arrivo e ci torna indietro: si sposta "
                    f"l'oggetto, non si allunga la linea (B12, D-078)",
                    _run_ids(sheet, route),
                )
            )
    return findings


def _label_box(
    label: PlacedLabel, height_mm: float
) -> tuple[float, float, float, float]:
    """Il riquadro della sigla al suo corpo (REL-008): quello della posa."""
    return riquadro_della_scritta(label, height_mm)


def _boxes_overlap(
    first: tuple[float, float, float, float], second: tuple[float, float, float, float]
) -> bool:
    return (
        first[0] < second[2] - TOLERANCE_MM
        and second[0] < first[2] - TOLERANCE_MM
        and first[1] < second[3] - TOLERANCE_MM
        and second[1] < first[3] - TOLERANCE_MM
    )


def labels_on_runs(drawing: DrawingGeometry, frame: SheetFrame) -> list[ValidationIssue]:
    """D5, DRAW-003 — un testo non copre una tubazione.

    Le etichette sono l'ultima fase del disegno e non hanno costo rispetto
    alla geometria (DRAW-003-R1): il disegnatore scrive un testo solo su un
    posto libero, e se non ce n'e' uno lo omette. Un testo sopra una linea — o
    a meno del franco che i testi tengono dalle linee — e' quindi una tavola
    che non esce dal disegnatore, o una regressione; e' un **avviso**, perche'
    nessun rilievo sui testi blocca l'emissione della tavola.
    """
    findings: list[ValidationIssue] = []
    height = frame.standard.text_small_mm
    for sheet in drawing.sheets:
        stretches = [
            (
                route,
                (
                    min(before.x_mm, after.x_mm) - LINE_CLEARANCE_MM,
                    min(before.y_mm, after.y_mm) - LINE_CLEARANCE_MM,
                    max(before.x_mm, after.x_mm) + LINE_CLEARANCE_MM,
                    max(before.y_mm, after.y_mm) + LINE_CLEARANCE_MM,
                ),
            )
            for _, route, segment in _run_polylines(sheet)
            for before, after in moves_of(segment)
        ]
        for label in sheet.labels:
            box = _label_box(label, height)
            hit = next((route for route, other in stretches if _boxes_overlap(box, other)), None)
            if hit is None:
                continue
            findings.append(
                _finding(
                    "LABEL_ON_A_RUN",
                    IssueSeverity.WARNING,
                    f"l'etichetta {label.id} copre la tratta {_run_name(hit)}: un testo "
                    f"si scrive su un posto libero o si omette (D5, D-075, DRAW-003-R1)",
                    sorted({sheet.sheet_id, label.id, *hit.connection_ids}),
                )
            )
    return findings


def _segment_crosses_box(
    before: Point, after: Point, box: tuple[float, float, float, float]
) -> bool:
    """Vero se il segmento passa per l'interno del riquadro (Liang-Barsky): un
    richiamo e' obliquo, e il suo riquadro d'ingombro non dice dove passa."""
    origin = (before.x_mm, before.y_mm)
    delta = (after.x_mm - before.x_mm, after.y_mm - before.y_mm)
    low, high = 0.0, 1.0
    for axis, (lower, upper) in enumerate(((box[0], box[2]), (box[1], box[3]))):
        if abs(delta[axis]) <= TOLERANCE_MM:
            if not lower + TOLERANCE_MM < origin[axis] < upper - TOLERANCE_MM:
                return False
            continue
        first = (lower - origin[axis]) / delta[axis]
        second = (upper - origin[axis]) / delta[axis]
        low = max(low, min(first, second))
        high = min(high, max(first, second))
    return low < high - TOLERANCE_MM


def equipment_table(drawing: DrawingGeometry, frame: SheetFrame) -> list[ValidationIssue]:
    """REL-006 — il disegno non passa sulla tabella delle apparecchiature.

    La tabella sta in alto a sinistra (I-141), e l'esecutore le fa spazio
    spostando il disegno quando serve (`layout.compose.sgombra_la_tabella`).
    E' un vincolo della posa, e un vincolo della posa ha un rilievo sulla
    tavola finita (**D-158**): un simbolo, un tratto di tubazione, una sigla o
    un richiamo dentro la tabella e' un **bloccante** — la tabella non si
    legge, e il disegno ha bisogno di un foglio piu' grande, che il piano sceglie."""
    findings: list[ValidationIssue] = []
    height = frame.standard.text_small_mm
    for sheet in drawing.sheets:
        if sheet.tabella is None:
            continue
        zona = sheet.tabella.riquadro
        dentro: list[str] = [
            item.component_id
            for item in sheet.symbols
            if _boxes_overlap((item.origin.x_mm, item.origin.y_mm, item.right_mm, item.bottom_mm), zona)
        ]
        for _, route, segment in _run_polylines(sheet):
            if any(
                _boxes_overlap(
                    (
                        min(before.x_mm, after.x_mm),
                        min(before.y_mm, after.y_mm),
                        max(before.x_mm, after.x_mm),
                        max(before.y_mm, after.y_mm),
                    ),
                    zona,
                )
                or _segment_crosses_box(before, after, zona)
                for before, after in moves_of(segment)
            ):
                dentro.append(_run_name(route))
        for label in sheet.labels:
            if _boxes_overlap(_label_box(label, height), zona) or any(
                _segment_crosses_box(*segmento, zona) for segmento in segmenti_del_richiamo(label)
            ):
                dentro.append(label.id)
        for reference in sheet.cross_references:
            if _boxes_overlap(
                (
                    reference.anchor.x_mm,
                    reference.anchor.y_mm - height,
                    reference.anchor.x_mm + text_width_mm(reference.text, height),
                    reference.anchor.y_mm,
                ),
                zona,
            ):
                dentro.append(reference.id)
        if not dentro:
            continue
        unici = list(dict.fromkeys(dentro))
        findings.append(
            _finding(
                "DRAWING_OVER_THE_EQUIPMENT_TABLE",
                IssueSeverity.BLOCKING,
                f"la tavola {sheet.sheet_id}: il disegno passa sulla tabella delle "
                f"apparecchiature — {', '.join(unici)}. La tabella sta in alto a "
                f"sinistra (I-141) e il disegno le fa spazio: se non ci riesce, il "
                f"foglio e' troppo piccolo per questo disegno",
                [sheet.sheet_id, *unici],
            )
        )
    return findings


def omitted_tags(drawing: DrawingGeometry) -> list[ValidationIssue]:
    """DRAW-003-R1 — una sigla di macchina che non ha trovato posto.

    Il disegnatore scrive la sigla su un lato libero del pezzo o con un
    richiamo corto che non attraversa niente; se nemmeno quello esiste la
    omette, e la tavola esce lo stesso. Chi legge il preflight deve pero'
    saperlo: e' un avviso, mai un blocco, perche' l'impossibilita' di
    collocare un testo non ferma l'emissione della tavola.
    """
    findings: list[ValidationIssue] = []
    for sheet in drawing.sheets:
        written = {label.id for label in sheet.labels if label.role == "tag"}
        in_tabella = (
            {riga.component_id for riga in sheet.tabella.righe} if sheet.tabella is not None else set()
        )
        for symbol in sheet.symbols:
            if not symbol.tag or f"{symbol.component_id}-tag" in written:
                continue
            if symbol.component_id in in_tabella:
                # **La sigla di un'apparecchiatura che sta in tabella non si puo'
                # omettere** (I-160): il codice della tabella la nomina, e sul
                # disegno deve esserci il pezzo che nomina.
                findings.append(
                    _finding(
                        "TABLE_EQUIPMENT_TAG_OMITTED",
                        IssueSeverity.BLOCKING,
                        f"la sigla {symbol.tag} di {symbol.component_id} non e' scritta, e il "
                        f"pezzo sta nella tabella delle apparecchiature: la sua sigla non si "
                        f"omette (I-160)",
                        [sheet.sheet_id, symbol.component_id],
                    )
                )
                continue
            findings.append(
                _finding(
                    "TAG_OMITTED",
                    IssueSeverity.WARNING,
                    f"la sigla {symbol.tag} di {symbol.component_id} non e' scritta: "
                    f"nessun lato libero e nessun richiamo pulito (DRAW-003-R1)",
                    [sheet.sheet_id, symbol.component_id],
                )
            )
    return findings


def omitted_free_labels(drawing: DrawingGeometry, project: ProjectModel | None) -> list[ValidationIssue]:
    """REL-009, I-194 — la scritta libera che il progettista da' a un pezzo, e che non
    ha trovato posto.

    «al solare termico» su un attacco tappato dice a che cosa serve l'attacco: senza,
    sulla tavola resta un tubo che finisce contro un tappo, e non si sa perche'. Non e'
    una sigla che la tabella o il disegno ripetono altrove: **blocca**, e si cura nella
    posa, lasciando un lato libero accanto al pezzo. Senza il modello non si misura."""
    if project is None:
        return []
    scritte = {
        item.id: str(item.properties[ETICHETTA]).strip()
        for item in project.components
        if isinstance(item.properties.get(ETICHETTA), str) and str(item.properties[ETICHETTA]).strip()
    }
    findings: list[ValidationIssue] = []
    for sheet in drawing.sheets:
        scritte_qui = {label.id for label in sheet.labels}
        for symbol in sheet.symbols:
            testo = scritte.get(symbol.component_id)
            if testo is None or f"{symbol.component_id}-{ETICHETTA}" in scritte_qui:
                continue
            findings.append(
                _finding(
                    "FREE_LABEL_OMITTED",
                    IssueSeverity.BLOCKING,
                    f"la scritta «{testo}» di {symbol.component_id} non e' scritta: nessun lato "
                    f"libero e nessun richiamo pulito. La scritta l'ha data il progettista, e "
                    f"la tavola non esce senza: si lascia posto accanto al pezzo (I-194)",
                    [sheet.sheet_id, symbol.component_id],
                )
            )
    return findings


def diameter_tags(
    drawing: DrawingGeometry, catalog: ComponentRegistry, project: ProjectModel | None = None
) -> list[ValidationIssue]:
    """REL-007 — **un'etichetta per tratto** (I-143; D-193, punti 6-8).

    Dalla sola tavola si vedono due difetti del disegnatore, e bloccano:
    un'etichetta che nomina connessioni che la tavola non disegna
    (`DIAMETER_TAG_WITHOUT_RUN`) e due etichette sullo stesso tratto
    (`DIAMETER_TAG_REPEATED`). **Col modello** si vede anche il terzo: un tratto
    che porta il DN — chiesto dal progettista, con la portata dai suoi dati — e
    l'etichetta non l'ha trovata (`DIAMETER_TAG_MISSING`): e' un avviso, come
    una sigla omessa (DRAW-003-R1), e la tavola esce lo stesso."""
    tratti = (
        tratti_da_etichettare(project, catalog)
        if project is not None and project.diametri is not None
        else ()
    )
    findings: list[ValidationIssue] = []
    for sheet in drawing.sheets:
        disegnate = {
            connection_id for route in sheet.routes for connection_id in route.connection_ids
        }
        per_tratto: dict[frozenset[str], list[str]] = {}
        for etichetta in sheet.diametri:
            nominate = frozenset(etichetta.connection_ids)
            fuori = not nominate or not nominate <= disegnate
            estranea = bool(tratti) and all(nominate != item.connection_ids for item in tratti)
            if fuori or estranea:
                findings.append(
                    _finding(
                        "DIAMETER_TAG_WITHOUT_RUN",
                        IssueSeverity.BLOCKING,
                        f"l'etichetta {etichetta.testo} non nomina un tratto di questa tavola "
                        f"che porti il DN (REL-007)",
                        [sheet.sheet_id, *sorted(nominate)[:1]],
                    )
                )
                continue
            per_tratto.setdefault(nominate, []).append(etichetta.testo)
        for nominate, testi in per_tratto.items():
            if len(testi) > 1:
                findings.append(
                    _finding(
                        "DIAMETER_TAG_REPEATED",
                        IssueSeverity.BLOCKING,
                        f"lo stesso tratto porta {len(testi)} etichette del DN "
                        f"({', '.join(testi)}): ne porta una sola (I-143)",
                        [sheet.sheet_id, *sorted(nominate)[:1]],
                    )
                )
        for tratto in tratti:
            if not tratto.connection_ids <= disegnate or tratto.connection_ids in per_tratto:
                continue
            if not tratto.strada_principale:
                # Il DN di una strada secondaria si sacrifica quando non c'e' posto
                # (I-161): non e' un difetto della tavola.
                continue
            capo, fine = tratto.capi
            findings.append(
                _finding(
                    "DIAMETER_TAG_MISSING",
                    IssueSeverity.WARNING,
                    f"il tratto {capo.component_id} -> {fine.component_id} porta "
                    f"{tratto.scritta} e l'etichetta non e' scritta: nessun rettilineo con "
                    f"un lato libero (REL-007)",
                    [sheet.sheet_id, capo.component_id, fine.component_id],
                )
            )
    return findings


def _padrone(label: PlacedLabel, pezzi: list[str]) -> str:
    """Il pezzo di una sigla o di un dato: l'identificativo della scritta e' quello
    del pezzo, piu' `-tag` o `-` e il nome del dato (`layout.labels`)."""
    return next((pezzo for pezzo in pezzi if label.id.startswith(pezzo + "-")), label.id)


def _distanza_fra_riquadri(
    first: tuple[float, float, float, float], second: tuple[float, float, float, float]
) -> float:
    dx = max(second[0] - first[2], first[0] - second[2], 0.0)
    dy = max(second[1] - first[3], first[1] - second[3], 0.0)
    return math.hypot(dx, dy)


def text_spacing(drawing: DrawingGeometry, frame: SheetFrame) -> list[ValidationIssue]:
    """REL-008 — le distanze fra le scritte (D-194, punto 9): **il rilievo delle
    regole della posa** (D-158, `docs/ARCHITETTURA-DEL-PIANO.md` §7).

    A 9 punti le scritte si leggevano male senza toccarsi, e nessun rilievo lo
    diceva: la sessione l'ha visto sulle tavole. La posa ora le tiene lontane, e
    qui si misura la tavola finita:

    - `TEXTS_READ_AS_ONE` — due scritte di pezzi diversi (sigle e dati accanto al
      pezzo, DN) piu' vicine di un corpo lungo la riga e di mezzo corpo fra le righe
      (`labels.riquadro_di_rispetto`), misurato dall'una e dall'altra: la posa ne fa
      rispettare almeno uno, e il rilievo scatta quando nessuno dei due e' rispettato;
    - `TAG_NEARER_ANOTHER_PIECE` — una sigla o un dato accanto al pezzo che sta piu'
      vicino a un altro pezzo che al suo (`labels._Canvas.vicina_al_suo`);
    - `DETACHED_DIAMETER_CROWDED` — la scritta di un DN staccato a meno di un corpo da
      scritte, simboli e linee degli altri tratti (`diametri.FRANCO_DELLA_STACCATA_EM`);
    - `LEADER_ON_A_FLOW_ARROW` — la freccia del richiamo di un DN sulla freccia di
      verso della linea (`diametri.riquadri_delle_frecce`).

    Sono **avvisi**: un testo non ferma la tavola (DRAW-003-R1)."""
    findings: list[ValidationIssue] = []
    corpo = frame.standard.text_small_mm
    for sheet in drawing.sheets:
        pezzi = sorted((item.component_id for item in sheet.symbols), key=len, reverse=True)
        riquadri_dei_pezzi = {
            item.component_id: (item.origin.x_mm, item.origin.y_mm, item.right_mm, item.bottom_mm)
            for item in sheet.symbols
        }
        # Le scritte accanto al pezzo e i DN: il richiamo di una sigla dice lui di
        # chi e' la scritta, e la posa non le chiede il rispetto degli altri.
        scritte: list[tuple[str, str, tuple[float, float, float, float], float, bool]] = []
        for label in sheet.labels:
            if label.role not in ("tag", "data") or segmenti_del_richiamo(label):
                continue
            scritte.append(
                (
                    label.id,
                    _padrone(label, pezzi),
                    _label_box(label, corpo),
                    label.corpo_mm if label.corpo_mm is not None else corpo,
                    False,
                )
            )
        for etichetta in sheet.diametri:
            scritte.append(
                (
                    f"DN {etichetta.testo}",
                    "DN " + "/".join(etichetta.connection_ids),
                    riquadro_del_diametro(etichetta, corpo),
                    etichetta.corpo_mm if etichetta.corpo_mm is not None else corpo,
                    etichetta.verticale,
                )
            )
        for indice, (nome, suo, box, corpo_suo, verticale) in enumerate(scritte):
            for altro_nome, altro, altro_box, corpo_altro, altro_verso in scritte[indice + 1 :]:
                if suo == altro:
                    continue
                if _boxes_overlap(riquadro_di_rispetto(box, corpo_suo, verticale), altro_box) and (
                    _boxes_overlap(riquadro_di_rispetto(altro_box, corpo_altro, altro_verso), box)
                ):
                    findings.append(
                        _finding(
                            "TEXTS_READ_AS_ONE",
                            IssueSeverity.WARNING,
                            f"{nome} e {altro_nome} sono di pezzi diversi e stanno a meno di un "
                            f"corpo sulla riga, o di mezzo fra le righe: si leggono come una "
                            f"scritta sola (D-194, punto 9)",
                            [sheet.sheet_id, nome, altro_nome],
                        )
                    )
        for nome, suo, box, _, _ in scritte:
            if suo not in riquadri_dei_pezzi:
                continue
            vicinanza = _distanza_fra_riquadri(box, riquadri_dei_pezzi[suo])
            altri = [
                (_distanza_fra_riquadri(box, riquadro), pezzo)
                for pezzo, riquadro in riquadri_dei_pezzi.items()
                if pezzo != suo
            ]
            if altri and min(altri)[0] < vicinanza - TOLERANCE_MM:
                findings.append(
                    _finding(
                        "TAG_NEARER_ANOTHER_PIECE",
                        IssueSeverity.WARNING,
                        f"{nome} sta a {min(altri)[0]:.2f} mm da {min(altri)[1]} e a "
                        f"{vicinanza:.2f} mm dal suo pezzo: si legge come la scritta dell'altro "
                        f"(D-194, punto 9)",
                        [sheet.sheet_id, nome, min(altri)[1]],
                    )
                )
        frecce = riquadri_delle_frecce(sheet)
        for etichetta in sheet.diametri:
            if etichetta.richiamo is None:
                continue
            nome = f"DN {etichetta.testo}"
            box = riquadro_del_diametro(etichetta, corpo)
            proprie = set(etichetta.connection_ids)
            # Simboli, sigle e linee sono posati prima dei DN, e la staccata ne sta a un
            # corpo; un DN posato dopo ne rispetta solo il riquadro di rispetto, che
            # misura `TEXTS_READ_AS_ONE`.
            vicini = list(riquadri_dei_pezzi.values())
            vicini += [altro for _, suo, altro, _, _ in scritte if not suo.startswith("DN ")]
            vicini += [
                (
                    min(before.x_mm, after.x_mm),
                    min(before.y_mm, after.y_mm),
                    max(before.x_mm, after.x_mm),
                    max(before.y_mm, after.y_mm),
                )
                for _, route, segment in _run_polylines(sheet)
                if not (route.connection_ids and set(route.connection_ids) <= proprie)
                for before, after in moves_of(segment)
            ]
            franco = FRANCO_DELLA_STACCATA_EM * corpo
            piu_vicino = min((_distanza_fra_riquadri(box, altro) for altro in vicini), default=math.inf)
            if piu_vicino < franco - TOLERANCE_MM:
                findings.append(
                    _finding(
                        "DETACHED_DIAMETER_CROWDED",
                        IssueSeverity.WARNING,
                        f"la scritta staccata {nome} sta a {piu_vicino:.2f} mm da cio' che non e' "
                        f"il suo tratto, meno di un corpo ({franco:.2f} mm): si legge con il "
                        f"vicino (D-194, punto 9)",
                        [sheet.sheet_id, nome, *sorted(proprie)[:1]],
                    )
                )
            punta = etichetta.richiamo.punta
            if any(
                freccia[0] - TOLERANCE_MM <= punta.x_mm <= freccia[2] + TOLERANCE_MM
                and freccia[1] - TOLERANCE_MM <= punta.y_mm <= freccia[3] + TOLERANCE_MM
                for freccia in frecce
            ):
                findings.append(
                    _finding(
                        "LEADER_ON_A_FLOW_ARROW",
                        IssueSeverity.WARNING,
                        f"la freccia del richiamo di {nome} cade sulla freccia di verso della "
                        f"linea (D-194, punto 9)",
                        [sheet.sheet_id, nome, *sorted(proprie)[:1]],
                    )
                )
    return findings


def _leader_enters(
    leader: tuple[Point, Point], box: tuple[float, float, float, float]
) -> bool:
    """Vero se il richiamo percorre l'interno del riquadro (Liang-Barsky)."""
    before, after = leader
    origin = (before.x_mm, before.y_mm)
    delta = (after.x_mm - before.x_mm, after.y_mm - before.y_mm)
    low, high = 0.0, 1.0
    for axis, (lower, upper) in enumerate(((box[0], box[2]), (box[1], box[3]))):
        if abs(delta[axis]) <= TOLERANCE_MM:
            if not lower + TOLERANCE_MM < origin[axis] < upper - TOLERANCE_MM:
                return False
            continue
        first = (lower - origin[axis]) / delta[axis]
        second = (upper - origin[axis]) / delta[axis]
        low = max(low, min(first, second))
        high = min(high, max(first, second))
    return low < high - TOLERANCE_MM


def _segmenti_dei_richiami(sheet: SheetGeometry) -> list[tuple[str, tuple[Point, Point]]]:
    """Ogni segmento di ogni richiamo della tavola, col nome di chi lo porta: la
    diagonale di prima delle sigle (`leader_from`), il tratto obliquo e la spalla
    del richiamo nuovo — delle sigle e dei DN staccati (I-162, I-163)."""
    segmenti: list[tuple[str, tuple[Point, Point]]] = []
    for label in sheet.labels:
        if label.leader_from is not None:
            segmenti.append((label.id, (label.leader_from, label.anchor)))
        if label.richiamo is not None:
            segmenti.extend((label.id, segmento) for segmento in label.richiamo.segmenti)
    for etichetta in sheet.diametri:
        if etichetta.richiamo is not None:
            nome = f"DN {etichetta.testo} ({', '.join(etichetta.connection_ids[:1])})"
            segmenti.extend((nome, segmento) for segmento in etichetta.richiamo.segmenti)
    return segmenti


def leader_crossings(drawing: DrawingGeometry) -> list[ValidationIssue]:
    """DRAW-003 — i richiami non si incrociano fra loro, non attraversano tubi
    e non passano sopra simboli.

    Il disegnatore non produce un richiamo cosi' (DRAW-003-R1): quando nessuna
    diagonale pulita esiste il testo si omette. Un richiamo che attraversa
    qualcosa e' percio' una geometria scritta a mano o una regressione, ed e'
    un avviso: nessun rilievo sui testi blocca la tavola.
    """
    findings: list[ValidationIssue] = []
    for sheet in drawing.sheets:
        leaders = _segmenti_dei_richiami(sheet)
        runs = [
            (route, (before, after))
            for _, route, segment in _run_polylines(sheet)
            for before, after in moves_of(segment)
        ]
        for index, (label_id, leader) in enumerate(leaders):
            for other_id, other_leader in leaders[index + 1 :]:
                if other_id != label_id and segments_cross(leader, other_leader):
                    findings.append(
                        _finding(
                            "LEADERS_CROSS",
                            IssueSeverity.WARNING,
                            f"i richiami delle etichette {label_id} e {other_id} si "
                            f"incrociano: due richiami che si attraversano non dicono "
                            f"piu' chi parla di chi (D2, DRAW-003)",
                            sorted({sheet.sheet_id, label_id, other_id}),
                        )
                    )
            covered = next(
                (
                    symbol
                    for symbol in sheet.symbols
                    if _leader_enters(leader, box_of(symbol))
                ),
                None,
            )
            if covered is not None:
                findings.append(
                    _finding(
                        "LEADER_CROSSES_A_SYMBOL",
                        IssueSeverity.WARNING,
                        f"il richiamo dell'etichetta {label_id} passa sopra il simbolo "
                        f"{covered.component_id}: un richiamo che confonde non si "
                        f"disegna, il testo si omette (D2, DRAW-003-R1)",
                        sorted({sheet.sheet_id, label_id, covered.component_id}),
                    )
                )
            crossed = next((route for route, run in runs if segments_cross(leader, run)), None)
            if crossed is not None:
                findings.append(
                    _finding(
                        "LEADER_CROSSES_A_RUN",
                        IssueSeverity.WARNING,
                        f"il richiamo dell'etichetta {label_id} attraversa la tratta "
                        f"{_run_name(crossed)}: un richiamo che confonde non si "
                        f"disegna, il testo si omette (D2, DRAW-003-R1)",
                        sorted({sheet.sheet_id, label_id, *crossed.connection_ids}),
                    )
                )
    return findings


def orthogonality_of_leaders(drawing: DrawingGeometry) -> list[ValidationIssue]:
    """D2, D3, D-075 — un richiamo e' obliquo a 45 gradi, mai ortogonale.

    Le tubazioni sono sempre ortogonali (D-041, B1): un richiamo ortogonale ha
    la stessa forma e la stessa giacitura di un tubo, e si legge come un tubo.
    La diagonale risolve alla radice, perche' nessuna tubazione e' mai obliqua.

    La geometria dichiara del richiamo i **due capi**, non la spezzata: la
    misura sta quindi sui due capi, ed e' la sola che valga qualunque cosa
    faccia il renderer. Un richiamo si puo' disegnare come D-075 lo vuole — una
    sola diagonale a 45 gradi — se e solo se i due capi stanno a 45 gradi l'uno
    dall'altro. Se non ci stanno, chi disegna deve piegare, e una piega ad
    angolo retto e' esattamente il tubo finto che D-075 vieta.

    Un'etichetta senza richiamo non e' misurata: e' il caso giusto, la scritta
    piccola accanto al proprio pezzo (D1).
    """
    findings: list[ValidationIssue] = []
    for sheet in drawing.sheets:
        # Del richiamo nuovo si misura il tratto obliquo: la spalla e' orizzontale
        # per scelta del PO (I-163).
        capi = (
            [(label.id, label.leader_from, label.anchor) for label in sheet.labels if label.leader_from is not None]
            + [
                (label.id, label.richiamo.punta, label.richiamo.gomito)
                for label in sheet.labels
                if label.richiamo is not None
            ]
            + [
                (f"DN {etichetta.testo}", etichetta.richiamo.punta, etichetta.richiamo.gomito)
                for etichetta in sheet.diametri
                if etichetta.richiamo is not None
            ]
        )
        for label_id, da, a in capi:
            span_x = abs(a.x_mm - da.x_mm)
            span_y = abs(a.y_mm - da.y_mm)
            if span_x <= TOLERANCE_MM and span_y <= TOLERANCE_MM:
                continue
            if abs(span_x - span_y) <= TOLERANCE_MM:
                continue
            angle = math.degrees(math.atan2(span_y, span_x))
            if span_x <= TOLERANCE_MM or span_y <= TOLERANCE_MM:
                code = "ORTHOGONAL_LABEL_LEADER"
                message = (
                    f"il richiamo dell'etichetta {label_id} e' ortogonale "
                    f"({angle:.0f} gradi): ha la giacitura di una tubazione e si legge "
                    f"come un altro tubo, mentre un richiamo si disegna obliquo a "
                    f"{LEADER_ANGLE_DEG} gradi (D2, D3, D-075)"
                )
            else:
                code = "LEADER_NOT_AT_45_DEGREES"
                message = (
                    f"il richiamo dell'etichetta {label_id} unisce due capi a "
                    f"{angle:.0f} gradi invece che a {LEADER_ANGLE_DEG}: fra quei due "
                    f"punti una sola diagonale non ci sta e chi disegna deve piegare ad "
                    f"angolo retto, cioe' disegnare un altro tubo (D2, D3, D-075)"
                )
            findings.append(
                _finding(code, IssueSeverity.BLOCKING, message, [sheet.sheet_id, label_id])
            )
    return findings


def _ci_sta(
    larghezza: float, altezza: float, area: Rect, respiro: float, sheet: SheetGeometry
) -> bool:
    """Se un disegno di quell'ingombro sta in quell'area, col margine minimo.

    **Con la tabella delle apparecchiature** (REL-006) ci deve stare accanto a
    lei: sotto — l'altezza della tabella e lo stacco in piu' — oppure a destra.
    E' una condizione sufficiente, misurata sull'ingombro: un disegno che ci
    starebbe solo grazie a un angolo vuoto non la passa, e il rilievo tace. Un
    rilievo che dice «ci sta» deve essere vero, o non si puo' chiudere."""
    if sheet.tabella is None:
        return (
            area.width_mm >= larghezza + respiro - TOLERANCE_MM
            and area.height_mm >= altezza + respiro - TOLERANCE_MM
        )
    tabella = sheet.tabella
    stacco = STACCO_DALLA_TABELLA_MM
    sotto = (
        area.width_mm >= larghezza + respiro - TOLERANCE_MM
        and area.height_mm
        >= altezza + tabella.altezza_mm + stacco + respiro / 2 - TOLERANCE_MM
    )
    a_destra = (
        area.width_mm
        >= larghezza + tabella.larghezza_mm + stacco + respiro / 2 - TOLERANCE_MM
        and area.height_mm >= altezza + respiro - TOLERANCE_MM
    )
    return sotto or a_destra


def _margin_beside_the_table(
    sheet: SheetGeometry, tabella: TabellaDelleApparecchiature, area: Rect, step_mm: float
) -> float:
    """Il margine che il disegno puo' permettersi nel posto che la tabella lascia
    libero: lo stesso conto di `margin_allowed_mm`, sull'area che resta sotto la
    tabella e su quella che resta alla sua destra, e vale la piu' generosa."""
    stacco = STACCO_DALLA_TABELLA_MM
    sotto = (
        area.x_mm,
        area.y_mm + tabella.altezza_mm + stacco,
        area.right_mm,
        area.bottom_mm,
    )
    a_destra = (
        area.x_mm + tabella.larghezza_mm + stacco,
        area.y_mm,
        area.right_mm,
        area.bottom_mm,
    )
    return max(
        margin_allowed_mm(sheet.symbols, sheet.routes, sotto, step_mm),
        margin_allowed_mm(sheet.symbols, sheet.routes, a_destra, step_mm),
    )


def sheet_fill(drawing: DrawingGeometry, frame: SheetFrame) -> list[ValidationIssue]:
    """**D3** — si prende il foglio piu' piccolo che contiene il disegno.

    ⛔ **Dal 22 settembre 2026 questa funzione non misura piu' dove stanno i
    pezzi** (**D-170**). Contava l'inchiostro nei quattro quadranti e accusava la
    tavola sbilanciata: **spingeva nel verso sbagliato**, e contraddiceva **A4**
    — «ogni pezzo sta addosso alla macchina che serve». Due agenti su tre, in
    camera pulita e indipendentemente, hanno allontanato un pezzo dalla macchina
    che serve **solo per spegnere quel rilievo**.

    Il PO ha sciolto il conflitto: A4 vince sempre, **si tiene il disegno stretto
    e si prende il foglio piu' piccolo che lo contiene**, e il vuoto che resta
    **non e' un difetto**. Quello che resta da dire e' una cosa sola, e non e'
    sulla posa: *questo disegno ci stava su un foglio piu' piccolo*.
    """
    findings: list[ValidationIssue] = []
    area = frame.drawing_rect_mm
    for sheet in drawing.sheets:
        # ⛔ **`SHEET_BARELY_FILLED` non c'e' piu'** (**D-170**, 22 settembre 2026).
        #
        # Diceva «il foglio e' pieno al 37%, sotto la finestra 45-65%»: cioe'
        # diceva che **il vuoto e' un difetto**. Il PO ha deciso il contrario:
        # «si tiene il disegno stretto e si prende il foglio piu' piccolo che lo
        # contiene — se poi resta del vuoto, **pazienza: il vuoto non e' un
        # difetto**».
        #
        # Era anche un cattivo indizio della cosa che voleva dire: un disegno
        # lungo e stretto **sul foglio piu' piccolo che lo contiene** sta sotto
        # il 45% per costruzione, e il rilievo si accendeva su una tavola che non
        # aveva niente da correggere. La domanda vera — *ci stava su un foglio
        # piu' piccolo?* — la fa adesso `SHEET_LARGER_THAN_NEEDED`, qui sotto, e
        # la fa direttamente.
        ratio = _fill_ratio(sheet, area)
        # **E l'altra sponda della finestra** (D-140): il riempimento non e' una
        # scala, e' un intervallo. Sopra il tetto il disegno e' fitto e non ci
        # sta piu' lo spazio per le sigle dei componenti — che e' la ragione per
        # cui il PO ha voluto una finestra invece di una soglia.
        if ratio > SHEET_FILL_MAX_RATIO:
            findings.append(
                _finding(
                    "SHEET_TOO_FULL",
                    IssueSeverity.WARNING,
                    f"la tavola {sheet.sheet_id}: il foglio e' pieno al "
                    f"{ratio * 100:.0f}%, sopra il {SHEET_FILL_MAX_RATIO * 100:.0f}% "
                    f"di D-140, e li' lo spazio per le sigle si stringe davvero. "
                    f"Resta una **misura** e non un difetto da chiudere (D-149): la "
                    f"posa non insegue piu' questo numero",
                    [sheet.sheet_id],
                )
            )
        # **Il disegno non arriva al bordo** (**D-143**, `DRAW-013` §B.4). Il
        # margine di rispetto parte da venticinque millimetri per lato e si
        # stringe fino a dieci **soltanto** per far entrare un disegno che
        # altrimenti non ci starebbe. Il rilievo si fa quindi sul confronto fra
        # il margine che c'e' e quello che questo disegno poteva permettersi: un
        # disegno grande che sta a dodici millimetri dal bordo e' **autorizzato**
        # — piu' dentro non ci stava — e uno piccolo spinto contro il bordo no.
        rect = (area.x_mm, area.y_mm, area.right_mm, area.bottom_mm)
        margin = border_margin_mm(sheet.symbols, sheet.routes, rect)
        allowed = margin_allowed_mm(
            sheet.symbols, sheet.routes, rect, frame.standard.grid_mm
        )
        # **La tabella delle apparecchiature si prende il suo spazio** (REL-006):
        # un disegno che si e' spostato per lasciarglielo e' piu' vicino al bordo
        # di quanto la sua sola misura gli consentirebbe, ed e' autorizzato. Il
        # margine che poteva permettersi si misura sul posto che la tabella lascia
        # — sotto di lei o alla sua destra, il piu' largo dei due.
        if sheet.tabella is not None:
            allowed = min(
                allowed,
                _margin_beside_the_table(sheet, sheet.tabella, area, frame.standard.grid_mm),
            )
        if margin is not None and margin < allowed - TOLERANCE_MM:
            findings.append(
                _finding(
                    "DRAWING_TOUCHES_THE_BORDER",
                    IssueSeverity.WARNING,
                    f"la tavola {sheet.sheet_id}: il disegno arriva a "
                    f"{margin:.1f} mm dal bordo dell'area, e con il suo ingombro "
                    f"poteva starne {allowed:.1f}: un disegno comodo non si "
                    f"disegna dal bordo a bordo (D-143)",
                    [sheet.sheet_id],
                )
            )
        # **D-170, 22 settembre 2026 — il vuoto non e' un difetto.**
        #
        # Qui stava `DRAWING_ALL_ON_ONE_SIDE`: contava l'inchiostro nei quattro
        # quadranti e accusava la tavola quando il piu' pieno ne portava piu' di
        # tre volte il piu' vuoto. **Spingeva nel verso sbagliato.** Misurato il
        # 21 settembre: **due agenti su tre**, in camera pulita e
        # indipendentemente, hanno **allontanato un pezzo dalla macchina che
        # serve** — il volano dalle pompe, lo scambiatore dalla caldaia — solo
        # per spegnerlo, e tutt'e due hanno scritto da soli che **un disegnatore
        # non lo farebbe**. Contraddiceva **A4**, che e' una regola del PO.
        #
        # Il PO ha sciolto il conflitto in termini di disegno: «**ogni pezzo sta
        # addosso alla macchina che serve**, e **si tiene il disegno stretto e si
        # prende il foglio piu' piccolo che lo contiene — se poi resta del vuoto,
        # pazienza: il vuoto non e' un difetto**».
        #
        # Quindi D3 **cambia natura**: non e' piu' una regola su **dove stanno i
        # pezzi**, e' una regola sulla **scelta del foglio**. L'unica cosa che
        # resta da dire e': *questo disegno ci stava su un foglio piu' piccolo*.
        ingombro = _drawing_bounds(sheet)
        if ingombro is None:
            continue
        larghezza = ingombro[2] - ingombro[0]
        altezza = ingombro[3] - ingombro[1]
        # I formati sono in ordine crescente, e si nominano per indice: `SheetFrame`
        # e' un modello e non sta in un dizionario.
        # **Ci deve stare davvero, col margine.** Non basta che l'ingombro
        # dell'inchiostro entri nell'area del foglio piu' piccolo: ci deve stare
        # **con il margine minimo da tutt'e due i lati** (D-143), o il rilievo
        # direbbe «usa l'A3» per un disegno che sull'A3 tocca la cornice — e un
        # rilievo che non si puo' chiudere e' peggio di nessun rilievo.
        respiro = 2 * SHEET_MARGIN_MIN_MM
        piu_piccoli = [
            indice
            for indice, altro in enumerate(ORDINARY_FRAMES)
            if altro.drawing_rect_mm.width_mm < area.width_mm
            and _ci_sta(
                larghezza, altezza, altro.drawing_rect_mm, respiro, sheet
            )
        ]
        if piu_piccoli:
            nome = NOMI_DEI_FORMATI[min(piu_piccoli)]
            findings.append(
                _finding(
                    "SHEET_LARGER_THAN_NEEDED",
                    IssueSeverity.WARNING,
                    f"la tavola {sheet.sheet_id}: il disegno ingombra "
                    f"{larghezza:.0f} x {altezza:.0f} mm e ci starebbe su un "
                    f"**{nome}**: si prende il foglio piu' piccolo che lo "
                    f"contiene, e il vuoto che resta non e' un difetto (D3, D-170)",
                    [sheet.sheet_id],
                )
            )
    return findings


def next_sheet_fill(
    drawing: DrawingGeometry, frame: SheetFrame
) -> list[ValidationIssue]:
    """A2, D-072 — una tavola successiva esiste solo se porta contenuto vero.

    «Non ha senso separare in due fogli con il secondo completamente vuoto.» La
    prima tavola non e' misurata qui: una tavola sola non e' una divisione, e il
    suo riempimento lo dice `sheet_fill` come avviso.
    """
    findings: list[ValidationIssue] = []
    area = frame.drawing_rect_mm
    for sheet in drawing.sheets[1:]:
        ratio = _fill_ratio(sheet, area)
        if ratio >= NEXT_SHEET_FILL_MIN_RATIO:
            continue
        findings.append(
            _finding(
                "CONTINUATION_SHEET_TOO_EMPTY",
                IssueSeverity.BLOCKING,
                f"la tavola {sheet.sheet_id} e' piena solo al {ratio * 100:.0f}%, sotto "
                f"il {NEXT_SHEET_FILL_MIN_RATIO * 100:.0f}% dichiarato: si divide solo "
                f"se la tavola successiva e' abbastanza piena, altrimenti si ottimizza "
                f"quella che c'e' (A2, D-072)",
                [sheet.sheet_id],
            )
        )
    return findings


def symbol_sources(
    drawing: DrawingGeometry, catalog: ComponentRegistry
) -> list[ValidationIssue]:
    """C8, D-081, D-083 — nessun simbolo senza una fonte vera.

    La convenzione grafica interna non e' una fonte: e' il nome che si da' a un
    simbolo inventato. Un simbolo che la cita torna a essere una domanda aperta
    al PM, non un elaborato da consegnare.
    """
    used: dict[str, set[str]] = {}
    for sheet in drawing.sheets:
        for symbol in sheet.symbols:
            used.setdefault(symbol.symbol_id, set()).add(symbol.component_id)
    by_symbol = {item.symbol_id: item for item in catalog.all()}

    findings: list[ValidationIssue] = []
    for symbol_id in sorted(used):
        components = sorted(used[symbol_id])
        entities = [symbol_id, *components]
        subject = f"il simbolo {symbol_id}, {_how_many_components(len(components))},"
        definition = by_symbol.get(symbol_id)
        if definition is None:
            findings.append(
                _finding(
                    "SYMBOL_SOURCE_NOT_VERIFIABLE",
                    IssueSeverity.BLOCKING,
                    f"{subject} non si trova nel catalogo: la sua fonte non e' "
                    f"verificabile (D-083)",
                    entities,
                )
            )
            continue
        try:
            source = catalog.resolve(definition.id).symbol.manifest.source
        except CatalogError as exc:
            findings.append(
                _finding(
                    "SYMBOL_SOURCE_NOT_VERIFIABLE",
                    IssueSeverity.BLOCKING,
                    f"{subject} non si risolve sulla libreria dei simboli: {exc} (D-083)",
                    entities,
                )
            )
            continue
        if not source.strip():
            findings.append(
                _finding(
                    "SYMBOL_WITHOUT_A_DECLARED_SOURCE",
                    IssueSeverity.BLOCKING,
                    f"{subject} non dichiara nessuna fonte: la mancanza di fonte e' una "
                    f"domanda al PM, non una licenza (D-083)",
                    entities,
                )
            )
        elif source.strip() == INVENTED_SOURCE:
            findings.append(
                _finding(
                    "SYMBOL_FROM_AN_INVENTED_CONVENTION",
                    IssueSeverity.BLOCKING,
                    f"{subject} cita {INVENTED_SOURCE}: la convenzione interna non e' "
                    f"una fonte, e' il nome di un simbolo inventato (C8, D-081, D-083)",
                    entities,
                )
            )
    return findings


def _how_many_components(count: int) -> str:
    return f"usato da {count} componente" if count == 1 else f"usato da {count} componenti"


def unresolved_runs(drawing: DrawingGeometry) -> list[ValidationIssue]:
    """Le tratte consegnate col ripiego dichiarato (**D-150**).

    **E' il primo rilievo del rapporto, e il piu' grave**, perche' e' l'unico
    che dice che la tavola **non e' finita**. Tutti gli altri misurano quanto
    bene e' disegnato qualcosa che c'e'; questo dice che qualcosa non c'e', o
    c'e' sbagliato.

    Esce **bloccante**, e il resto del motore gli da' gia' il comportamento
    giusto senza che questa misura sappia niente di lui: con `--verifica` la
    tavola **esce marcata** e i rilievi restano stampati per intero; senza, non
    esce affatto (D-063). Cioe': si guarda e si rifinisce in CAD, e non si
    consegna come finale. E' esattamente il contratto che D-150 vuole.
    """
    findings: list[ValidationIssue] = []
    for sheet in drawing.sheets:
        for route in sheet.routes:
            if not route.unresolved:
                continue
            nome = route.connection_ids[0] if route.connection_ids else "senza nome"
            findings.append(
                _finding(
                    "RUN_UNRESOLVED",
                    IssueSeverity.BLOCKING,
                    f"la tavola {sheet.sheet_id}: la tratta {nome} della rete "
                    f"{route.network_id} **non e' stata risolta dal motore** e porta "
                    f"un segno di ripiego — la linea non evita gli ostacoli e i suoi "
                    f"accessori in linea possono mancare. Va chiusa a mano sul DXF, "
                    f"oppure il motore va corretto (D-150)",
                    [sheet.sheet_id, *route.connection_ids],
                )
            )
    return findings


def preflight_drawing(
    drawing: DrawingGeometry,
    frame: SheetFrame,
    catalog: ComponentRegistry,
    project: ProjectModel | None = None,
) -> list[ValidationIssue]:
    """Tutte le misure di qualita', nell'ordine dichiarato da `MEASURE_ORDER`.

    L'ordine e' parte dell'esito: chi legge il rapporto trova prima le linee,
    poi i testi, poi il foglio, infine le fonti — e lo trova sempre nello stesso
    posto, quale che sia la tavola.

    **`project` e' facoltativo, e non per comodita'.** La tavola si misura anche
    senza il modello che l'ha generata: e' cio' che il preflight ha sempre
    fatto, ed e' cio' che trentasei file di prove verificano. Col modello in
    mano il preflight sa in piu' **quali tratte sono autostrada** e conta le
    loro pieghe con il bilancio della catena invece che con quello di uno
    stacchetto (**D-151**): e' una misura piu' fine sulla stessa tavola, non
    un'altra misura.
    """
    autostrade = (
        autostrade_del_progetto(project, catalog) if project is not None else ()
    )
    return [
        # **Per prima la tratta non risolta**: e' l'unico rilievo che dice che
        # la tavola non e' finita, e chi legge non deve doverlo cercare.
        *unresolved_runs(drawing),
        *bends_per_run(drawing, autostrade),
        *longitudinal_overlap(drawing, frame),
        *clearances(drawing, frame),
        *u_turns(drawing, frame),
        *orthogonality_of_leaders(drawing),
        *labels_on_runs(drawing, frame),
        *leader_crossings(drawing),
        *omitted_tags(drawing),
        *omitted_free_labels(drawing, project),
        *diameter_tags(drawing, catalog, project),
        *text_spacing(drawing, frame),
        *equipment_table(drawing, frame),
        *sheet_fill(drawing, frame),
        *next_sheet_fill(drawing, frame),
        *symbol_sources(drawing, catalog),
    ]
