"""Il motore: modello piu' regole, e ne escono proposte.

Funzione pura. Non tocca il modello, non scrive niente, non decide niente: §9.2
dice che il motore non trasforma una proposta in progetto approvato, e il modo
piu' semplice di rispettarlo e' non dargli la possibilita' di farlo.

L'ordine e' quello delle regole nel registro, poi delle reti e dei componenti
nell'ordine del modello. Deterministico e ispezionabile: due esecuzioni danno la
stessa lista, e la lista si legge dall'alto come la si e' scritta.

**Cosa il motore non decide.** Una regola dichiara la funzione che deve
comparire; quale voce di catalogo la porti su quel fluido lo risolve il
catalogo, e se le voci sono due si ferma invece di sceglierne una. Il motore non
conosce nessun nome di componente, e non ne conosce nemmeno uno scritto in una
regola: da P2 non ce ne sono piu' (D-069).

**E se le voci sono zero, lo dice.** Una regola le cui condizioni sono vere ma
per cui il catalogo non ha nessun pezzo su quel fluido non «non si applica»: si
applica e non ha niente da offrire. La differenza e' tutta, perche' il primo
caso e' silenzio legittimo e il secondo e' un accessorio che sparisce senza che
nessuno lo sappia — un bollitore a se' stante che resta senza scarico. Esce
percio' un **punto aperto** accanto alle proposte, con la categoria della regola
che lo ha generato.
"""

from collections.abc import Mapping
from dataclasses import dataclass, field

from disegnatore_mep.catalog.registry import ComponentRegistry
from disegnatore_mep.catalog.schema import ComponentDefinition, OnBoard
from disegnatore_mep.model.project import NetworkModel, PortRef, ProjectModel
from disegnatore_mep.model.types import PlantRegime

from .context import RuleContext
from .errors import RuleError
from .proposal import GapReason, RuleGap, RuleProposal, proposed_component_id
from .registry import RuleRegistry
from .schema import (
    OnBoardPolicy,
    Placement,
    RuleCardinality,
    RuleDefinition,
    SatisfactionScope,
)

BRANCH_OFF = "branch_off"
"""Il mestiere del raccordo che apre una derivazione sulla tubazione."""


@dataclass(frozen=True)
class Evaluation:
    """Cosa il motore ha trovato: cio' che propone e cio' che gli manca."""

    proposals: list[RuleProposal] = field(default_factory=list)
    gaps: list[RuleGap] = field(default_factory=list)
    withheld: list[RuleProposal] = field(default_factory=list)
    """Le proposte che il progettista ha tolto (`accessori_tolti`, REL-009): la
    regola le farebbe, e non si applicano. Non sono punti aperti."""

    @property
    def is_empty(self) -> bool:
        """Nessuna proposta. I punti aperti non contano: non si risolvono
        applicando qualcosa, e aspettarli farebbe girare a vuoto la
        saturazione."""
        return not self.proposals


def _anchors(context: RuleContext, rule: RuleDefinition, network: NetworkModel) -> list[PortRef]:
    """Gli attacchi su cui questa regola potrebbe posare qualcosa, in ordine."""
    network_id = network.id
    found: list[PortRef] = []
    for component_id in context.anchors_of(
        network_id, rule.when.anchor_has_function, rule.when.anchor_has_trait
    ):
        # Una regola che si occupa della riserva non guarda i circuiti che la
        # attraversano: il serpentino di un bollitore porta acqua di
        # riscaldamento, e uno scarico li' svuota il primario lasciando pieno
        # il serbatoio. La rete che serve la riserva e' quella che porta il
        # fluido tenuto in serbo, oppure quella da cui la riserva dichiara di
        # riempirsi (C2).
        if rule.when.network_carries_what_the_anchor_stores and not (
            context.stores(component_id, network.medium)
            or context.fills_on(component_id, network_id)
        ):
            continue
        if rule.when.network_fills_the_anchor and not context.fills_on(
            component_id, network_id
        ):
            continue
        # Il dominio di protezione (I-046): la regola parla solo di chi, con i
        # propri organi aperti, non arriva a nessun pezzo con quella funzione
        # senza attraversare un organo altrui.
        if rule.when.anchor_cut_off_from is not None and not context.cut_off_from(
            component_id, rule.when.anchor_cut_off_from, network_id
        ):
            continue
        for port in context.connected_ports(component_id):
            if port.flow not in rule.then.placement.flows:
                continue
            if context.network_of_connection.get(
                context.connection_of_port[(component_id, port.id)]
            ) != network_id:
                continue
            found.append(PortRef(component_id=component_id, port_id=port.id))
    return found


def _regime_allows(rule: RuleDefinition, declared: PlantRegime | None) -> bool:
    """La regola vale nel regime che il progetto dichiara (D-106).

    Il regime non si calcola mai: lo dichiara il progettista, e un progetto
    che non dichiara niente riceve il **corredo minimo** — le regole del
    regime piccolo si applicano, quelle del grande no.
    """
    if rule.when.plant_regime is None:
        return True
    if rule.when.plant_regime is PlantRegime.OVER_35_KW:
        return declared is PlantRegime.OVER_35_KW
    return declared is not PlantRegime.OVER_35_KW


def _domains(
    chains: list[tuple[str, ...]],
) -> list[tuple[tuple[str, ...], frozenset[str]]]:
    """Le camminate raggruppate per **dominio**, con il tratto che ciascuno ha
    in comune.

    Due ancoraggi stanno nello stesso dominio se le loro camminate condividono
    una tubazione: da li' in poi il percorso e' lo stesso, e un pezzo posato su
    quel tratto serve tutti e due. Chi non condivide niente con nessuno resta un
    dominio a se', **e non fa perdere il proprio tratto agli altri**: era il
    difetto che il PM ha visto sull'ibrido, dove la protezione valida per una
    macchina veniva scartata perche' l'altra, dietro la deviatrice, non ci
    arrivava.

    Restituisce, per ogni dominio, la prima camminata — quella che detta la
    testa — e le tubazioni comuni a tutte le sue. L'ordine e' quello degli
    ancoraggi, che e' gia' invariante rispetto all'ordine del file.
    """
    groups: list[tuple[list[tuple[str, ...]], frozenset[str]]] = [
        ([chain], frozenset(chain)) for chain in chains
    ]
    merged = True
    while merged:
        merged = False
        for first in range(len(groups)):
            for second in range(first + 1, len(groups)):
                shared = groups[first][1] & groups[second][1]
                if not shared:
                    continue
                groups[first] = ([*groups[first][0], *groups[second][0]], shared)
                del groups[second]
                merged = True
                break
            if merged:
                break
    return [(group[0], shared) for group, shared in groups]


def _common_run_anchors(
    context: RuleContext, rule: RuleDefinition, network: NetworkModel
) -> tuple[list[tuple[PortRef, frozenset[str]]], PortRef | None]:
    """La testa del tratto comune di **ogni dominio** della rete.

    Dal ritorno (o dalla mandata) di ciascun ancoraggio si cammina lungo il
    percorso — contro il fluido per il ritorno, seguendolo per la mandata —
    attraverso cio' che lascia passare la corsa; dentro un multivia si passa per
    le comunicazioni che i suoi stati ammettono, mai da un ramo all'altro. Le
    tubazioni che le camminate di un dominio condividono sono il suo tratto
    comune; il pezzo si posa sulla prima di esse, cioe' la piu' vicina agli
    ancoraggi: a monte della prima ripartizione sul ritorno, a valle
    dell'ultima confluenza sulla mandata. Con un ancoraggio solo il tratto
    comune comincia sul suo stesso attacco.

    La cardinalita' e' percio' **per dominio**, non per rete: due circuiti
    chiusi indipendenti dichiarati sulla stessa rete sono due domini e vogliono
    ciascuno il proprio corredo (DRAW-006, blocco C, punto 4).

    Restituisce `(teste, ripiego)`: ogni testa viene con le tubazioni del
    proprio dominio, su cui si guarda se il corredo c'e' gia'; il ripiego e'
    l'attacco del primo ancoraggio, che serve a dire **dove** la rete non ha
    nessun tratto comune.
    """
    upstream = rule.then.placement is Placement.ON_THE_COMMON_RETURN
    chains: list[tuple[str, ...]] = []
    fallback: PortRef | None = None
    for component_id in context.anchors_of(
        network.id, rule.when.anchor_has_function, rule.when.anchor_has_trait
    ):
        if rule.when.network_carries_what_the_anchor_stores and not (
            context.stores(component_id, network.medium)
            or context.fills_on(component_id, network.id)
        ):
            continue
        if rule.when.network_fills_the_anchor and not context.fills_on(
            component_id, network.id
        ):
            continue
        for port in context.connected_ports(component_id):
            if port.flow not in rule.then.placement.flows:
                continue
            connection_id = context.connection_of_port[(component_id, port.id)]
            if context.network_of_connection.get(connection_id) != network.id:
                continue
            if fallback is None:
                fallback = PortRef(component_id=component_id, port_id=port.id)
            chain = context.run_from(
                connection_id, upstream=upstream, network_id=network.id
            )
            if chain:
                chains.append(chain)
    found: list[tuple[PortRef, frozenset[str]]] = []
    for first, shared in _domains(chains):
        head = next(item for item in first if item in shared)
        leaves, enters = context.pipe_ends[head]
        found.append(((enters if upstream else leaves), shared))
    return found, fallback


def _limited(
    anchors: list[PortRef], cardinality: RuleCardinality, served: set[str]
) -> list[PortRef]:
    """La cardinalita' dichiarata, applicata.

    Senza, un vaso di espansione esce una volta per ogni ritorno del generatore:
    e' il difetto trovato prototipando, prima che ci fosse del codice da
    correggere.

    `served` porta i componenti gia' serviti da questa regola **su tutte le
    reti**, non solo su quella in esame: un volano sta contemporaneamente sul
    primario e sul secondario, e uno scarico per accumulo deve restare uno.
    """
    if cardinality is RuleCardinality.PER_PORT:
        return anchors
    if cardinality is RuleCardinality.PER_NETWORK:
        return anchors[:1]
    first: list[PortRef] = []
    for anchor in anchors:
        if anchor.component_id in served:
            continue
        served.add(anchor.component_id)
        first.append(anchor)
    return first


def _function_at(context: RuleContext, rule: RuleDefinition, anchor: PortRef) -> str:
    """La funzione che questa regola chiede **su questo ancoraggio**.

    Dipende dal regime di intercettazione dichiarato dall'ancoraggio: cio' che
    non deve mai restare escluso per distrazione vuole un organo bloccabile
    aperto, non quello comune.
    """
    return rule.then.function_for(context.shutoff_regime_of(anchor.component_id))


def _carried_by_every_anchor(
    context: RuleContext, rule: RuleDefinition, network_id: str, function: str
) -> bool:
    """Ogni componente che la regola ancora su questa rete la porta a bordo.

    E' il solo modo in cui il bordo macchina soddisfa una regola **di rete**:
    se tutti i generatori integrano il vaso, un vaso esterno non si aggiunge;
    se uno solo lo integra, il circuito lo vuole comunque. Il bordo di un
    membro che la regola non ancora — la sicurezza integrata della pompa di
    calore, per la regola del serbatoio — non conta mai.
    """
    members = context.anchors_of(
        network_id, rule.when.anchor_has_function, rule.when.anchor_has_trait
    )
    return bool(members) and all(
        context.carries(item, function) for item in members
    )


def _already_there(
    context: RuleContext,
    rule: RuleDefinition,
    network_id: str,
    anchor: PortRef,
    domain: frozenset[str] | None = None,
) -> bool:
    """La funzione che la regola porterebbe qui c'e' gia', nell'ambito dichiarato."""
    function = _function_at(context, rule, anchor)
    # Cio' che l'ancoraggio porta a bordo non si aggiunge (D-106, criterio 4):
    # il filtro integrato della macchina E' il filtro di quella macchina, e
    # vale in ogni ambito — per attacco come per rete. Salvo dove la regola
    # dichiara che il bordo non basta: la sicurezza di ogni generatore (D-182).
    on_board_counts = rule.satisfied_by.on_board_counts
    if on_board_counts and context.carries(anchor.component_id, function):
        return True
    if rule.satisfied_by.scope is SatisfactionScope.ON_THE_NETWORK:
        # Su un tratto comune l'ambito e' il **dominio** che quel tratto serve,
        # non la rete intera: con l'ambito di rete il corredo di un secondo
        # circuito chiuso spariva perche' il primo ce l'aveva gia' (DRAW-006).
        present = (
            context.run_holds(domain, function)
            if domain is not None
            else context.network_has(network_id, function)
        )
        return present or (
            on_board_counts and _carried_by_every_anchor(context, rule, network_id, function)
        )
    # Un accessorio posato sull'attacco di servizio non sta sulla tubazione
    # principale: camminando lungo quella non lo si troverebbe, e lo si
    # riproporrebbe a ogni passata.
    if context.service_port_is_taken(anchor.component_id, function):
        return True
    if rule.satisfied_by.scope is SatisfactionScope.ON_THE_GROUP:
        # Il gruppo si isola dall'esterno, mai fra i membri (I-034): l'organo
        # c'e' gia' sul tratto, oppure il tratto porta a un membro del gruppo.
        return context.group_holds(anchor, function)
    return context.port_carries(anchor, function)


MEDIA_WITHOUT_ACCESSORIES = frozenset({"solar_fluid"})
"""I fluidi sulle cui reti **nessuna regola aggiunge niente** (D-188).

Il PO, 26 settembre 2026: sul circuito solare il gruppo di circolazione lo
descrive il progettista e lo trascrive chi legge il testo, e le regole non
aggiungono niente — in particolare nessun gruppo di riempimento
dall'acquedotto, perche' il circuito si riempie di fluido antigelo. Si decide
qui, nel punto in cui il motore sceglie di quali reti una regola parla: le
regole restano come sono, e un pezzo che sta su due reti — il bollitore a due
serpentini — riceve il suo corredo sulla rete di riscaldamento e niente su
quella solare."""


def _matches(context: RuleContext, rule: RuleDefinition, network: NetworkModel) -> bool:
    """La rete e' una di quelle di cui la regola parla."""
    if network.domain != rule.when.network_domain:
        return False
    if network.medium in MEDIA_WITHOUT_ACCESSORIES:
        return False
    if rule.when.network_medium is not None and network.medium != rule.when.network_medium:
        return False
    if rule.when.network_has_function is not None and not context.network_has(
        network.id, rule.when.network_has_function
    ):
        return False
    return not (
        rule.when.network_lacks_function is not None
        and context.network_has(network.id, rule.when.network_lacks_function)
    )


def _domain_at(
    domains: dict[tuple[str, str], frozenset[str]], anchor: PortRef
) -> frozenset[str] | None:
    """Le tubazioni del dominio che quella testa serve, se la regola li conta.

    Vuoto per ogni altra regola: allora l'ambito di soddisfazione resta quello
    che la regola dichiara, e non cambia niente rispetto a prima.
    """
    return domains.get((anchor.component_id, anchor.port_id))


def _catalogue_has(
    catalog: ComponentRegistry, rule: RuleDefinition, function: str, medium: str
) -> bool:
    """Il catalogo ha un pezzo per quella funzione su quel fluido.

    Un **ponte** si cerca altrove: le sue porte non stanno tutte sullo stesso
    fluido, quindi `serving` non lo trova ne' lo deve trovare — non e' un pezzo
    da infilare in una tratta.
    """
    if rule.then.bridges_from_medium is not None:
        return bool(catalog.bridging(function, rule.then.bridges_from_medium, medium))
    return bool(catalog.serving(function, medium))


def _declares(properties: Mapping[str, object], wanted: Mapping[str, str]) -> bool:
    """Il pezzo dichiara tutti quei dati, con quei valori (D-178).

    Vuoto non dichiara mai niente: una regola senza la clausola chiede come ha
    sempre chiesto. Il confronto ignora maiuscole e spazi ai bordi, perche' il
    valore e' la parola del progettista trascritta com'e'."""
    if not wanted:
        return False
    return all(
        key in properties
        and str(properties[key]).strip().lower() == value.strip().lower()
        for key, value in wanted.items()
    )


def _definition_for(
    catalog: ComponentRegistry, rule: RuleDefinition, function: str, medium: str
) -> ComponentDefinition:
    """La voce che la regola propone su quella rete: un ponte si cerca fra due
    fluidi, tutto il resto sul fluido della rete.

    Una sola domanda, fatta in un posto solo: la miscelatrice termostatica ha
    un attacco sull'acqua fredda (D-175), e chiederla come organo della sola
    acqua calda sanitaria — dove C2 guarda come si attacca il pezzo — non la
    trovava piu'."""
    if rule.then.bridges_from_medium is not None:
        return catalog.bridge(function, rule.then.bridges_from_medium, medium)
    return catalog.providing(function, medium)


def _source_for(
    context: RuleContext, project: ProjectModel, medium: str
) -> PortRef | None:
    """L'attacco della sorgente gia' approvata per quel fluido.

    Le reti si guardano in ordine di nome, come ovunque nel motore: quale rete
    alimenti il ponte non deve dipendere da come l'impianto e' stato scritto.
    """
    for network in sorted(project.networks, key=lambda item: item.id):
        if network.medium != medium:
            continue
        found = context.source_port_on(network.id)
        if found is not None:
            return found
    return None


def _gap(
    context: RuleContext,
    rule: RuleDefinition,
    network: NetworkModel,
    anchor: PortRef,
    reason: GapReason = GapReason.MISSING_PIECE,
) -> RuleGap:
    return RuleGap(
        rule_id=rule.id,
        rule_version=rule.version,
        category=rule.category,
        name=rule.name,
        network_id=network.id,
        medium=network.medium,
        anchor=anchor,
        missing_function=_function_at(context, rule, anchor),
        reason=reason,
        rationale=rule.rationale,
        source=rule.source,
    )


def evaluate(
    project: ProjectModel, catalog: ComponentRegistry, rules: RuleRegistry
) -> Evaluation:
    """Le integrazioni che il modello non ha ancora, con il perche' di ciascuna,
    e i punti in cui una regola si applica ma il catalogo non ha il pezzo."""
    context = RuleContext.build(project, catalog, {item.id: item for item in rules.all()})
    taken = {item.id for item in project.components}
    declared = {item.id: item.properties for item in project.components}
    proposals: list[RuleProposal] = []
    gaps: dict[tuple[str, str, str, str], RuleGap] = {}
    # Un tratto, un organo (I-034). Due attacchi affacciati sullo stesso tratto
    # — l'accumulo e il circolatore che ne parte — chiedono lo stesso pezzo
    # sullo stesso volume: la seconda proposta e' la prima, non un doppione da
    # applicare. Il tratto si riconosce dalle tubazioni che lo compongono.
    claimed: set[tuple[frozenset[str], str]] = set()

    for rule in rules.all():
        # Il regime della centrale si legge come ogni altra proprieta'
        # dichiarata (D-106): una regola dell'altro regime non parla affatto.
        if not _regime_allows(rule, project.plant_regime):
            continue
        served: set[str] = set()
        # Le reti in ordine di nome, non nell'ordine del file: quale rete si
        # serve per prima decide, per le regole a cardinalita' limitata, su
        # quale attacco l'accessorio si posa — e non puo' dipendere da come
        # l'impianto e' stato scritto.
        for network in sorted(project.networks, key=lambda item: item.id):
            if not _matches(context, rule, network):
                continue

            # Le tubazioni del dominio di ciascuna testa, per le regole che si
            # posano su un tratto comune: e' li' che si guarda se il corredo
            # c'e' gia', invece che sull'intera rete.
            domain_of: dict[tuple[str, str], frozenset[str]] = {}
            if rule.then.placement.on_a_common_run:
                # Il pezzo non si posa su un attacco dell'ancoraggio ma sul
                # tratto comune. Chi si conta **per rete** ne vuole uno solo, e
                # una rete i cui ancoraggi non condividono nessuna tubazione non
                # si serve in silenzio: sceglierne un dominio sarebbe decidere al
                # posto del progettista, e tacere sarebbe peggio — esce un punto
                # aperto. Chi si conta **per dominio di protezione** li serve
                # invece tutti: nessun dominio perde il proprio pezzo perche' un
                # altro non lo raggiunge (DRAW-006, blocco C, punti 4 e 5).
                heads, fallback = _common_run_anchors(context, rule, network)
                per_domain = rule.cardinality is RuleCardinality.PER_PROTECTION_DOMAIN
                if not heads or (len(heads) > 1 and not per_domain):
                    if fallback is None:
                        continue
                    missing = _gap(
                        context, rule, network, fallback, GapReason.NO_COMMON_RUN
                    )
                    gaps.setdefault(missing.key, missing)
                    continue
                candidates = [head for head, _ in heads]
                if per_domain:
                    domain_of = {
                        (head.component_id, head.port_id): pipes for head, pipes in heads
                    }
            else:
                candidates = _anchors(context, rule, network)

            # Un ancoraggio su un fluido per cui il catalogo non ha nessun pezzo
            # con quella funzione non si puo' servire — ma non si tace: diventa
            # un punto aperto, uno per rete e per funzione, perche' il pezzo che
            # manca in catalogo e' uno solo. Averne **due** e' un'altra cosa e
            # si ferma: la sceglierebbe il programma.
            anchors: list[PortRef] = []
            for anchor in candidates:
                if not _catalogue_has(
                    catalog, rule, _function_at(context, rule, anchor), network.medium
                ):
                    missing = _gap(context, rule, network, anchor)
                    gaps.setdefault(missing.key, missing)
                    continue
                # C2: una riserva che dichiara da dove si riempie riceve le
                # derivazioni **solo li'**. Uno stacco senza attacco dedicato,
                # saldato su un altro attacco della riserva, finirebbe sul
                # circuito sbagliato — lo scarico sull'uscita calda del
                # bollitore era esattamente questo. L'attacco di riempimento
                # verra' servito quando si valuta la sua rete.
                fill = context.fill_port_of(anchor.component_id)
                if fill is not None and anchor.port_id != fill:
                    definition = _definition_for(
                        catalog, rule, _function_at(context, rule, anchor), network.medium
                    )
                    if definition.attaches_on_a_branch and (
                        context.service_port_for(
                            anchor.component_id, _function_at(context, rule, anchor)
                        )
                        is None
                    ):
                        continue
                anchors.append(anchor)

            # Cio' che la regola porterebbe c'e' gia', attacco per attacco. Si
            # calcola una volta sola: la stessa risposta serve a chi conta i
            # componenti serviti e a chi sceglie gli attacchi ancora liberi.
            covered = {
                (anchor.component_id, anchor.port_id): _already_there(
                    context, rule, network.id, anchor, _domain_at(domain_of, anchor)
                )
                for anchor in anchors
            }
            satisfied = {item for (item, _), found in covered.items() if found}
            # Un componente gia' servito su una rete e' servito e basta: il
            # volano sta sul primario e sul secondario, e uno scarico per
            # accumulo deve restare uno anche quando la prima passata non ha
            # proposto nulla perche' c'era gia'.
            served |= satisfied
            if rule.cardinality is RuleCardinality.PER_COMPONENT:
                # Una regola per componente si accontenta di **un** accessorio sul
                # pezzo, su qualunque attacco: guardare il singolo attacco la
                # faceva riproporre l'intercettazione del volano a ogni passata,
                # perche' la valvola era finita sull'altro lato.
                free = [item for item in anchors if item.component_id not in satisfied]
            else:
                free = [
                    anchor
                    for anchor in anchors
                    if not covered[(anchor.component_id, anchor.port_id)]
                ]
            # Le teste dei domini sono gia' una per dominio: tagliarle con la
            # cardinalita' di rete ne lascerebbe fuori tutti tranne il primo.
            allowed = (
                free
                if rule.cardinality is RuleCardinality.PER_PROTECTION_DOMAIN
                else _limited(free, rule.cardinality, served)
            )
            # Il ponte fra due reti (DRAW-006-R1, blocco D): la sorgente da
            # cui pescare dev'essere gia' dichiarata dal progettista. Si cerca
            # una volta per rete servita, prima di proporre: se non c'e', ogni
            # ancoraggio diventa un punto aperto invece di un pezzo appeso a
            # nulla.
            source: PortRef | None = None
            if rule.then.bridges_from_medium is not None:
                source = _source_for(context, project, rule.then.bridges_from_medium)
                # E la derivazione con cui pescare da quella rete: senza il
                # raccordo per quel fluido il ponte non si puo' innestare, ed
                # e' lo stesso silenzio del pezzo mancante — un punto aperto,
                # non un crollo a meta' catena.
                if source is not None and not catalog.serving(
                    BRANCH_OFF, rule.then.bridges_from_medium
                ):
                    source = None
                if source is None:
                    for anchor in allowed:
                        missing = _gap(
                            context, rule, network, anchor, GapReason.NO_SOURCE_NETWORK
                        )
                        gaps.setdefault(missing.key, missing)
                    continue

            for anchor in allowed:
                function = _function_at(context, rule, anchor)
                # Una regola che esiste in forza del bordo macchina non
                # presume: se il catalogo non dice se la funzione sta dentro
                # il mantello, il dato e' ignoto, e un dato ignoto e' una
                # domanda al progettista, non un pezzo in piu' (I-046).
                # Tranne dove il progettista ha gia' detto il dato che toglie la
                # domanda (D-178): l'ACS centralizzata vuole il vaso sanitario.
                if (
                    rule.then.if_on_board_is_unknown is OnBoardPolicy.ASK
                    and context.on_board(anchor.component_id, function) is OnBoard.UNKNOWN
                    and not _declares(
                        declared.get(anchor.component_id, {}),
                        rule.then.unless_the_anchor_declares,
                    )
                ):
                    missing = _gap(context, rule, network, anchor, GapReason.ON_BOARD_UNKNOWN)
                    gaps.setdefault(missing.key, missing)
                    continue
                definition = _definition_for(catalog, rule, function, network.medium)
                component_id = proposed_component_id(definition.id, anchor)
                if component_id in taken:
                    continue
                if rule.satisfied_by.scope is not SatisfactionScope.ON_THE_NETWORK:
                    # Solo un tratto vero identifica qualcosa: un attacco di
                    # servizio ancora libero non ha tubazioni, e due pezzi che
                    # ne aspettano uno ciascuno non condividono niente.
                    pipes = context.stretch_from(anchor)
                    if pipes:
                        stretch = (pipes, function)
                        if stretch in claimed:
                            continue
                        claimed.add(stretch)
                # Solo per chi pende da uno stacco, e solo se la macchina
                # dichiara l'attacco per quella funzione: altrimenti resta
                # vuoto e lo stacco si apre sulla tubazione (D-101).
                service_port = (
                    context.service_port_for(anchor.component_id, function)
                    if definition.attaches_on_a_branch
                    else None
                )
                # Lo stacco sulla tubazione vuole un raccordo di derivazione
                # per quel fluido. Se il catalogo non ce l'ha, proporre
                # farebbe crollare l'applicazione a meta' catena: e' lo
                # stesso silenzio del pezzo mancante, e si dichiara allo
                # stesso modo — un punto aperto, non un'eccezione.
                if (
                    definition.attaches_on_a_branch
                    and service_port is None
                    and not catalog.serving(BRANCH_OFF, network.medium)
                ):
                    missing = _gap(context, rule, network, anchor)
                    gaps.setdefault(missing.key, missing)
                    continue
                taken.add(component_id)
                proposals.append(
                    RuleProposal(
                        rule_id=rule.id,
                        rule_version=rule.version,
                        category=rule.category,
                        component_id=component_id,
                        definition_id=definition.id,
                        name=rule.name,
                        network_id=network.id,
                        anchor=anchor,
                        inlet_port=rule.then.inlet_port,
                        outlet_port=rule.then.outlet_port,
                        service_port=service_port,
                        source_anchor=source,
                        bridge_port=rule.then.bridge_port,
                        rationale=rule.rationale,
                        source=rule.source,
                    )
                )
    # Il progettista toglie dopo che la regola ha parlato (REL-009, I-192): il
    # tratto resta reclamato dalla proposta tolta, e l'organo non si riaffaccia
    # dall'altro capo dello stesso tratto. Se dice dove sta invece, la stessa
    # proposta si posa la'.
    tolti = {item.pezzo: item for item in project.accessori_tolti}
    tenute = [item for item in proposals if item.component_id not in tolti]
    tolte = [item for item in proposals if item.component_id in tolti]
    for tolta in tolte:
        altrove = tolti[tolta.component_id].altrove
        if altrove is None:
            continue
        spostata = _spostata(context, catalog, tolta, altrove)
        if spostata.component_id not in taken and all(
            item.component_id != spostata.component_id for item in tenute
        ):
            tenute.append(spostata)
    return Evaluation(proposals=tenute, gaps=list(gaps.values()), withheld=tolte)


def _spostata(
    context: RuleContext, catalog: ComponentRegistry, proposta: RuleProposal, altrove: str
) -> RuleProposal:
    """La stessa proposta, sull'attacco che il progettista indica (REL-009, I-192).

    Il pezzo, la regola e il perche' non cambiano: cambiano l'attacco, la rete che
    ci passa e il nome, che si deriva dal nuovo attacco come ogni altro. L'attacco
    di servizio si rilegge sul pezzo nuovo: un vaso spostato su un raccordo pende da
    uno stacco, non dall'attacco della macchina da cui la regola partiva."""
    pezzo, attacco = altrove.split(".", 1)
    anchor = PortRef(component_id=pezzo, port_id=attacco)
    connection_id = context.connection_of_port.get((pezzo, attacco))
    if connection_id is None:
        raise RuleError(
            f"{proposta.component_id} e' spostato su {altrove}, e nessuna tubazione tocca "
            f"quell'attacco: si sposta su un attacco collegato"
        )
    definition = catalog.resolve(proposta.definition_id).definition
    service_port = (
        next(
            (
                porta
                for funzione in definition.functions
                if (porta := context.service_port_for(pezzo, funzione)) is not None
            ),
            None,
        )
        if definition.attaches_on_a_branch
        else None
    )
    return proposta.model_copy(
        update={
            "component_id": proposed_component_id(definition.id, anchor),
            "network_id": context.network_of_connection[connection_id],
            "anchor": anchor,
            "service_port": service_port,
        }
    )


__all__ = ["BRANCH_OFF", "Evaluation", "evaluate"]
