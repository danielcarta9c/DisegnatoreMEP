"""Mandata o ritorno: lo dice la topologia, non la geometria.

Finora il verso di una tratta si leggeva dal disegno gia' fatto — «chi va verso
destra e' mandata» — e bastava che un componente finisse a sinistra del suo
alimentatore perche' la mandata venisse disegnata blu. E' il difetto che il PM
ha visto per primo: «il ritorno blu va dentro la valvola a tre vie?». Ci andava
la mandata: la valvola sta a valle della pompa di calore, e la geometria la
aveva messa a sinistra.

Il verso e' una proprieta' del **modello**, che e' orientato: ogni connessione
va da una porta `out` a una porta `in`. Quello che manca al modello e' quale
componente sia la sorgente del circuito, e lo dicono le funzioni di catalogo.

La regola, che e' poi come si legge una centrale:

- ogni rete ha una **sorgente** — il generatore, o l'accumulo se generatori non
  ce ne sono;
- cio' che esce dalla sorgente e prosegue in avanti e' **mandata**, fino al
  primo utilizzatore;
- cio' che rientra nella sorgente, risalito all'indietro, e' **ritorno**, fino
  al primo utilizzatore.

Camminare si ferma sugli utilizzatori perche' e' li' che il fluido cambia
mestiere: quello che entra in un radiatore e' mandata, quello che ne esce e'
ritorno, e nessuna delle due camminate deve attraversarlo per non riscrivere
l'altra meta' del circuito.
"""

from collections import defaultdict
from collections.abc import Callable
from typing import NamedTuple

from disegnatore_mep.catalog.registry import ComponentRegistry
from disegnatore_mep.catalog.schema import PortDefinition
from disegnatore_mep.model.project import PortRef, ProjectModel
from disegnatore_mep.model.types import PortFlow

from .fluidi import porta_la_freccia
from .geometry import FlowKind
from .trunks import Trunk

TrunkKey = tuple[str, ...]
"""Identita' di una tratta: le connessioni che la compongono."""

INBOUND_FUNCTIONS = frozenset({"filling"})
"""I mestieri di chi, da uno stacco, **immette** acqua nel circuito.

Il gruppo di riempimento e' acqua di rete che entra nel ritorno tecnico: la
sua freccia punta dal gruppo verso il circuito (DRAW-005-R1, I-042). E' un
elenco di **funzioni** di catalogo, mai di pezzi (D-069)."""

OUTBOUND_FUNCTIONS = frozenset({"drain"})
"""I mestieri di chi, da uno stacco, **fa uscire** acqua dal circuito: lo
scarico esplicitamente modellato porta il verso uscente, e nessuna freccia
(`FlowKind.OUTBOUND`, I-273).

Appeso all'attacco di una macchina — lo scarico in fondo al volano — prende il
colore del **ritorno**: lo scarico sta nel punto piu' basso, e in fondo a un
accumulo c'e' l'acqua fredda, quella che torna alla macchina. Fino a REL-017
prendeva il colore base del fluido, cioe' quello dell'andata, e il PO l'ha visto
rosso sotto il volano di una villetta (I-273)."""

GENERATOR_FUNCTIONS = frozenset(
    {
        "heat_generation",
        "cooling_generation",
        "refrigerant_generation",
        "gas_combustion",
    }
)
"""Chi produce il fluido caldo o freddo: e' la sorgente naturale di un circuito."""

STORE_FUNCTIONS = frozenset(
    {
        "thermal_storage",
        "dhw_storage",
        "hydraulic_separation",
    }
)
"""Chi lo accumula o lo separa: e' la sorgente del circuito che ne parte.

Un volano e' l'utilizzatore del primario e la sorgente del secondario. Le due
cose non sono in contraddizione: dipende da quale rete si sta guardando, ed e'
per questo che l'orientamento si calcola **una rete alla volta**.
"""

EXCHANGE_FUNCTIONS = frozenset({"heat_exchange"})
"""Chi scambia calore fra due circuiti: lo scambiatore a piastre.

E' una macchina di centrale, non un terminale (I-066, D-138): il PO la nomina
accanto agli accumuli quando detta dove arrivano le autostrade — «dai generatori
agli accumuli **e agli scambiatori**»."""

TERMINAL_FUNCTIONS = frozenset(
    {
        "emission",
        "air_terminal",
        "direct_expansion_terminal",
    }
)
"""Chi consegna il calore all'ambiente: il capolinea della distribuzione.

Sono i «terminali» di D-138, quelli verso cui corre la strada secondaria che la
fase della struttura traccia insieme alle autostrade."""

BOUNDARY_FUNCTION = "boundary"
"""Il mestiere di chi sta al confine dell'impianto: da li' il fluido entra o se
ne va. La posa lo legge per sapere che quel pezzo **non ha una posizione
propria** e va accanto all'utente che serve (I-061, DRAW-009 §A.2)."""

PROVISION_FUNCTION = "provision"
"""Il mestiere dell'attacco predisposto (REL-009, I-197): un tubo tappato che oggi non
porta niente, e che sta per la macchina che verra' — il solare termico."""

LOAD_FUNCTIONS = frozenset(
    {
        "emission",
        "air_terminal",
        "direct_expansion_terminal",
        "thermal_storage",
        "dhw_storage",
        "hydraulic_separation",
        "heat_exchange",
        BOUNDARY_FUNCTION,
    }
)
"""Dove il fluido cede o prende calore, e quindi cambia da mandata a ritorno.

Ci stanno dentro anche gli accumuli: rispetto al circuito che li alimenta un
volano e' un utilizzatore a tutti gli effetti, e la camminata deve fermarcisi.
"""


def _rank(functions: frozenset[str]) -> int:
    if functions & GENERATOR_FUNCTIONS:
        return 2
    if functions & STORE_FUNCTIONS:
        return 1
    return 0


def _sources(
    members: list[str],
    incoming: dict[str, list[Trunk]],
    functions_of: dict[str, frozenset[str]],
    position: dict[str, int],
) -> list[str]:
    """Da dove parte una rete. Due criteri, e il primo viene prima.

    **Chi immette e non riceve e' la sorgente, qualunque mestiere faccia.** Su
    una rete di acqua fredda la sorgente e' l'acquedotto: immette e basta. Il
    bollitore la riceve — e' l'ultimo posto dove il fluido va, non il primo da
    cui viene. Prima contava solo il mestiere, e il mestiere del bollitore
    (tenere una riserva) valeva piu' di quello di un confine di rete: cosi' la
    sorgente dell'acqua fredda risultava il bollitore, la camminata partiva da
    li' **all'indietro**, e **tutta l'adduzione veniva disegnata come un
    ritorno** — con il colore e il tratteggio del ritorno. Sui cinque impianti
    non esisteva una sola tratta di acqua fredda in andata, e l'acqua fredda un
    ritorno non ce l'ha.

    Dove nessuno immette senza ricevere — un circuito chiuso, che e' il caso del
    primario — la sorgente la dice il **mestiere**: prima chi genera, poi chi
    accumula.

    Resta **una sola** sorgente per rete, come prima. Partire da tutte quelle di
    pari mestiere — le due pompe di calore in parallelo — toglierebbe qualche
    tratta indecisa, ma cambia l'ordine con cui il collocatore legge il
    processo, e oggi la disposizione non regge il cambiamento: due impianti su
    tre smettono di entrare nel foglio. E' scritto fra le righe aperte del
    registro degli input del PM, e si fa quando la composizione compatta.
    """
    feeders = [item for item in members if not incoming.get(item)]
    candidates = feeders or members
    return [
        min(
            candidates,
            key=lambda item: (
                -_rank(functions_of.get(item, frozenset())),
                position.get(item, 0),
            ),
        )
    ]


def _walk(
    edges: dict[str, list[Trunk]],
    onward: str,
    source: str,
    functions_of: dict[str, frozenset[str]],
) -> set[TrunkKey]:
    """Le tratte raggiunte partendo dalla sorgente, fermandosi sugli utilizzatori."""
    reached: set[TrunkKey] = set()
    frontier = [source]
    visited = {source}
    while frontier:
        following: list[str] = []
        for component_id in frontier:
            for trunk in edges[component_id]:
                reached.add(trunk.connection_ids)
                beyond: str = getattr(trunk, onward).component_id
                if beyond in visited:
                    continue
                visited.add(beyond)
                if functions_of.get(beyond, frozenset()) & LOAD_FUNCTIONS:
                    continue
                following.append(beyond)
        frontier = following
    return reached


def orient_trunks(
    project: ProjectModel, catalog: ComponentRegistry, trunks: list[Trunk]
) -> dict[TrunkKey, bool | None]:
    """Per ciascuna tratta: `True` mandata, `False` ritorno, `None` indecidibile.

    `None` non e' un fallimento: e' un circuito in cui nessun utilizzatore
    separa l'andata dal ritorno — un anello di sola distribuzione, per esempio —
    e la sola cosa che resta e' guardare come e' venuto il disegno. Chi chiama
    decide come ripiegare; qui non si inventa un verso che il modello non ha.
    """
    functions_of = {
        item.id: frozenset(catalog.resolve(item.definition_id).definition.functions)
        for item in project.components
    }
    position = {item.id: index for index, item in enumerate(project.components)}

    by_network: dict[str, list[Trunk]] = defaultdict(list)
    for trunk in trunks:
        by_network[trunk.network_id].append(trunk)

    oriented: dict[TrunkKey, bool | None] = {}
    for group in by_network.values():
        outgoing: dict[str, list[Trunk]] = defaultdict(list)
        incoming: dict[str, list[Trunk]] = defaultdict(list)
        members: list[str] = []
        for trunk in group:
            outgoing[trunk.start.component_id].append(trunk)
            incoming[trunk.end.component_id].append(trunk)
            for component_id in (trunk.start.component_id, trunk.end.component_id):
                if component_id not in members:
                    members.append(component_id)
        if not members:
            continue

        supply: set[TrunkKey] = set()
        returns: set[TrunkKey] = set()
        for source in _sources(members, incoming, functions_of, position):
            supply |= _walk(outgoing, "end", source, functions_of)
            returns |= _walk(incoming, "start", source, functions_of)
        for trunk in group:
            key = trunk.connection_ids
            in_supply, in_return = key in supply, key in returns
            oriented[key] = None if in_supply == in_return else in_supply
    return oriented


class TrunkFlow(NamedTuple):
    """Cio' che il disegno deve sapere di una tratta prima di instradarla."""

    supply: bool | None
    """Andata o ritorno; `None` solo per una tratta del percorso che la
    topologia non decide. Uno stacco non e' mai indeciso: eredita."""

    kind: FlowKind
    """La specie: flusso ordinario, ramo statico, ingresso, scarico."""

    flow_from_start: bool
    """Il verso del flusso rispetto ai due capi della tratta: da `start` a
    `end`, oppure al contrario."""


def _branch_root(
    trunk: Trunk, ports_of: dict[str, tuple[PortDefinition, ...]]
) -> PortRef | None:
    """L'attacco fuori dal percorso da cui la tratta parte, se e' uno stacco.

    Uno stacco si riconosce dal **catalogo** (D-101): un suo capo sta su un
    attacco che il pezzo dichiara fuori dal percorso — il braccio di un
    raccordo, l'attacco di servizio di una macchina. Nessuna coordinata,
    nessun identificativo."""
    for ref in (trunk.start, trunk.end):
        if any(
            port.id == ref.port_id and port.off_the_run
            for port in ports_of.get(ref.component_id, ())
        ):
            return ref
    return None


def _forward_of(
    trunk: Trunk, ports_of: dict[str, tuple[PortDefinition, ...]]
) -> bool:
    """Il flusso ordinario va da `start` a `end`? Lo dicono le porte.

    Una connessione del modello va sempre da una porta che esce a una che
    entra; ma una tratta ricomposta dagli accessori in linea parte dal capo
    che il file elencava per primo, che puo' essere quello in cui il fluido
    **entra**. La freccia segue il catalogo, non l'ordine del file."""

    def flow_at(ref: PortRef) -> PortFlow | None:
        return next(
            (port.flow for port in ports_of.get(ref.component_id, ()) if port.id == ref.port_id),
            None,
        )

    at_start, at_end = flow_at(trunk.start), flow_at(trunk.end)
    if at_start is PortFlow.OUT or at_end is PortFlow.IN:
        return True
    return not (at_start is PortFlow.IN or at_end is PortFlow.OUT)


Arco = tuple[Trunk, str, str, str]
"""Un arco orientato della camminata del colore: la tratta, il pezzo oltre, l'attacco da
cui si esce dal pezzo di qua e quello da cui si entra nel pezzo di la'."""

Passaggio = Callable[[str, str], frozenset[str] | None]
"""Le porte che comunicano con quella data dentro un pezzo che dichiara i propri
passaggi (`ComponentDefinition.passaggi`); niente per tutti gli altri."""


def _nessun_passaggio(component_id: str, port_id: str) -> frozenset[str] | None:
    return None


def _walk_edges(
    edges: dict[str, list[Arco]],
    source: str,
    functions_of: dict[str, frozenset[str]],
    passaggio: Passaggio = _nessun_passaggio,
) -> set[TrunkKey]:
    """Come `_walk`, su archi gia' orientati: ogni arco porta il pezzo oltre.

    **Dentro un pezzo che dichiara i propri passaggi** si prosegue solo per le porte
    del passaggio da cui si e' entrati (REL-009, I-202): nel collettore con ritorno la
    mandata va alle uscite verso i terminali, e non esce dal ritorno."""
    reached: set[TrunkKey] = set()
    frontier: list[tuple[str, str | None]] = [(source, None)]
    visited: set[tuple[str, frozenset[str] | None]] = {(source, None)}
    while frontier:
        following: list[tuple[str, str | None]] = []
        for component_id, entrata in frontier:
            gruppo = passaggio(component_id, entrata) if entrata is not None else None
            for trunk, beyond, da, a in edges.get(component_id, ()):
                if gruppo is not None and da not in gruppo:
                    continue
                reached.add(trunk.connection_ids)
                chiave = (beyond, passaggio(beyond, a))
                if chiave in visited:
                    continue
                visited.add(chiave)
                if functions_of.get(beyond, frozenset()) & LOAD_FUNCTIONS:
                    continue
                following.append((beyond, a))
        frontier = following
    return reached


def _oriented_for_colour(
    project: ProjectModel, catalog: ComponentRegistry, trunks: list[Trunk]
) -> dict[TrunkKey, bool | None]:
    """Andata e ritorno **per il colore**, dal modello e da tutte le sorgenti.

    `orient_trunks` parte da una sorgente sola per rete e percorre le tratte
    nel verso in cui il file le ha scritte, e lo fa apposta: e' l'ordine con
    cui il collocatore legge il processo, e cambiarlo cambia la disposizione.
    Ma per il colore quella lettura non basta (I-042): con due macchine in
    parallelo la mandata e il ritorno della seconda restano indecisi, e una
    tratta che il file elenca dal capo che entra viene percorsa al contrario.
    Qui, e solo per il colore, si legge il modello com'e' orientato — ogni
    tratta nel verso in cui le sue porte dicono che il fluido la percorre — e
    si cammina da **ogni** sorgente della rete: una tratta raggiunta in avanti
    e' andata, una risalita e' ritorno, indecisa solo chi si raggiunge in
    entrambi i modi o in nessuno. La posa non legge questo.
    """
    functions_of = {
        item.id: frozenset(catalog.resolve(item.definition_id).definition.functions)
        for item in project.components
    }
    ports_of = {
        item.id: tuple(catalog.get(item.definition_id).ports) for item in project.components
    }
    position = {item.id: index for index, item in enumerate(project.components)}
    stored = {
        item.id: catalog.get(item.definition_id).stored_medium for item in project.components
    }
    medium_of = {network.id: network.medium for network in project.networks}
    by_network: dict[str, list[Trunk]] = defaultdict(list)
    for trunk in trunks:
        by_network[trunk.network_id].append(trunk)

    definizioni = {item.id: catalog.get(item.definition_id) for item in project.components}

    def passaggio(component_id: str, port_id: str) -> frozenset[str] | None:
        definizione = definizioni.get(component_id)
        return definizione.passaggio(port_id) if definizione is not None else None

    oriented: dict[TrunkKey, bool | None] = {}
    for network_id, group in by_network.items():
        outgoing: dict[str, list[Arco]] = defaultdict(list)
        incoming: dict[str, list[Arco]] = defaultdict(list)
        members: list[str] = []
        for trunk in group:
            # Uno stacco non e' strada: chi cammina lungo il percorso non ci
            # entra, e un accessorio appeso non e' mai una sorgente.
            if _branch_root(trunk, ports_of) is not None:
                continue
            head, tail = (
                (trunk.start, trunk.end)
                if _forward_of(trunk, ports_of)
                else (trunk.end, trunk.start)
            )
            outgoing[head.component_id].append((trunk, tail.component_id, head.port_id, tail.port_id))
            incoming[tail.component_id].append((trunk, head.component_id, tail.port_id, head.port_id))
            for component_id in (head.component_id, tail.component_id):
                if component_id not in members:
                    members.append(component_id)
        if not members:
            continue
        # Le sorgenti: chi immette e non riceve; altrimenti tutti quelli del
        # mestiere piu' alto — i generatori, o gli accumuli — e non uno solo.
        #
        # **Ma una riserva o un generatore che manda acqua su questa rete ne e'
        # la sorgente anche se un confine immette** (**D-176**). Il ricircolo
        # sanitario rientra dalle utenze per il proprio confine, l'«ACS-R»: quel
        # confine immette e non riceve, ma l'acqua che porta e' quella che
        # l'accumulo ha mandato fuori e che torna a lui — e' il **ritorno**
        # dell'acqua calda, non la sua sorgente. L'acquedotto resta la sorgente
        # dell'acqua fredda: il bollitore quella rete la riceve e basta.
        # Chi questa rete attraversa scambiando calore con un fluido che non e'
        # il suo — la serpentina di un bollitore — la restituisce come ritorno.
        scambiano = frozenset(
            item
            for item in members
            if stored.get(item) is not None and stored[item] != medium_of.get(network_id)
        )
        # **E non ne e' una sorgente** (REL-009, I-202). Il bollitore e' un accumulo,
        # ma della serpentina e' l'utilizzatore: sul circuito di carico, volano e
        # bollitore erano tutti e due sorgenti, le due camminate si contraddicevano, e
        # la mandata della pompa di carico ereditava il ritorno che entra nel volano —
        # blu, sulla tavola del caso reale ricostruito.
        emitters = [
            item
            for item in members
            if outgoing.get(item)
            and _rank(functions_of.get(item, frozenset())) > 0
            and item not in scambiano
        ]
        feeders = [item for item in members if not incoming.get(item)]
        # **Un attacco predisposto sta per la macchina che verra'** (REL-009, I-197):
        # il collettore solare dietro il tappo. Quello che immette ne e' la mandata,
        # quello che riceve il ritorno — non il volano che li ha tutti e due: la
        # mandata entra dall'alto, e «la mandata e' sempre sopra il suo ritorno».
        predisposti_che_ricevono = [
            item
            for item in members
            if not outgoing.get(item) and PROVISION_FUNCTION in functions_of.get(item, frozenset())
        ]
        if feeders and all(PROVISION_FUNCTION in functions_of.get(item, frozenset()) for item in feeders):
            sources = feeders
        elif emitters:
            top = max(_rank(functions_of.get(item, frozenset())) for item in emitters)
            sources = [
                item for item in emitters if _rank(functions_of.get(item, frozenset())) == top
            ]
        elif feeders:
            sources = feeders
        else:
            top = max(_rank(functions_of.get(item, frozenset())) for item in members)
            sources = [item for item in members if _rank(functions_of.get(item, frozenset())) == top]
            if top == 0:
                sources = [min(sources, key=lambda item: position.get(item, 0))]
        supply: set[TrunkKey] = set()
        returns: set[TrunkKey] = set()
        for source in sources:
            supply |= _walk_edges(outgoing, source, functions_of, passaggio)
            returns |= _walk_edges(incoming, source, functions_of, passaggio)
        if sources == feeders and feeders and all(
            PROVISION_FUNCTION in functions_of.get(item, frozenset()) for item in feeders
        ):
            for pozzo in predisposti_che_ricevono:
                returns |= _walk_edges(incoming, pozzo, functions_of, passaggio)
        for trunk in group:
            key = trunk.connection_ids
            in_supply, in_return = key in supply, key in returns
            oriented[key] = None if in_supply == in_return else in_supply
        _eredita_da_monte(outgoing, incoming, functions_of, oriented, scambiano, passaggio)
    return oriented


def _eredita_da_monte(
    outgoing: dict[str, list[Arco]],
    incoming: dict[str, list[Arco]],
    functions_of: dict[str, frozenset[str]],
    oriented: dict[TrunkKey, bool | None],
    scambiano: frozenset[str] = frozenset(),
    passaggio: Passaggio = _nessun_passaggio,
) -> None:
    """**Dove le camminate non decidono, il fluido tiene il ruolo che ha a
    monte**, finche' non attraversa un terminale o una serpentina.

    Le camminate si fermano a ogni utilizzatore, accumuli compresi, e cosi'
    restano indecise le tratte che nessuna delle due raggiunge. Fino al 23
    settembre 2026 il loro colore lo decideva la geometria — mandata se la
    tratta va verso destra (`route.py`) — e un agente in camera pulita ha
    visto il ritorno delle zone dipinto da mandata sull'impianto 3, dove il
    volano sta **in serie sul ritorno** e ferma la camminata che risale dalla
    pompa di calore: ha dovuto scartare una posa migliore perche' la tavola non
    si leggeva. Lo stesso sull'impianto 5, sul by-pass della miscelatrice.

    La lettura e' quella del fluido: chi esce da un terminale e' ritorno, e un
    pezzo che non e' un terminale non cambia il ruolo di quello che lo
    attraversa — la tratta prende il ruolo di tutte quelle che entrano nel suo
    capo a monte, se e' uno solo. Si legge **solo a monte**: dove due fluidi
    si mescolano — il by-pass che entra nella miscelatrice — il ruolo lo porta
    chi arriva, non chi riparte. Le tratte che le camminate hanno deciso non
    si toccano; quelle che restano indecise tornano al ripiego geometrico.

    **Una serpentina cambia il ruolo come un terminale** (`scambiano`): il
    bollitore tiene in serbo acqua sanitaria, e l'acqua di riscaldamento che
    lo attraversa gli cede calore ed esce ritorno. Fino al 2 ottobre 2026 qui
    contavano i soli terminali, e sulla prima tavola del PO uscita da
    claude.ai — volano a due attacchi in serie sul ritorno, che ferma la
    camminata dalla pompa di calore — il ritorno della serpentina ereditava la
    mandata che entra nel bollitore ed era disegnato rosso. Un volano a due
    attacchi tiene in serbo lo stesso fluido della rete: non scambia, e chi lo
    attraversa tiene il proprio ruolo.
    """
    cambiato = True
    while cambiato:
        cambiato = False
        for testa, uscenti in outgoing.items():
            for trunk, _, da, _ in uscenti:
                if oriented.get(trunk.connection_ids) is not None:
                    continue
                if testa in scambiano or functions_of.get(testa, frozenset()) & TERMINAL_FUNCTIONS:
                    ruolo: bool | None = False
                else:
                    # Dentro un pezzo coi passaggi dichiarati il ruolo viene solo da chi
                    # entra nello stesso passaggio (I-202).
                    gruppo = passaggio(testa, da)
                    entranti = {
                        oriented.get(altra.connection_ids)
                        for altra, _, dove, _ in incoming.get(testa, ())
                        if gruppo is None or dove in gruppo
                    }
                    ruolo = entranti.pop() if len(entranti) == 1 else None
                if ruolo is None:
                    continue
                oriented[trunk.connection_ids] = ruolo
                cambiato = True


def classify_trunks(
    project: ProjectModel, catalog: ComponentRegistry, trunks: list[Trunk]
) -> dict[TrunkKey, TrunkFlow]:
    """Servizio, specie e verso di ogni tratta, dal solo modello (I-042).

    Le tratte del percorso prendono andata o ritorno da `orient_trunks` e sono
    flusso ordinario. Uno **stacco** — una tratta che parte da un attacco fuori
    dal percorso — prende:

    - la **specie** dal mestiere di cio' che regge: chi immette (il
      riempimento) e' un ingresso, chi fa uscire (lo scarico) e' uno scarico,
      tutto il resto — misura, espansione, sfiato, sicurezza — e' statico;
    - il **servizio** dalla tratta che lo regge, quando pende da un raccordo:
      il manometro innestato sul ritorno tecnico e' del ritorno tecnico.
      Quando pende direttamente da un attacco di servizio di una macchina — lo
      sfiato in cima al serbatoio — non c'e' una tratta da cui ereditare: il
      volume della macchina non e' ne' andata ne' ritorno, e lo stacco prende
      il colore base del fluido; **lo scarico, che sta in fondo, quello del
      ritorno** (I-273, `OUTBOUND_FUNCTIONS`);
    - il **verso**: l'ingresso guarda verso il tratto che lo regge, lo scarico
      se ne allontana, il ramo statico non ne ha. **La freccia** la porta solo
      l'ingresso: lo scarico e' un rubinetto chiuso e si disegna senza (I-273,
      `FlowKind.porta_la_freccia`).

    Nessuna geometria entra qui, ed e' il contratto: la firma lo dice.
    """
    oriented = _oriented_for_colour(project, catalog, trunks)
    definitions = {item.id: catalog.get(item.definition_id) for item in project.components}
    ports_of = {key: tuple(value.ports) for key, value in definitions.items()}
    result: dict[TrunkKey, TrunkFlow] = {}
    for trunk in trunks:
        key = trunk.connection_ids
        root = _branch_root(trunk, ports_of)
        if root is None:
            result[key] = TrunkFlow(
                supply=oriented.get(key),
                kind=FlowKind.ORDINARY,
                flow_from_start=_forward_of(trunk, ports_of),
            )
            continue
        far = trunk.end if root == trunk.start else trunk.start
        functions = frozenset(definitions[far.component_id].functions)
        if functions & INBOUND_FUNCTIONS:
            kind = FlowKind.INBOUND
        elif functions & OUTBOUND_FUNCTIONS:
            kind = FlowKind.OUTBOUND
        else:
            kind = FlowKind.STATIC
        root_at_start = root == trunk.start
        # Verso il capo radice per chi entra, via da esso per chi esce.
        flow_from_start = root_at_start if kind is FlowKind.OUTBOUND else not root_at_start
        # Il colore base del fluido per chi pende da una macchina; per lo scarico,
        # che sta nel punto piu' basso dove l'acqua torna fredda, quello del
        # ritorno (I-273). Da un raccordo, quello della tratta che lo regge.
        supply: bool | None = kind is not FlowKind.OUTBOUND
        if definitions[root.component_id].is_a_fitting:
            hosts = {
                oriented.get(other.connection_ids)
                for other in trunks
                if other is not trunk
                and any(
                    ref.component_id == root.component_id
                    and _branch_root(other, ports_of) != ref
                    and not any(
                        port.id == ref.port_id and port.off_the_run
                        for port in ports_of[ref.component_id]
                    )
                    for ref in (other.start, other.end)
                )
            } - {None}
            supply = hosts.pop() if len(hosts) == 1 else True
        result[key] = TrunkFlow(supply=supply, kind=kind, flow_from_start=flow_from_start)
    # **Le linee di un fluido senza freccia** (REL-012): il refrigerante di una
    # macchina reversibile, l'elettrico, il bus. Il verso resta dove il modello lo
    # dice; la freccia no. La convenzione e' in `layout.fluidi`, e si cambia li'.
    fluidi = {item.id: item.medium for item in project.networks}
    for trunk in trunks:
        if not porta_la_freccia(fluidi.get(trunk.network_id, "")):
            result[trunk.connection_ids] = result[trunk.connection_ids]._replace(
                kind=FlowKind.NO_ARROW
            )
    return result


__all__ = [
    "EXCHANGE_FUNCTIONS",
    "INBOUND_FUNCTIONS",
    "OUTBOUND_FUNCTIONS",
    "TERMINAL_FUNCTIONS",
    "TrunkFlow",
    "TrunkKey",
    "classify_trunks",
    "orient_trunks",
]
