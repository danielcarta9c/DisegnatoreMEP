"""Disegnatore MEP deterministic core."""

__version__ = "1.14.0"
