"""⛔ **MORTO IL 20 SETTEMBRE 2026, E RESTA AGLI ATTI.**

**Quando:** 20 settembre 2026. **Perche':** **D-151** — «il disegno lo compone un
agente, non lo trova un solutore». **Dove e' finito il suo lavoro:** la posa la
decide ora il **piano di composizione** (`disegnatore_mep.piano`), che un agente
scrive e il motore esegue; il revisore (`piano/revisore.py`) chiude l'anello.
L'architettura sta in `docs/ARCHITETTURA-DEL-PIANO.md`.

**Nessun percorso vigente chiama piu' questo modulo.** `layout/compose.py` non lo
importa piu'. Quello che segue descrive il prodotto **fino al 20 settembre**, e
si legge come storia: la somma pesata, le sue sette manopole, e il greedy che le
minimizzava.

**Perche' non e' stato cancellato.** Un file che nessuno chiama e **non lo
dichiara** e' una trappola: e' cosi' che la ricerca del 4 agosto e' rimasta
inattuata per sei settimane. Qui la dichiarazione e' questa, in testa. Il
difetto non era la taratura: era la **forma della domanda** — una somma pesata
non sa esprimere una gerarchia di giudizio, e nessun peso dice «un collettore e'
**una** linea dritta». Il giorno in cui servisse un ottimizzatore locale sopra
un piano gia' composto, quello che c'e' qui dentro e' ancora buono; oggi no.

---

La posa finale, decisa dal costo delle tubazioni (D-078, D-080, DRAW-002).

Il PO, sulla tavola di DRAW-001 (I-021): «bisogna spostare le macchine perche'
spostare le macchine costa zero; invece incroci, curve e lunghezze costano». E
prima ancora (D-078): «non devi mettere gli oggetti in tavola e poi fare le
linee — o meglio lo fai, ma poi gli oggetti si spostano per ottimizzare il
routing, non viceversa».

Qui `place.py` ha gia' dato una posa iniziale valida e ordinata per processo;
questo modulo decide la posa **finale** reinstradando l'intera tavola a ogni
prova. Tre regole, nell'ordine del pacchetto DRAW-002:

1. **Un solo confronto esplicito della tavola**, `SheetCost`, con precedenza
   lessicografica: violazioni bloccanti e tratte che non ospitano i propri
   accessori; tratte con andata e ritorno; millimetri di andata e ritorno;
   tratte oltre tre pieghe; pieghe; incroci; lunghezza; e solo come spareggio
   fra geometrie uguali su tutte e sette, riempimento e bilanciamento. Nessun
   peso: una voce successiva non compensa mai una precedente, e il movimento
   dei simboli non entra nel costo.
2. **Niente distensione.** Prima il ciclo, finite le linee, allontanava i
   pezzi dal centro per inseguire il 60 % di riempimento pagando in lunghezza
   di tubo: quel comportamento e' rimosso. `fill` e `imbalance` restano misure
   diagnostiche e spareggi, mai ragioni per aumentare tubo, curve, incroci o
   andate e ritorno.
3. **Le pose vengono dalla topologia, non da distanze prefissate.** I candidati
   si ricavano dalle coordinate delle porte e dei vicini collegati: la quota
   che allinea due porte, la distanza minima che lascia il rettilineo agli
   accessori in linea, la rotazione che rivolge una porta verso il proprio
   collegamento, la catena di raccordi rimessa in fila dalla porta del pezzo
   grosso, la traslazione di una pila o di una colonna come gruppo, lo
   spostamento di tutto cio' che sta oltre un pezzo verso il pezzo che lo
   precede. Possono valere anche molti passi di griglia.

E da DRAW-004 (I-026, I-027, I-029) il ciclo ragiona come un disegnatore:
prima gli assi fra le porte delle macchine e le dorsali continue, poi gli
stacchi. Sono **candidati**, non regole: si generano e si confrontano con la
posa corrente sul solo `SheetCost`.

- **Assi fra le porte.** Per ogni collegamento verso un pari: la mia colonna
  sull'asse della sua porta, la sua colonna sull'asse della mia, e le due
  colonne su un asse comune a meta' strada. Anche in verticale, e anche per
  chi sta a terra: la quota iniziale e' un suggerimento di posa, non un
  vincolo, e il modello non dichiara vincoli fisici che la impongano.
- **Dorsale prima, stacchi dopo.** La catena di raccordi rimessa in fila dalla
  porta di un pezzo grosso, con ogni raccordo che prosegue diritto, e il pezzo
  grosso all'altro capo portato sull'asse d'uscita della catena — o affacciato
  alla distanza minima — cosi' che la sequenza principale resti rettilinea e i
  rami partano dai raccordi che stanno sull'asse.
- **La T che assorbe una curva.** Un raccordo a T si disegna come un punto e
  ha tre attacchi uguali: quale attacco fisico serva ciascuna porta del
  modello e' una proprieta' della posa (`PlacedSymbol.port_map`), non del
  grafo. Le rotazioni ammesse dal simbolo e le permutazioni fra attacchi
  dello stesso dominio e fluido sono candidati: il percorso principale puo'
  usare due attacchi ortogonali e girare nel raccordo invece che in un gomito
  a parte. Vince solo se la tavola completa costa meno.

Ogni candidato si misura **dopo `settle_sheet`**, accessori in linea posati e
tutte le tratte reinstradate: e' la stessa funzione con cui `compose_sheet`
disegna, quindi cio' che si misura e' cio' che esce. Nessuna approssimazione su
geometrie parziali.

Vincoli mai violabili, qualunque sia il guadagno:

- l'ordine di processo da sinistra a destra (D-060), letto sul verso del
  fluido: una tratta di mandata non porta la meta a sinistra della sorgente,
  una di ritorno non la porta a destra; dove il verso non e' deciso l'ordine
  disegnato non cambia. Una posa iniziale che gia' contraddice il verso puo'
  essere corretta, mai peggiorata;
- le distanze minime fra simboli, la griglia, l'area di disegno;
- una pila o una colonna non si sfila di un elemento: si trasla insieme, e
  una pila a terra conserva l'ordine dei propri membri (chi sta sopra resta
  sopra) e il proprio interasse non scende sotto lo stacco di fascia;
- determinismo: candidati in ordine fisso, accettazione della prima mossa che
  batte la posa corrente sul confronto unico, tetto dichiarato di prove.

Il ciclo e' greedy e reversibile: ogni mossa accettata batte strettamente la
precedente, quindi termina; il tetto di instradamenti di prova lo ferma comunque
in un punto che dipende solo dagli ingressi.
"""

from collections.abc import Iterable
from enum import IntEnum
from itertools import permutations
from typing import NamedTuple

from disegnatore_mep.catalog.registry import ComponentRegistry
from disegnatore_mep.catalog.schema import FITTING_FUNCTIONS
from disegnatore_mep.graphics.frame import Rect, SheetFrame
from disegnatore_mep.graphics.symbol import PortFace, SymbolManifest, SymbolPort
from disegnatore_mep.model.project import ProjectModel

from .composition import Standing, levels_of, standing_of
from .errors import LayoutError
from .flow import TrunkKey, orient_trunks
from .geometry import (
    INK_COVERAGE_MIN,
    SHEET_FILL_MAX_RATIO,
    SHEET_FILL_MIN_RATIO,
    SHEET_MARGIN_MM,
    PlacedSymbol,
    Point,
    RoutedTrunk,
    box_of,
    fill_ratio,
    ink_box,
    ink_coverage,
    ink_imbalance,
    margin_allowed_mm,
    overshoot_mm,
    run_intrudes_on,
)
from .grid import GridSpace, is_on_grid
from .hierarchy import Level, hierarchy_of, spine_machines, weight_of
from .highways import Highway, highways, lies_in_line
from .inline import SettledSheet, settle_sheet
from .partition import SheetPartition
from .place import (
    ROUTING_MARGIN_MM,
    ROW_GAP_MM,
    hanging_children,
    hanging_ports,
    inline_room_mm,
    run_chains,
    stub_minimum_mm,
)
from .route import CROSS_COST, STEP_COST, TURN_COST
from .spine import SpineLayout
from .trunks import Trunk

MAX_PASSES = 12
"""Passate del ciclo: ognuna scorre tutti i pezzi una volta.

Una passata senza mosse accettate chiude il ciclo; dodici lo chiudono comunque.
Il numero e' un limite di sicurezza, non un obiettivo: il tetto che governa il
costo e' quello degli instradamenti di prova.
"""

MAX_TRIAL_ROUTINGS = 1500
"""Tetto di instradamenti di prova per foglio: il limite di ricerca dichiarato.

Raggiunto il tetto si restituisce la migliore posa trovata fin li'. Scatta in
modo deterministico — stessi ingressi, stesse prove, stesso punto di arresto —
quindi non costa la riproducibilita'. Ogni prova e' un `settle_sheet` completo,
e vale circa un decimo di secondo sull'impianto 1.
"""

MAX_AXIS_TRIALS = 2000
"""Tetto di instradamenti di prova della seconda fase, quella degli assi.

Il ciclo lavora in due fasi (DRAW-004): prima la posa di DRAW-002, con le
sue candidate e il suo tetto; poi, dall'ottimo raggiunto, la rifinitura da
disegnatore — assi fra le porte, dorsali, la T che gira, le quote delle
macchine — con un tetto proprio, perche' la seconda fase non consumi la
prima. Anche questo scatta in modo deterministico.
"""

STRETCH_STEPS = (2, 4, 8)
"""Gli allungamenti ciechi del tronco, in passi di griglia (DRAW-008 §B.2).

Oltre a quello **calcolato** — esattamente il rettilineo che manca al corredo —
qualche allungamento in piu', perche' il corredo che non entra non e' sempre
quello della tratta che si allunga: a volte e' il vicino che ruba la corsia.
"""

BLOCK_STEPS = (1, 2, 3, 4, 6, 8, 10)
"""Le traslazioni di blocco, in passi di griglia (DRAW-009 §B).

Il PO, il 12 settembre 2026, correggendo la lettura che DRAW-008 aveva
adottato: **il tronco e' un corpo rigido, non un corpo immobile.** Trasla tutto
intero e porta con se' cio' che gli sta appeso; se il corredo dell'ACS non sta
sotto, si alzano le macchine di spina. La misura del PM sulla tavola 2 dice che
la mossa buona sta intorno agli otto passi, e sotto i due non cambia niente:
l'elenco copre quell'arco e si ferma, perche' ogni passo e' un instradamento di
prova e il tetto delle prove e' quello.
"""

NUDGE_STEPS = (1, 2, 4, 8)
"""Le traslazioni cieche, in passi di griglia: l'ultima risorsa, dopo le mosse
ricavate dalle porte. Servono a scansare un ostacolo che nessuna porta indica."""

LIFT_STEPS = (1, 2, 4, 6)
"""Le traslazioni verticali gratuite di una macchina, in passi di griglia
(I-046): la prima risorsa, non l'ultima. Spostare una macchina non costa;
curve, incroci e lunghezza si'."""

SLACK_STEPS = (0, 2, 4)
"""Il gioco in piu' provato oltre la distanza minima, in passi di griglia.

La distanza minima e' quella che lascia il rettilineo agli accessori in linea;
qualche passo in piu' serve quando un altro pezzo o una tratta altrui occupano
proprio quel rettilineo.
"""

BENDS_PER_RUN_MAX = 3
"""Pieghe oltre le quali una tratta e' un giro attorno a qualcosa (B4, D-060).

Lo stesso numero che il preflight usa per il proprio avviso.
"""

_TOLERANCE_MM = 1e-6
_HORIZONTAL_FACES = (PortFace.LEFT, PortFace.RIGHT)
_DIRECTION: dict[PortFace, tuple[float, float]] = {
    PortFace.RIGHT: (1.0, 0.0),
    PortFace.BOTTOM: (0.0, 1.0),
    PortFace.LEFT: (-1.0, 0.0),
    PortFace.TOP: (0.0, -1.0),
}

class Phase(IntEnum):
    """Le tre fasi della posa (DRAW-008), nell'ordine che il PO ha fissato.

    Ordinate perche' la validita' di una mossa dipende da **quanto avanti** si
    e': ogni fase eredita gli invarianti di quelle prima e non puo' comprarli.
    """

    TRONCO = 0
    """La forma del tronco: la costruisce `spine.lay_the_spine`, non il ciclo."""

    CORREDO = 1
    """Valvole, filtri e raccordi entrano nel tronco. Se non ci stanno, il
    tronco si allunga: due macchine di spina si allontanano lungo l'asse."""

    SERVIZIO = 2
    """Stacchi, diramazioni e appesi si attaccano a un tronco fermo: le
    macchine di spina non si muovono piu', e nessuna curva piega un'autostrada."""


Move = dict[str, PlacedSymbol]
"""Una candidata: i soli simboli che cambiano posa, gia' posati dove andrebbero."""

PortMap = dict[str, str]
"""Quale attacco fisico serve ciascuna porta del modello; vuoto e' l'identita'."""

Orientation = tuple[int, tuple[tuple[str, str], ...]]
"""Una rotazione e una permutazione degli attacchi, come chiave ordinabile."""

Signature = tuple[tuple[str, float, float, int, tuple[tuple[str, str], ...]], ...]


CostKey = tuple[int, int, float, int, int, int, float, float]
"""La chiave d'ordine di `SheetCost`, scritta una volta sola.

Le voci sono **otto** da **D-149**: erano nove, e la nona era il riempimento,
che il PO ha tolto dagli obiettivi. Resta il **margine di rispetto** (D-143),
infilato da `DRAW-013` fra gli attraversamenti e lo spareggio.

Vive qui, e non ripetuta in ogni firma, perche' la volta scorsa che e' cambiata
il tipo del diario e' andato fuori sincrono senza che niente se ne accorgesse
fino a `mypy` — ed e' successo di nuovo con D-149, che questa riga ha preso.
"""


class Attempt(NamedTuple):
    """Una riga del diario del ciclo: una candidata provata, e com'e' andata.

    Il rapporto di collaudo deve dire quali alternative di asse sono state
    provate e perche' quella finale ha vinto (DRAW-004): qui restano la
    specie della candidata, il pezzo per cui e' stata generata, la chiave di
    costo misurata — `None` se la posa non si lascia instradare — e se e'
    stata accettata.
    """

    phase: str
    """La fase in cui la candidata e' stata provata: `posa` (la prima posa
    instradabile), `corredo` e `servizio` (DRAW-008 §B e §C), `rifinitura`
    (DRAW-004)."""

    kind: str
    leader: str
    cost: CostKey | None
    accepted: bool


class PortPair(NamedTuple):
    """Due porte che il fluido collega, e cio' che sta in mezzo.

    `through` sono i pezzi attraversati per arrivarci: vuoto quando le due
    porte sono i capi della stessa tratta, e altrimenti i raccordi, gli
    accessori in linea e i multivia che la corsa percorre. Serve al rapporto
    di collaudo, che deve poter dire **attraverso cosa** un asse e' stato
    provato.
    """

    my_port: str
    peer_id: str
    peer_port: str
    through: tuple[str, ...] = ()


FILL_WINDOW = (SHEET_FILL_MIN_RATIO, SHEET_FILL_MAX_RATIO)
"""La finestra del riempimento (**D-140**): ne' troppo poco ne' troppo.

Le due sponde stanno in `layout.geometry`, accanto alla misura, e non qui: le
leggono il **preflight**, che avvisa a tavola finita, e questo **costo**, che le
insegue mentre dispone. Un numero solo, in un posto solo — se divergessero, il
ciclo crederebbe di aver riempito un foglio che il controllo vede vuoto.

Sotto il 45 % il disegno e' vuoto e stretto insieme; sopra il 65 % non ci sta
piu' lo spazio per le sigle dei componenti. La percentuale si misura sull'area
di disegno, che e' gia' al netto del cartiglio e della legenda — su una A3,
350 x 235 mm — ed e' la stessa che `fill_ratio` calcola.

⛔ **Non e' un traguardo**, ed e' precisamente per questo che e' una finestra:
cio' che D-134 rifiutava — inseguire una percentuale sempre piu' alta — resta
rifiutato. Il PO (**D-139**): «i mm non sono un vero costo da misurare, lo e'
piu' avere un buon riempimento, ne' troppo poco ne' troppo».
"""


class SheetCost(NamedTuple):
    """Il valore confrontabile della geometria completa, nell'ordine del pacchetto.

    Si confronta con `beats`, che e' l'ordine lessicografico delle voci di
    `key()`: la prima che differisce decide.

    **Che cosa costa, da D-139.** Le violazioni, l'andata e ritorno, le tratte
    troppo piegate, poi i due costi veri del disegno — le **curve** e, in
    secondo luogo, gli **attraversamenti** — e infine il **riempimento**, letto
    dentro la sua finestra. Il bilanciamento chiude la fila.

    ⛔ **La lunghezza non e' piu' una voce di costo.** Resta nella tupla, e si
    riporta, ma **come misura e non come giudizio**: `key()` non la legge. Il PO
    (D-139): «i mm non sono un vero parametro». Finche' stava fra
    `crossings` e il riempimento era lei che, a parita' di curve e
    attraversamenti, decideva **sempre** per la posa piu' corta — e il
    riempimento, ultimo dopo di lei, non poteva mai comprare un millimetro. E'
    la compattazione che si misurava sulla tavola 2: 257,5 mm occupati su 350
    disponibili, con il foglio libero a destra.
    """

    violations: int
    """Tratte che non ospitano i propri accessori, e accessori posati addosso a
    una tratta altrui o a un simbolo: cio' che il preflight blocca."""

    turnback_runs: int
    """Tratte con andata e ritorno (B12, D-078)."""

    turnback_mm: float
    """Millimetri complessivi di andata e ritorno."""

    long_runs: int
    """Tratte oltre le tre pieghe (B4)."""

    bends: int
    """Pieghe, **pesate per gerarchia** (DRAW-007 §B): non e' il numero di
    pieghe della tavola, e' il loro costo. Il numero vero si legge sulla
    geometria, dove lo leggono le misure di collaudo."""

    crossings: int
    """Incroci, pesati per gerarchia come le pieghe."""

    margin_gap: float
    """Di quanto il disegno rinuncia al margine di rispetto (**D-143**).

    Zero quando l'ingombro ci sta con i venticinque millimetri per lato che il
    PO chiede; cresce fino a quindici quando il disegno e' cosi' largo che il
    margine deve stringersi fino al suo minimo. **Sta prima del riempimento**
    nella chiave, e non e' un ordine casuale: un disegno che si allarga fino al
    bordo per far salire una percentuale e' esattamente cio' che il PO ha
    bocciato — «non si mettono gli oggetti cosi' vicini al bordo del foglio». Lo
    spazio comodo si prende **dopo**, con la dilatazione, che il margine limita.
    """

    fill: float
    """Riempimento dell'area di disegno: **non** si legge da solo (D-141)."""

    coverage: float
    """Quanta parte dell'ingombro porta davvero inchiostro (D-141).

    Sta accanto al riempimento e non altrove perche' il riempimento **si gonfia
    spostando un pezzo in un angolo**: il rettangolo cresce, la percentuale
    sale, e il disegno resta vuoto come prima. Finche' il riempimento era una
    misura il difetto non contava; adesso che e' un obiettivo, qualcuno lo
    farebbe."""

    imbalance: float
    """Squilibrio dell'inchiostro fra i quadranti: spareggio, meno e' meglio."""

    length_mm: float
    """Millimetri di tubo, pesati per gerarchia. **Misura, non giudizio**
    (D-139): sta in fondo alla tupla e `key()` non la legge."""

    @property
    def fill_gap(self) -> float:
        """Quanto la tavola e' lontana dall'essere **ben riempita**.

        Zero e' il bersaglio, e ci si arriva da tutt'e due i lati: e' la
        finestra di D-140, non una percentuale da inseguire. Una posa piu'
        vuota e una piu' stretta della finestra costano tutt'e due, ed e'
        esattamente cio' che «ne' troppo poco ne' troppo» vuol dire.

        **E non si legge mai da solo** (D-141): accanto alla distanza dalla
        finestra sta quanto l'ingombro e' spoglio, e vince — cioe' costa — la
        peggiore delle due. Cosi' una posa che alza il riempimento spingendo un
        pezzo in un angolo **non guadagna niente**: il riempimento entra nella
        finestra ma la copertura crolla, e la voce peggiora invece di
        migliorare. Un numero solo, con dentro la propria guardia: due voci
        separate avrebbero lasciato la seconda a fare da spareggio della prima,
        che e' il modo in cui il trucco tornerebbe a pagare.
        """
        low, high = FILL_WINDOW
        outside = max(low - self.fill, self.fill - high, 0.0)
        bare = max(INK_COVERAGE_MIN - self.coverage, 0.0)
        return max(outside, bare)

    def key(self) -> CostKey:
        """La chiave d'ordine: le sei voci, il margine, lo spareggio.

        **Non ci sono ne' la lunghezza ne' il riempimento**, e per la stessa
        ragione. La lunghezza e' uscita con D-139; il riempimento esce con
        **D-149**, dopo tre pacchetti passati a inseguirlo:

        > «Toglierei anche questa cosa dello stretch e del riempimento foglio.
        > Ha dato solo risultati peggiori. Prima il disegno era meglio.»

        Tutt'e due restano nella tupla come **misure**, e il rapporto le porta;
        nessuna delle due decide piu' niente. Con loro esce anche la copertura
        dell'ingombro, che era la **guardia** del riempimento (D-141) e non
        aveva senso da sola: sorvegliava un obiettivo che adesso non c'e'.

        Resta il **margine** di D-143, che non e' un riempimento al contrario:
        dice che il disegno non tocca il bordo, e il PO l'ha chiesto guardando
        la tavola.
        """
        return (
            self.violations,
            self.turnback_runs,
            round(self.turnback_mm, 3),
            self.long_runs,
            self.bends,
            self.crossings,
            round(self.margin_gap, 3),
            round(self.imbalance, 6),
        )

    def beats(self, other: "SheetCost") -> bool:
        """Vero se questa geometria e' strettamente migliore dell'altra.

        Una riga sola, adesso che il riempimento e' uscito dalla chiave
        (**D-149**). Qui stavano la guardia di D-141 — il riempimento salito
        mentre la copertura scendeva non valeva — e l'interruttore `on_fill`
        con cui si giudicava un allungo senza leggere il riempimento (D-142
        §A.3). Nessuna delle due ha piu' un oggetto: quello che
        sorvegliavano non entra piu' nel confronto.

        **Lo stiramento del singolo tratto resta ammesso**, e resta ammesso per
        la sola ragione per cui il contratto lo ammetteva: far entrare il
        corredo dove non ci sta. Non serviva un interruttore a impedirgli di
        comprare riempimento — non c'e' piu' riempimento da comprare.
        """
        return self.key() < other.key()


class Measured(NamedTuple):
    """Una posa misurata: il suo costo e la tavola instradata da cui viene."""

    cost: SheetCost
    settled: SettledSheet


def objective_of(routes: list[RoutedTrunk], step_mm: float) -> int:
    """L'obiettivo storico del PM, intero: pieghe, attraversamenti, lunghezza
    (D-060), con i pesi dell'instradatore. Resta come misura di confronto delle
    prove: il ciclo non lo usa piu' per decidere, decide `SheetCost`."""
    total = 0
    for route in routes:
        for segment in route.segments:
            total += TURN_COST * max(len(segment) - 2, 0)
            length = sum(
                abs(after.x_mm - before.x_mm) + abs(after.y_mm - before.y_mm)
                for before, after in zip(segment, segment[1:], strict=False)
            )
            total += STEP_COST * round(length / step_mm)
        total += CROSS_COST * len(route.crossings)
    return total


def overshoot_beyond_goal_mm(route: RoutedTrunk, goal: Point) -> float:
    """Di quanto la tratta supera la porta di destinazione per poi tornarci (B12).

    Il corollario di D-078: «un componente non si raggiunge mai con un'andata
    e ritorno; se la linea lo supera e torna indietro, e' l'oggetto a essere
    nel posto sbagliato». Il confine e' la perpendicolare per la porta di
    arrivo: per un approccio orizzontale e' la verticale per la porta, per uno
    verticale l'orizzontale. Ogni punto della spezzata oltre quel confine, nel
    verso di arrivo, e' un'andata oltre la meta che la tratta deve disfare.

    Non e' la stessa cosa che misura `geometry.overshoot_mm`, che guarda la
    spezzata disegnata e vede se torna su se stessa; il ciclo le conta **tutte
    e due**, perche' sono due difetti e non due nomi dello stesso.
    """
    if not route.segments:
        return 0.0
    last = route.segments[-1]
    if len(last) < 2:
        return 0.0
    end, before = last[-1], last[-2]
    horizontal = abs(end.x_mm - before.x_mm) > abs(end.y_mm - before.y_mm)
    points = [point for segment in route.segments for point in segment]
    if horizontal:
        sign = 1.0 if end.x_mm > before.x_mm else -1.0
        overshoot = max((point.x_mm - goal.x_mm) * sign for point in points)
    else:
        sign = 1.0 if end.y_mm > before.y_mm else -1.0
        overshoot = max((point.y_mm - goal.y_mm) * sign for point in points)
    return max(overshoot, 0.0)


def overshoots_the_goal(route: RoutedTrunk, goal: Point) -> bool:
    """Vero se la tratta supera la porta di destinazione per poi tornarci (B12)."""
    return overshoot_beyond_goal_mm(route, goal) > _TOLERANCE_MM


def _relation(left: float, right: float) -> int:
    return (left > right) - (left < right)


def _centred_on(
    box: tuple[float, float, float, float] | None,
    area: tuple[float, float, float, float],
) -> tuple[float, float, float, float]:
    """L'area di disegno **come la vedra' il blocco una volta centrato**.

    Il ciclo sceglie una posa, e dopo di lui la composizione porta il blocco al
    centro del foglio: misurare i quadranti dove i pezzi stanno adesso vuol dire
    misurare una tavola che non uscira'. Si trasla il rettangolo, non la posa.
    """
    if box is None:
        return area
    centre_x = (box[0] + box[2]) / 2.0
    centre_y = (box[1] + box[3]) / 2.0
    half_width = (area[2] - area[0]) / 2.0
    half_height = (area[3] - area[1]) / 2.0
    return (
        centre_x - half_width,
        centre_y - half_height,
        centre_x + half_width,
        centre_y + half_height,
    )


def _snap_up(value_mm: float, step_mm: float) -> float:
    """Il primo multiplo del passo non inferiore al valore."""
    steps = int(value_mm / step_mm)
    if value_mm - steps * step_mm > _TOLERANCE_MM:
        steps += 1
    return steps * step_mm


def _admitted_permutations(
    manifest: SymbolManifest, ports: list[tuple[str, str]], functions: frozenset[str]
) -> list[PortMap]:
    """Le permutazioni degli attacchi che il catalogo e il simbolo ammettono.

    L'identita' viene sempre prima. Le altre esistono solo per un **raccordo**:
    un pezzo che il catalogo dichiara semanticamente come tale — le funzioni di
    `FITTING_FUNCTIONS`, unire due tubazioni o aprire una derivazione — con
    almeno tre attacchi, tutti dello stesso dominio e fluido e tutti presenti
    nel manifesto. Un raccordo si disegna come un punto e ogni suo attacco
    vale l'altro. Tutto il resto non ne ammette nessuna, anche se ha tre o
    piu' porte dello stesso fluido: in una valvola miscelatrice, in una
    deviatrice, in un collettore o in un accumulo ogni porta ha un ruolo, e
    scambiarle cambierebbe l'impianto, non il disegno. Il criterio e' la
    funzione dichiarata dal catalogo (D-069), mai il nome del pezzo.
    """
    identity: PortMap = {}
    if not functions & FITTING_FUNCTIONS:
        return [identity]
    ids = [port_id for port_id, _ in ports]
    if len(ids) < 3 or len({kind for _, kind in ports}) != 1:
        return [identity]
    if any(port_id not in manifest.port_ids for port_id in ids):
        return [identity]
    found: list[PortMap] = [identity]
    for order in permutations(ids):
        mapping = {mine: physical for mine, physical in zip(ids, order, strict=True) if mine != physical}
        if mapping:
            found.append(mapping)
    return found


def _signature(layout: Move) -> Signature:
    return tuple(
        (
            item.component_id,
            item.origin.x_mm,
            item.origin.y_mm,
            item.rotation_deg,
            tuple(sorted(item.port_map.items())),
        )
        for item in layout.values()
    )


def _too_close(one: PlacedSymbol, two: PlacedSymbol, gap_mm: float) -> bool:
    """Vero se i due riquadri si toccano, contando lo stacco fra figure diverse."""
    return (
        one.origin.x_mm < two.right_mm + gap_mm - _TOLERANCE_MM
        and two.origin.x_mm - gap_mm < one.right_mm - _TOLERANCE_MM
        and one.origin.y_mm < two.bottom_mm + gap_mm - _TOLERANCE_MM
        and two.origin.y_mm - gap_mm < one.bottom_mm - _TOLERANCE_MM
    )


def _same_pose(one: PlacedSymbol, two: PlacedSymbol) -> bool:
    return (
        one.origin == two.origin
        and one.rotation_deg == two.rotation_deg
        and one.port_map == two.port_map
    )


class Improver:
    """Il ciclo di miglioramento di un foglio, con le sue letture della posa.

    Si costruisce sulla posa iniziale e la migliora con `run`. I metodi
    `candidates`, `is_valid` e `measure` sono pubblici perche' le prove generali
    del pacchetto verificano **quali** mosse il ciclo sa generare, non solo
    dove arriva.
    """

    def __init__(
        self,
        project: ProjectModel,
        partition: SheetPartition,
        catalog: ComponentRegistry,
        frame: SheetFrame,
        placed: list[PlacedSymbol],
        inline_ids: frozenset[str],
        spine_layout: SpineLayout | None = None,
        conceded: frozenset[TrunkKey] = frozenset(),
    ) -> None:
        self.project = project
        self.partition = partition
        self.catalog = catalog
        self.frame = frame
        self.inline_ids = inline_ids
        self.trunks: list[Trunk] = list(partition.trunks)
        # La gerarchia della tavola, calcolata una volta sola e letta da qui in
        # avanti: il costo la pesa, l'obiettivo di allineamento la guarda. Il
        # conto vive in `hierarchy.py` e in nessun altro posto (DRAW-007 §A.2).
        self.hierarchy = hierarchy_of(project, catalog, self.trunks)
        self.spine = spine_machines(project, catalog)
        self.order = [item.component_id for item in placed]
        self.best: Move = {item.component_id: item for item in placed}
        # L'ordine di scansione e' quello della posa iniziale letta da sinistra
        # a destra e dall'alto in basso, mai quello dei nomi: due impianti
        # uguali con identificativi diversi devono dare la stessa tavola.
        self.scan = sorted(
            self.order,
            key=lambda item: (
                self.best[item].origin.x_mm,
                self.best[item].origin.y_mm,
                self.best[item].symbol_id,
            ),
        )

        drawing = frame.drawing_rect_mm
        # Lo stesso rettangolo ridotto dentro cui `place_sheet` posa: il
        # corridoio di instradamento lungo il bordo resta libero.
        self.area = Rect(
            x_mm=drawing.x_mm + ROUTING_MARGIN_MM,
            y_mm=drawing.y_mm + ROUTING_MARGIN_MM,
            width_mm=drawing.width_mm - 2 * ROUTING_MARGIN_MM,
            height_mm=drawing.height_mm - 2 * ROUTING_MARGIN_MM,
        )
        self.sheet_rect = (drawing.x_mm, drawing.y_mm, drawing.right_mm, drawing.bottom_mm)
        self.grid = GridSpace(origin=drawing, standard=frame.standard)
        self.step = self.grid.step_mm
        self.clearance = frame.standard.min_clearance_mm
        self.levels = levels_of(drawing.y_mm, drawing.height_mm, self.step)

        definitions = {item.id: item.definition_id for item in project.components}
        # La voce di catalogo di ciascun pezzo posato: la legge chi cammina
        # lungo le tratte per sapere che cosa si attraversa e a quali
        # condizioni (DRAW-006-R1, blocco B).
        self.definitions = {
            item.component_id: catalog.get(definitions[item.component_id])
            for item in placed
        }
        self.upright: dict[str, SymbolManifest] = {}
        self.features: dict[str, tuple[frozenset[str], bool]] = {}
        self.permutations: dict[str, list[PortMap]] = {}
        for item in placed:
            resolved = catalog.resolve(definitions[item.component_id])
            self.upright[item.component_id] = resolved.symbol.manifest
            self.features[item.component_id] = (
                frozenset(resolved.definition.functions),
                resolved.is_inline,
            )
            # Le permutazioni ammesse: solo per un raccordo — cosi' lo dice il
            # catalogo, con le sue funzioni — fra attacchi dello stesso dominio
            # e fluido. Una valvola a tre vie o un collettore hanno tre porte
            # dello stesso fluido e non ne ammettono nessuna: ogni porta ha un
            # ruolo.
            self.permutations[item.component_id] = _admitted_permutations(
                resolved.symbol.manifest,
                [(port.id, f"{port.domain}:{port.medium}") for port in resolved.definition.ports],
                frozenset(resolved.definition.functions),
            )
        self._turned: dict[tuple[str, int], SymbolManifest] = {}
        self.standings = {
            item.component_id: self.standing_at(item.component_id, item.rotation_deg)
            for item in placed
        }

        # Il verso del fluido, che decide l'ordine di processo (D-059, D-060).
        self.flow = orient_trunks(project, catalog, self.trunks)

        # Le figure: chi pende da chi, e chi sta in fila su una tratta.
        placeable = frozenset(self.order)
        self.children: dict[str, tuple[tuple[str, str], ...]] = hanging_children(
            project, partition, catalog, placeable
        )
        self.parent_of: dict[str, tuple[str, str]] = {
            child: (parent, port_id)
            for parent, items in self.children.items()
            for child, port_id in items
        }
        # **Il suo** attacco su quello stacco, non il primo del manifesto: un
        # ponte fra due reti ne ha due e pende da quello in cui sbocca.
        self.hang_port: dict[str, str] = hanging_ports(
            project, partition, catalog, placeable
        )
        self.chains = sorted(
            (
                chain
                for chain in run_chains(project, partition, catalog, placeable)
                if all(item in self.best for item in chain)
            ),
            key=lambda chain: min(self.scan.index(item) for item in chain),
        )
        self.room: dict[tuple[str, ...], float] = {
            trunk.connection_ids: inline_room_mm(project, catalog, trunk.inline_component_ids)
            for trunk in self.trunks
        }
        # Le tratte vuote fra due raccordi di cui almeno uno regge un appeso
        # (I-046): il raccordo della sicurezza sta stretto alla confluenza, il
        # raccordo del manometro al raccordo del riempimento. Lungo una retta
        # la lunghezza totale non cambia spostando un raccordo, e nessun
        # costo lo terrebbe vicino a cio' a cui appartiene: e' un vincolo.
        fittings = {
            item.component_id
            for item in placed
            if catalog.get(definitions[item.component_id]).is_a_fitting
        }
        self.service_links: list[Trunk] = [
            trunk
            for trunk in self.trunks
            if not trunk.inline_component_ids
            and {trunk.start.component_id, trunk.end.component_id} <= fittings
            and any(
                self.children.get(item)
                for item in (trunk.start.component_id, trunk.end.component_id)
            )
        ]
        self.service_followers: dict[str, tuple[str, ...]] = {}
        for trunk in self.service_links:
            for mine, other in (
                (trunk.start.component_id, trunk.end.component_id),
                (trunk.end.component_id, trunk.start.component_id),
            ):
                self.service_followers[mine] = (*self.service_followers.get(mine, ()), other)
        # Lo stacco di ogni appeso dal proprio attacco, misurato sulla posa
        # iniziale lungo l'asse dello stacco: si conserva quando il pezzo si
        # muove o si gira, perche' l'ha deciso il posizionamento.
        self.hang_gap: dict[str, float] = {}
        # Il minimo di ogni stacco, letto dalla tratta come lo legge la posa
        # (I-046): sotto non si scende, sopra si paga in lunghezza.
        self.hang_min: dict[str, float] = {}
        # La tratta di ciascuno stacco, tenuta da parte: la rilegge il vincolo
        # di D-145, che deve sapere **quanto rettilineo** quella tratta chiede.
        self.hang_trunk: dict[str, Trunk] = {}
        for child, (parent, _port_id) in self.parent_of.items():
            trunk = next(
                item
                for item in self.trunks
                if {item.start.component_id, item.end.component_id} == {parent, child}
            )
            self.hang_trunk[child] = trunk
            face = self.upright[child].port(
                self.hang_port.get(child, self.upright[child].ports[0].id)
            ).face
            self.hang_min[child] = stub_minimum_mm(
                project, catalog, trunk, face in _HORIZONTAL_FACES, self.step
            )
        self._refresh_hang_gaps()

        self.owning_run = {
            component_id: index
            for index, trunk in enumerate(self.trunks)
            for component_id in trunk.inline_component_ids
        }
        self.trials = 0
        self.axis_trials = 0
        self.journal: list[Attempt] = []
        # La fase: nella prima chi sta a terra tiene la quota e i raccordi
        # provano le sole rotazioni; nella seconda le macchine possono
        # cambiare quota e i raccordi anche permutare gli attacchi.
        self.refining = False
        # La fase. Il ciclo comincia dal corredo perche' il tronco l'ha gia'
        # costruito `spine.lay_the_spine`: qui non si cerca piu' una forma, la
        # si eredita e non la si perde (DRAW-008 §A.4).
        self.phase = Phase.CORREDO
        self.spine_layout = spine_layout
        # Le tratte del tronco, e quali di esse sono arrivate **dritte**. La
        # rettilineita' di queste e' un vincolo, non una voce di costo: sta
        # qui, fra «i vincoli che nessun guadagno compra», e non in
        # `SheetCost`. Una tratta che il tronco non e' riuscito a raddrizzare
        # non diventa per questo libera di peggiorare: il vincolo e' che il
        # numero di quelle dritte non cali mai.
        # Senza una fase del tronco alle spalle non c'e' nessuna forma da
        # conservare, e il ciclo torna quello di prima: e' cosi' che le prove
        # che costruiscono un `Improver` da sole continuano a misurare cio' che
        # misuravano, ed e' anche il ripiego di `compose_sheet` quando la
        # catena a fasi non consegna una tavola instradabile.
        self.autostrade: list[Trunk] = (
            [
                trunk
                for trunk in self.trunks
                if self.hierarchy[trunk.connection_ids] is Level.AUTOSTRADA
            ]
            if spine_layout is not None
            else []
        )
        # **L'autostrada intera** (DRAW-012 §C). Le tratte qui sopra sono i suoi
        # frammenti, e su un frammento la rettilineita' e' vera per costruzione:
        # cinque millimetri sono dritti sempre. L'oggetto che si conserva e' la
        # catena, e l'invariante si verifica su di lei.
        self.conceded = frozenset(conceded)
        self.highways: tuple[Highway, ...] = (
            tuple(
                item
                for item in highways(project, catalog, self.trunks)
                if not (set(item.keys) & self.conceded)
            )
            if spine_layout is not None
            else ()
        )
        self._memo: dict[Signature, Measured | None] = {}

    # -- letture del manifesto -------------------------------------------------

    def manifest_at(self, component_id: str, rotation_deg: int) -> SymbolManifest:
        """Il manifesto del componente girato di tanto, dal manifesto diritto."""
        found = self._turned.get((component_id, rotation_deg))
        if found is None:
            found = self.upright[component_id].rotated(rotation_deg)
            self._turned[component_id, rotation_deg] = found
        return found

    def standing_at(self, component_id: str, rotation_deg: int) -> Standing:
        functions, is_inline = self.features[component_id]
        return standing_of(
            self.manifest_at(component_id, rotation_deg).height_mm, functions, is_inline
        )

    def port_at(self, item: PlacedSymbol, port_id: str) -> tuple[Point, PortFace]:
        """Dove sta una porta di un simbolo posato, e dove guarda: sull'attacco
        fisico che la posa le ha assegnato."""
        port = self.manifest_at(item.component_id, item.rotation_deg).port(
            item.physical_port(port_id)
        )
        return (
            Point(x_mm=item.origin.x_mm + port.x_mm, y_mm=item.origin.y_mm + port.y_mm),
            port.face,
        )

    def _port_of(
        self, component_id: str, rotation_deg: int, port_map: PortMap, port_id: str
    ) -> SymbolPort:
        """Una porta del modello su un pezzo girato e permutato cosi'."""
        return self.manifest_at(component_id, rotation_deg).port(port_map.get(port_id, port_id))

    def _placed(
        self,
        component_id: str,
        origin: Point,
        rotation_deg: int,
        port_map: PortMap | None = None,
    ) -> PlacedSymbol:
        shape = self.manifest_at(component_id, rotation_deg)
        update: dict[str, object] = {
            "origin": origin,
            "rotation_deg": rotation_deg,
            "width_mm": shape.width_mm,
            "height_mm": shape.height_mm,
        }
        if port_map is not None:
            update["port_map"] = dict(port_map)
        return self.best[component_id].model_copy(update=update)

    def leader_of(self, component_id: str) -> str:
        """Il pezzo che si muove: un appeso viaggia col pezzo che lo regge.

        La catena si risale **fino in cima**: una figura puo' essere profonda —
        dal raccordo pende il gruppo di riempimento e dal gruppo pende il
        proprio ingresso dell'acqua fredda — e chi si muove e' la radice, non il
        primo che si incontra salendo.
        """
        seen: set[str] = set()
        walk = component_id
        while walk in self.parent_of and walk not in seen:
            seen.add(walk)
            walk = self.parent_of[walk][0]
        return walk

    def below(self, leader: str) -> tuple[str, ...]:
        """Tutta la figura sotto un pezzo, dall'alto in basso."""
        out: list[str] = []
        frontier = [child for child, _ in self.children.get(leader, ())]
        while frontier:
            item = frontier.pop(0)
            if item in out:
                continue
            out.append(item)
            frontier.extend(child for child, _ in self.children.get(item, ()))
        return tuple(out)

    def unit_of(self, component_id: str) -> tuple[str, ...]:
        leader = self.leader_of(component_id)
        return (leader, *self.below(leader))

    # -- la misura ---------------------------------------------------------------

    def measure(self, layout: Iterable[PlacedSymbol] | Move) -> Measured | None:
        """Un instradamento di prova completo, contato contro il tetto.

        Completo vuol dire con gli accessori posati: `settle_sheet` e' la stessa
        funzione con cui la tavola si disegna. `None` e' una posa che non si
        lascia instradare: non e' una candidata.
        """
        table = layout if isinstance(layout, dict) else {
            item.component_id: item for item in layout
        }
        signature = _signature({item: table[item] for item in self.order})
        if signature in self._memo:
            return self._memo[signature]
        self.trials += 1
        symbols = [table[item] for item in self.order]
        try:
            settled = settle_sheet(
                self.project, self.trunks, symbols, self.catalog, self.grid, tolerant=True
            )
        except LayoutError:
            self._memo[signature] = None
            return None
        found = Measured(cost=self.cost_of(table, settled), settled=settled)
        self._memo[signature] = found
        return found

    def cost_of(self, table: Move, settled: SettledSheet) -> SheetCost:
        """Il confronto unico, letto sulla tavola instradata."""
        violations = len(settled.unfit) + self._accessories_out_of_place(settled)
        turnback_runs = 0
        turnback_mm = 0.0
        long_runs = 0
        bends = 0
        crossings = 0
        length_mm = 0.0
        for trunk, route in zip(self.trunks, settled.routes, strict=True):
            # Il peso della gerarchia (DRAW-007 §B): una piega sul tronco fra le
            # macchine principali non vale una piega su uno stacco cieco, e con
            # il conto piatto il ciclo barattava la struttura della tavola per
            # un totale piu' basso — facendo, correttamente, la cosa sbagliata.
            weight = weight_of(self.hierarchy[trunk.connection_ids])
            arrival = table[trunk.end.component_id]
            goal, _ = self.port_at(arrival, trunk.end.port_id)
            back = max(
                overshoot_beyond_goal_mm(route, goal),
                max(
                    (overshoot_mm(segment, self.step) for segment in route.segments),
                    default=0.0,
                ),
            )
            if back > _TOLERANCE_MM:
                turnback_runs += 1
                turnback_mm += back
            turns = sum(max(len(segment) - 2, 0) for segment in route.segments)
            bends += turns * weight
            # Il tetto delle pieghe per tratta resta un **conto**, non un peso:
            # tre pieghe sono tre pieghe ovunque, e una tratta che le supera e'
            # fuori regola anche se sta su uno stacco.
            if turns > BENDS_PER_RUN_MAX:
                long_runs += 1
            crossings += len(route.crossings) * weight
            length_mm += weight * sum(
                abs(after.x_mm - before.x_mm) + abs(after.y_mm - before.y_mm)
                for segment in route.segments
                for before, after in zip(segment, segment[1:], strict=False)
            )
        box = ink_box(settled.symbols, settled.routes)
        return SheetCost(
            violations=violations,
            turnback_runs=turnback_runs,
            turnback_mm=turnback_mm,
            long_runs=long_runs,
            bends=bends,
            crossings=crossings,
            margin_gap=SHEET_MARGIN_MM
            - margin_allowed_mm(
                settled.symbols, settled.routes, self.sheet_rect, self.step
            ),
            fill=fill_ratio(settled.symbols, settled.routes, self.sheet_rect),
            coverage=ink_coverage(settled.symbols, settled.routes, box),
            imbalance=ink_imbalance(
                settled.symbols,
                settled.routes,
                _centred_on(box, self.sheet_rect),
                self.frame.standard.line_medium_mm,
            ),
            length_mm=length_mm,
        )

    def _accessories_out_of_place(self, settled: SettledSheet) -> int:
        """Accessori addosso a una tratta altrui o a un simbolo (B5, D-027).

        E' la misura del preflight, letta prima che la tavola esista: un
        accessorio e' un simbolo, e una tratta che non e' la sua gli deve stare
        alla distanza di rispetto. Quale sia la sua lo dice la tratta che lo
        porta, non la geometria.
        """
        count = 0
        for accessory in settled.accessories:
            box = box_of(accessory)
            mine = self.owning_run.get(accessory.component_id)
            others = [
                route for index, route in enumerate(settled.routes) if index != mine
            ]
            if run_intrudes_on(box, others, self.clearance):
                count += 1
                continue
            for other in settled.symbols:
                if other is accessory:
                    continue
                if (
                    box[0] < other.right_mm - _TOLERANCE_MM
                    and other.origin.x_mm < box[2] - _TOLERANCE_MM
                    and box[1] < other.bottom_mm - _TOLERANCE_MM
                    and other.origin.y_mm < box[3] - _TOLERANCE_MM
                ):
                    count += 1
                    break
        return count

    # -- le figure -------------------------------------------------------------

    def _neighbours(self, component_id: str) -> frozenset[str]:
        """A cosa un pezzo e' attaccato, senza contare cio' che pende."""
        return frozenset(
            other
            for trunk in self.trunks
            for mine, other in (
                (trunk.start.component_id, trunk.end.component_id),
                (trunk.end.component_id, trunk.start.component_id),
            )
            if mine == component_id and other not in self.parent_of and other in self.best
        )

    def column_of(self, component_id: str) -> tuple[str, ...]:
        """La colonna o la pila a cui un pezzo appartiene, lui compreso.

        Due letture, che sono quelle del posizionamento: chi sta a terra e
        divide la colonna con un altro a terra (D-073), e chi ha lo stesso bordo
        sinistro di un pari — stessi vicini — sopra o sotto di lui (A3, D-118).
        La colonna e' una figura: si trasla insieme, non si sfila.
        """
        leader = self.leader_of(component_id)
        leaders = [item for item in self.scan if item not in self.parent_of]

        def stacked(first: str, second: str) -> bool:
            one, two = self.best[first], self.best[second]
            if (
                self.standings[first] is Standing.GROUND
                and self.standings[second] is Standing.GROUND
                and one.origin.x_mm < two.right_mm - _TOLERANCE_MM
                and two.origin.x_mm < one.right_mm - _TOLERANCE_MM
            ):
                return True
            if abs(one.origin.x_mm - two.origin.x_mm) > _TOLERANCE_MM:
                return False
            apart = (
                one.bottom_mm <= two.origin.y_mm + _TOLERANCE_MM
                or two.bottom_mm <= one.origin.y_mm + _TOLERANCE_MM
            )
            return apart and self._neighbours(first) == self._neighbours(second)

        column = {leader}
        frontier = [leader]
        while frontier:
            current = frontier.pop()
            for other in leaders:
                if other not in column and stacked(current, other):
                    column.add(other)
                    frontier.append(other)
        return tuple(item for item in leaders if item in column)

    # -- come si costruisce una candidata --------------------------------------

    def place_unit(
        self, leader: str, origin: Point, rotation_deg: int, port_map: PortMap | None = None
    ) -> Move:
        """Il pezzo posato la', con cio' che gli pende riappeso al proprio attacco."""
        parent = self._placed(leader, origin, rotation_deg, port_map)
        move: Move = {leader: parent}
        self._rehang_below(leader, parent, move)
        return move

    def _rehang_below(self, leader: str, parent: PlacedSymbol, move: Move) -> None:
        """Riappende la figura intera, un livello per volta.

        Chi pende da un appeso va riappeso al **suo** pezzo dopo che questo si
        e' mosso: fermarsi al primo livello lasciava indietro il nipote, e la
        figura si spezzava senza che nessun vincolo se ne accorgesse.
        """
        for child, port_id in self.children.get(leader, ()):
            hung = self._rehung(child, parent, port_id)
            move[child] = hung
            self._rehang_below(child, hung, move)

    def _rehung(
        self, child: str, parent: PlacedSymbol, port_id: str, gap_mm: float | None = None
    ) -> PlacedSymbol:
        """L'appeso rimesso dalla parte in cui lo stacco guarda, allo stacco di prima.

        Il figlio si gira, se il manifesto lo ammette, perche' il suo unico
        attacco guardi lo stacco; altrimenti tiene il verso che aveva. Con
        `gap_mm` lo stacco cambia lunghezza: e' la mossa che libera una riga a
        chi deve passarci.
        """
        stub, face = self.port_at(parent, port_id)
        direction = _DIRECTION[face]
        gap = self.hang_gap[child] if gap_mm is None else gap_mm
        current = self.best[child]
        own_port_id = self.hang_port.get(child, self.upright[child].ports[0].id)
        wanted = face.opposite
        rotations = sorted(
            self.upright[child].allowed_rotations_deg,
            key=lambda item: (item != current.rotation_deg, item),
        )
        chosen = current.rotation_deg
        for degrees in rotations:
            if self.manifest_at(child, degrees).port(own_port_id).face is wanted:
                chosen = degrees
                break
        port = self.manifest_at(child, chosen).port(own_port_id)
        origin = Point(
            x_mm=stub.x_mm + direction[0] * gap - port.x_mm,
            y_mm=stub.y_mm + direction[1] * gap - port.y_mm,
        )
        return self._placed(child, origin, chosen)

    def _translated(self, leaders: Iterable[str], dx_mm: float, dy_mm: float) -> Move:
        move: Move = {}
        for leader in leaders:
            here = self.best[leader]
            move.update(
                self.place_unit(
                    leader,
                    Point(x_mm=here.origin.x_mm + dx_mm, y_mm=here.origin.y_mm + dy_mm),
                    here.rotation_deg,
                )
            )
        return move

    def _link_mm(self, table: Move, trunk: Trunk) -> float:
        """Da porta a porta, lungo la griglia, sulla tavola data."""
        start, _ = self.port_at(table[trunk.start.component_id], trunk.start.port_id)
        goal, _ = self.port_at(table[trunk.end.component_id], trunk.end.port_id)
        return abs(goal.x_mm - start.x_mm) + abs(goal.y_mm - start.y_mm)

    def _with_followers(self, move: Move) -> Move:
        """I raccordi di servizio seguono il raccordo a cui sono attaccati.

        Una candidata che sposta o gira un raccordo rimette in fila, dalla
        sua porta, i raccordi che gli stanno stretti su una tratta vuota
        (I-046) — quello della sicurezza dopo la confluenza, quelli del
        manometro, del riempimento e del vaso fra loro — con cio' che a loro
        pende, alla distanza minima e con l'ingresso rivolto all'indietro,
        come la catena. Cosi' la mossa resta una posa valida invece di
        allungare la tratta vuota, e il ciclo puo' spostare la confluenza
        senza lasciare indietro la sicurezza. Chi la mossa gia' colloca da
        se' non si tocca.
        """
        out = dict(move)
        frontier = [item for item in move if item in self.service_followers]
        while frontier:
            item = frontier.pop()
            for trunk in self.service_links:
                ends = (trunk.start, trunk.end)
                if item not in {ref.component_id for ref in ends}:
                    continue
                mine, other = ends if ends[0].component_id == item else (ends[1], ends[0])
                if other.component_id in out:
                    continue
                # La fila che continua oltre il seguace, lungo le tratte vuote.
                members = [other.component_id]
                while True:
                    beyond = [
                        follower
                        for follower in self.service_followers.get(members[-1], ())
                        if follower not in members and follower != item and follower not in out
                    ]
                    if not beyond:
                        break
                    members.append(beyond[0])
                saved = self.best
                self.best = {**saved, **out}
                try:
                    laid = self._lay(
                        tuple(members), item, mine.port_id, trunk, other.port_id, 0
                    )
                finally:
                    self.best = saved
                if laid is None:
                    continue
                for member in members:
                    if member in laid:
                        frontier.append(member)
                out.update(laid)
        return out

    def _need_mm(self, trunk: Trunk) -> float:
        """La distanza minima fra due porte affacciate su questa tratta.

        Il rettilineo che gli accessori pretendono, e mai meno dello stacco
        minimo fra due simboli (D-062).
        """
        return _snap_up(max(ROW_GAP_MM, self.room[trunk.connection_ids]), self.step)

    def _looks_at_its_peers(self, component_id: str, degrees: int, port_map: PortMap) -> bool:
        """Vero se, girato e permutato cosi', nessuna porta collegata volta le
        spalle al pezzo con cui parla.

        Un attacco che guarda dalla parte opposta al proprio pari obbliga la
        tratta a uscire e tornare indietro: quella posa non e' una candidata,
        e' rumore. Si legge dalla posizione attuale del pezzo e dei pari.
        """
        me = self.best[component_id]
        for _, my_port, peer_id, peer_port in self._trunks_of(component_id):
            port = self._port_of(component_id, degrees, port_map, my_port)
            outward = _DIRECTION[port.face]
            theirs, _ = self.port_at(self.best[peer_id], peer_port)
            dx = theirs.x_mm - (me.origin.x_mm + port.x_mm)
            dy = theirs.y_mm - (me.origin.y_mm + port.y_mm)
            if dx * outward[0] + dy * outward[1] < -_TOLERANCE_MM:
                return False
        return True

    def _orientations(
        self, component_id: str, *, toward_peers: bool = True
    ) -> list[tuple[int, PortMap]]:
        """Rotazioni ammesse per permutazioni ammesse, senza doppioni di
        giacitura: due combinazioni che mettono ogni porta del modello sulla
        stessa faccia sono la stessa posa. Prima quella attuale, poi in ordine
        di rotazione e di permutazione. Con `toward_peers` restano solo le
        pose in cui nessuna porta volta le spalle al proprio pari."""
        current = self.best[component_id]
        found: list[tuple[int, PortMap]] = []
        seen: set[tuple[tuple[str, PortFace], ...]] = set()
        ordered = sorted(
            self.upright[component_id].allowed_rotations_deg,
            key=lambda item: (item != current.rotation_deg, item),
        )
        maps = sorted(
            self.permutations[component_id] if self.refining else [current.port_map],
            key=lambda item: (item != current.port_map, sorted(item.items())),
        )
        for degrees in ordered:
            shape = self.manifest_at(component_id, degrees)
            for port_map in maps:
                faces = tuple(
                    (port.id, shape.port(port_map.get(port.id, port.id)).face)
                    for port in self.upright[component_id].ports
                )
                if faces in seen:
                    continue
                seen.add(faces)
                if (
                    toward_peers
                    and self.refining
                    and not self._looks_at_its_peers(component_id, degrees, port_map)
                ):
                    continue
                found.append((degrees, port_map))
        return found

    def _facing(
        self,
        component_id: str,
        port_id: str,
        wanted: PortFace,
        *,
        straight: tuple[str, PortFace] | None = None,
    ) -> list[tuple[int, PortMap]]:
        """Le pose del pezzo — rotazione e permutazione — che portano la porta
        a guardare da quella parte, prima quella attuale.

        Con `straight` si chiede anche che un'altra porta guardi in una data
        direzione: e' il raccordo che prosegue diritto lungo una dorsale.
        Quelle che lo fanno vengono prima; le altre restano, perche' il
        raccordo puo' anche girare.
        """
        found = [
            (degrees, port_map)
            for degrees, port_map in self._orientations(component_id)
            if self._port_of(component_id, degrees, port_map, port_id).face is wanted
        ]
        if straight is None or not self.refining:
            return found
        exit_port, exit_face = straight
        return sorted(
            found,
            key=lambda item: self._port_of(component_id, item[0], item[1], exit_port).face
            is not exit_face,
        )

    def _trunks_of(self, leader: str) -> list[tuple[Trunk, str, str, str]]:
        """Le tratte fra questo pezzo e un pezzo di un'altra figura:
        `(tratta, porta mia, pezzo pari, porta del pari)`."""
        unit = set(self.unit_of(leader))
        found: list[tuple[Trunk, str, str, str]] = []
        for trunk in self.trunks:
            for mine, other in ((trunk.start, trunk.end), (trunk.end, trunk.start)):
                if mine.component_id != leader:
                    continue
                if other.component_id in unit or other.component_id not in self.best:
                    continue
                found.append((trunk, mine.port_id, other.component_id, other.port_id))
        return found

    def _passes_through(self, component_id: str, port_id: str) -> list[tuple[str, str]]:
        """Le porte che comunicano con questa **dentro** il pezzo, e lo stato.

        Tre casi, e nessuno e' un elenco di nomi. Un **multivia** lo dice il
        catalogo, stato per stato: l'ingresso di una deviatrice comunica con un
        ramo oppure con l'altro, e i due rami non comunicano mai fra loro. Un
        **raccordo** o un accessorio **in linea** si attraversa fra tutti i
        propri attacchi del percorso. Una macchina no: li' la corsa finisce, ed
        e' quello il pezzo con cui ci si allinea.
        """
        definition = self.definitions[component_id]
        if definition.hydraulic_states:
            return [
                (other, state.id)
                for state in definition.hydraulic_states
                for other in sorted(state.linked(port_id))
            ]
        _, is_inline = self.features[component_id]
        # Un accessorio che pende da uno stacco con **due** attacchi non e' un
        # capolinea: la corsa ci entra e ne esce, ed e' il ponte fra due reti —
        # il gruppo di riempimento, che porta l'acqua dell'acquedotto nel
        # ritorno tecnico. Le sue due prese vanno allineate fra loro, o la
        # derivazione fredda gira attorno al foglio per raggiungerlo
        # (DRAW-006-R1, blocco D). Chi ha un attacco solo non prosegue, e una
        # macchina non pende da nessuno stacco.
        on_the_run = [port for port in definition.ports if not port.off_the_run]
        passes = is_inline or definition.is_a_fitting or (
            definition.attaches_on_a_branch and len(on_the_run) == 2
        )
        if not passes:
            return []
        return [(port.id, "") for port in on_the_run if port.id != port_id]

    def linked_peers(self, leader: str) -> list[PortPair]:
        """Le coppie di porte allineabili fra questo pezzo e un pezzo d'altra figura.

        Prima erano i soli capi diretti di una tratta, e bastava una deviatrice
        fra due macchine perche' l'asse ovvio fra le loro porte non venisse
        nemmeno provato (DRAW-006-R1, blocco B). Adesso si cammina: attraverso
        i raccordi, attraverso le catene di accessori in linea e — **uno stato
        ammesso per volta** — attraverso i multivia. Fermarsi e' un fatto del
        pezzo, non della distanza: si arriva a cio' che la corsa non attraversa.

        L'ordine e' quello delle tratte, che e' gia' strutturale; le coppie non
        si ripetono. E' una **lettura**, non una regola: quali candidate ne
        nascano e quale vinca lo decide il costo della tavola.
        """
        unit = set(self.unit_of(leader))
        found: list[PortPair] = []
        seen: set[tuple[str, str, str]] = set()
        # Si parte da ogni tratta che tocca il pezzo e si prosegue finche' si
        # attraversa. Il tetto e' il numero dei pezzi: una camminata che non
        # ripassa da dove e' gia' stata non puo' essere piu' lunga.
        queue: list[tuple[str, str, str, tuple[str, ...]]] = [
            (mine.port_id, other.component_id, other.port_id, ())
            for trunk in self.trunks
            for mine, other in ((trunk.start, trunk.end), (trunk.end, trunk.start))
            if mine.component_id == leader
        ]
        while queue:
            my_port, peer_id, peer_port, through = queue.pop(0)
            if peer_id not in self.best or len(through) > len(self.order):
                continue
            key = (my_port, peer_id, peer_port)
            if peer_id not in unit and key not in seen:
                seen.add(key)
                found.append(
                    PortPair(
                        my_port=my_port,
                        peer_id=peer_id,
                        peer_port=peer_port,
                        through=through,
                    )
                )
            for onward, _state in self._passes_through(peer_id, peer_port):
                for trunk in self.trunks:
                    for here, there in (
                        (trunk.start, trunk.end),
                        (trunk.end, trunk.start),
                    ):
                        if (here.component_id, here.port_id) != (peer_id, onward):
                            continue
                        if there.component_id in {*through, peer_id, leader}:
                            continue
                        queue.append(
                            (
                                my_port,
                                there.component_id,
                                there.port_id,
                                (*through, peer_id),
                            )
                        )
        return found

    def _port_moves(self, leader: str) -> list[Move]:
        """Le pose ricavate dalle porte dei vicini collegati.

        Per ogni tratta verso un pari gia' posato: la quota che allinea le due
        porte; la posa affacciata alla distanza minima che lascia il rettilineo
        agli accessori, dalla parte in cui la porta del pari guarda, con la
        rotazione che rivolge la propria porta verso di lui; e la stessa con
        qualche passo di gioco.
        """
        out: list[Move] = []
        me = self.best[leader]
        for trunk, my_port, peer_id, peer_port in self._trunks_of(leader):
            peer = self.best[peer_id]
            anchor, face = self.port_at(peer, peer_port)
            direction = _DIRECTION[face]
            need = self._need_mm(trunk)
            poses = self._facing(leader, my_port, face.opposite)
            if (me.rotation_deg, me.port_map) not in poses:
                poses = [(me.rotation_deg, me.port_map), *poses]
            # Nella prima fase chi sta a terra non cambia quota; nella seconda
            # si' (DRAW-004): la quota iniziale e' un suggerimento di posa, e
            # il modello non dichiara un vincolo fisico che la imponga.
            grounded = self.standings[leader] is Standing.GROUND and not self.refining
            for degrees, port_map in poses:
                port = self._port_of(leader, degrees, port_map, my_port)
                # (a) allineamento: la porta sulla riga (o sulla colonna) della
                # porta del pari, senza muoversi lungo l'asse del collegamento.
                if face in _HORIZONTAL_FACES:
                    if grounded:
                        continue
                    aligned = Point(x_mm=me.origin.x_mm, y_mm=anchor.y_mm - port.y_mm)
                else:
                    aligned = Point(x_mm=anchor.x_mm - port.x_mm, y_mm=me.origin.y_mm)
                out.append(self.place_unit(leader, aligned, degrees, port_map))
            for degrees, port_map in poses:
                port = self._port_of(leader, degrees, port_map, my_port)
                # (b) affacciato alla distanza minima, e con un po' di gioco.
                if port.face is not face.opposite:
                    continue
                for slack in SLACK_STEPS:
                    reach = need + slack * self.step
                    origin = Point(
                        x_mm=anchor.x_mm + direction[0] * reach - port.x_mm,
                        y_mm=me.origin.y_mm
                        if grounded
                        else anchor.y_mm + direction[1] * reach - port.y_mm,
                    )
                    out.append(self.place_unit(leader, origin, degrees, port_map))
        return out

    def _chain_moves(self, leader: str) -> list[Move]:
        """La catena di raccordi rimessa in fila dalla porta di un pezzo grosso.

        Dal capo attaccato all'ancora si cammina lungo la direzione in cui la
        porta dell'ancora guarda: ogni membro prende la rotazione che rivolge la
        propria porta d'ingresso all'indietro, si posa alla distanza minima che
        la tratta pretende, e se la sua porta d'uscita guarda altrove la fila
        gira con lei. E' la posa che un tecnico disegna a mano, e nessuna
        traslazione di un pezzo solo la raggiunge.
        """
        out: list[Move] = []
        for chain in self.chains:
            if leader not in chain:
                continue
            for members in (chain, tuple(reversed(chain))):
                head = members[0]
                for trunk, my_port, anchor_id, anchor_port in self._trunks_of(head):
                    if anchor_id in chain:
                        continue
                    for slack in SLACK_STEPS:
                        laid = self._lay(members, anchor_id, anchor_port, trunk, my_port, slack)
                        if laid is not None:
                            out.append(laid)
        return out

    def _spine_moves(self, leader: str) -> list[Move]:
        """Dorsale prima, stacchi dopo (DRAW-004).

        La sequenza principale fra due pezzi grossi e' la catena di raccordi
        che li unisce: la si rimette in fila dalla porta di un capo, con ogni
        raccordo che prosegue diritto, e **anche il pezzo grosso all'altro
        capo** si porta sull'asse d'uscita della catena — o vi si affaccia
        alla distanza minima — con la propria colonna. Cosi' la dorsale resta
        rettilinea finche' non serve davvero girare, i raccordi stanno
        sull'asse e i rami partono da li'. Si genera per il pezzo che e' in
        catena e per i due capi.
        """
        out: list[Move] = []
        for chain in self.chains:
            ends = set(chain)
            for members in (chain, tuple(reversed(chain))):
                head, tail = members[0], members[-1]
                ends.update(other for _, _, other, _ in self._trunks_of(head))
                ends.update(other for _, _, other, _ in self._trunks_of(tail))
            if leader not in ends:
                continue
            for members in (chain, tuple(reversed(chain))):
                head, tail = members[0], members[-1]
                for trunk, my_port, anchor_id, anchor_port in self._trunks_of(head):
                    if anchor_id in chain:
                        continue
                    laid = self._lay(members, anchor_id, anchor_port, trunk, my_port, 0)
                    if laid is None:
                        continue
                    for far_trunk, exit_port, far_id, far_port in self._trunks_of(tail):
                        if far_id in chain or far_id == anchor_id:
                            continue
                        out.extend(
                            self._far_end_on_the_axis(
                                laid, tail, exit_port, far_trunk, far_id, far_port
                            )
                        )
        return out

    def _far_end_on_the_axis(
        self,
        laid: Move,
        tail: str,
        exit_port: str,
        trunk: Trunk,
        far_id: str,
        far_port: str,
    ) -> list[Move]:
        """Il pezzo grosso all'altro capo della catena, portato con la propria
        colonna sull'asse d'uscita della catena gia' rimessa in fila: alla
        distanza che ha, o affacciato alla distanza minima."""
        exit_point, face = self.port_at(laid[tail], exit_port)
        far = self.best[far_id]
        own, _ = self.port_at(far, far_port)
        column = [item for item in self.column_of(far_id) if item not in laid]
        if not column:
            return []
        direction = _DIRECTION[face]
        out: list[Move] = []
        horizontal = face in _HORIZONTAL_FACES
        aligned_dx = 0.0 if horizontal else exit_point.x_mm - own.x_mm
        aligned_dy = exit_point.y_mm - own.y_mm if horizontal else 0.0
        if (aligned_dx, aligned_dy) != (0.0, 0.0):
            out.append({**laid, **self._translated(column, aligned_dx, aligned_dy)})
        reach = self._need_mm(trunk)
        snug = Point(
            x_mm=exit_point.x_mm + direction[0] * reach, y_mm=exit_point.y_mm + direction[1] * reach
        )
        snug_dx, snug_dy = snug.x_mm - own.x_mm, snug.y_mm - own.y_mm
        if (snug_dx, snug_dy) not in ((0.0, 0.0), (aligned_dx, aligned_dy)):
            out.append({**laid, **self._translated(column, snug_dx, snug_dy)})
        return out

    def _lay(
        self,
        members: tuple[str, ...],
        anchor_id: str,
        anchor_port: str,
        first_trunk: Trunk,
        first_port: str,
        slack: int,
    ) -> Move | None:
        move: Move = {}
        anchor, face = self.port_at(self.best[anchor_id], anchor_port)
        trunk, entry_port = first_trunk, first_port
        for index, member in enumerate(members):
            direction = _DIRECTION[face]
            reach = self._need_mm(trunk) + slack * self.step
            link: tuple[Trunk, str, str] | None = None
            if index < len(members) - 1:
                following = members[index + 1]
                link = next(
                    (
                        (item, mine.port_id, other.port_id)
                        for item in self.trunks
                        for mine, other in ((item.start, item.end), (item.end, item.start))
                        if mine.component_id == member and other.component_id == following
                    ),
                    None,
                )
                if link is None:
                    return None
            # Il raccordo prende la posa che rivolge l'ingresso all'indietro e,
            # potendo, fa proseguire l'uscita diritta: e' la dorsale.
            poses = self._facing(
                member,
                entry_port,
                face.opposite,
                straight=None if link is None else (link[1], face),
            )
            here = self.best[member]
            degrees, port_map = poses[0] if poses else (here.rotation_deg, here.port_map)
            port = self._port_of(member, degrees, port_map, entry_port)
            origin = Point(
                x_mm=anchor.x_mm + direction[0] * reach - port.x_mm,
                y_mm=anchor.y_mm + direction[1] * reach - port.y_mm,
            )
            move.update(self.place_unit(member, origin, degrees, port_map))
            if link is None:
                break
            trunk, exit_port, entry_port = link
            anchor, face = self.port_at(move[member], exit_port)
        return move

    def _column_moves(self, leader: str) -> list[Move]:
        """La pila o la colonna traslata come gruppo, per gli stessi motivi per
        cui uno dei suoi membri si muoverebbe da solo."""
        column = self.column_of(leader)
        if len(column) < 2:
            return []
        grounded = not self.refining and any(
            self.standings[item] is Standing.GROUND for item in column
        )
        out: list[Move] = []
        seen: set[tuple[float, float]] = set()
        for member in column:
            here = self.best[member]
            for single in self._port_moves(member):
                target = single[member]
                if target.rotation_deg != here.rotation_deg or target.port_map != here.port_map:
                    continue
                dx = target.origin.x_mm - here.origin.x_mm
                dy = 0.0 if grounded else target.origin.y_mm - here.origin.y_mm
                if (dx, dy) == (0.0, 0.0) or (dx, dy) in seen:
                    continue
                seen.add((dx, dy))
                out.append(self._translated(column, dx, dy))
        return out

    def _shift_moves(self, leader: str) -> list[Move]:
        """Tutto cio' che sta oltre un pezzo si avvicina al pezzo che lo precede.

        E' l'avvicinamento di un gruppo funzionale al successivo: si sposta in
        blocco cio' che sta a destra del bordo sinistro del pezzo — lui compreso
        — di quanto serve a chiudere il varco con cio' che sta a sinistra, o di
        quanto una tratta che attraversa quel confine chiede per affacciare le
        proprie porte. E specularmente verso destra, per chi sta a sinistra.
        """
        out: list[Move] = []
        me = self.best[leader]
        leaders = [item for item in self.scan if item not in self.parent_of]
        for rightwards in (False, True):
            if rightwards:
                group = [
                    item for item in leaders if self.best[item].right_mm <= me.right_mm + _TOLERANCE_MM
                ]
                rest = [item for item in leaders if item not in group]
                if not rest:
                    continue
                gap = min(self.best[item].origin.x_mm for item in rest) - max(
                    self.best[item].right_mm for item in group
                )
                sign = 1.0
            else:
                group = [
                    item for item in leaders if self.best[item].origin.x_mm >= me.origin.x_mm - _TOLERANCE_MM
                ]
                rest = [item for item in leaders if item not in group]
                if not rest:
                    continue
                gap = min(self.best[item].origin.x_mm for item in group) - max(
                    self.best[item].right_mm for item in rest
                )
                sign = -1.0
            deltas: list[float] = []
            closing = gap - ROW_GAP_MM
            if closing > _TOLERANCE_MM:
                deltas.append(sign * (int(closing / self.step) * self.step))
            crossing = set(group)
            for trunk in self.trunks:
                one, two = trunk.start, trunk.end
                if (one.component_id in crossing) == (two.component_id in crossing):
                    continue
                if one.component_id not in self.best or two.component_id not in self.best:
                    continue
                first, _ = self.port_at(self.best[one.component_id], one.port_id)
                second, _ = self.port_at(self.best[two.component_id], two.port_id)
                inner = first if one.component_id in crossing else second
                outer = second if one.component_id in crossing else first
                span = abs(inner.x_mm - outer.x_mm) - self._need_mm(trunk)
                if span > _TOLERANCE_MM:
                    deltas.append(sign * (int(span / self.step) * self.step))
            seen: set[float] = set()
            for delta in deltas:
                if delta == 0.0 or delta in seen:
                    continue
                seen.add(delta)
                out.append(self._translated(group, delta, 0.0))
        return out

    def _collisions(self, move: Move) -> list[tuple[str, PlacedSymbol, PlacedSymbol]]:
        """Le figure ferme contro cui una candidata va a sbattere: `(capo, mio, suo)`."""
        after = dict(self.best)
        after.update(move)
        moved_units = {self.leader_of(item) for item in move}
        found: list[tuple[str, PlacedSymbol, PlacedSymbol]] = []
        for other_id in self.order:
            leader = self.leader_of(other_id)
            if leader in moved_units:
                continue
            other = after[other_id]
            for item in move:
                mine = after[item]
                if (
                    mine.origin.x_mm < other.right_mm + ROW_GAP_MM - _TOLERANCE_MM
                    and other.origin.x_mm - ROW_GAP_MM < mine.right_mm - _TOLERANCE_MM
                    and mine.origin.y_mm < other.bottom_mm + ROW_GAP_MM - _TOLERANCE_MM
                    and other.origin.y_mm - ROW_GAP_MM < mine.bottom_mm - _TOLERANCE_MM
                ):
                    found.append((leader, mine, other))
        return found

    def _with_room(self, move: Move, direction: tuple[float, float]) -> list[Move]:
        """La stessa candidata, con lo spazio che le manca aperto lungo il suo asse.

        Una posa ricavata dalle porte puo' finire addosso a chi sta gia' li':
        non e' una ragione per scartarla, e' una ragione per spostare anche gli
        altri, che costano zero (D-078). Tre varianti, tutte lungo l'asse della
        mossa: si **spinge** chi e' addosso nel verso della mossa, a cascata con
        chi gli sta oltre; lo si spinge nel verso **opposto**, quando e' il
        posto davanti a una porta a dover essere liberato da chi lo occupava;
        oppure si **arretra** la mossa con tutto cio' che le sta dietro, il
        pezzo grosso da cui e' partita compreso. Chi sta a terra si sposta solo
        in orizzontale: lungo un asse verticale la variante che lo toccherebbe
        non e' valida, e cade da sola.
        """
        collisions = self._collisions(move)
        if not collisions:
            return []
        horizontal = direction[0] != 0.0
        sign = direction[0] if horizontal else direction[1]
        out: list[Move] = []
        for push in (sign, -sign):
            pushed = self._pushed(move, horizontal, push)
            if pushed is not None:
                out.append(pushed)
        retreated = self._retreated(move, collisions, horizontal, sign)
        if retreated is not None:
            out.append(retreated)
        return out

    def _low(self, item: PlacedSymbol, horizontal: bool) -> float:
        return item.origin.x_mm if horizontal else item.origin.y_mm

    def _high(self, item: PlacedSymbol, horizontal: bool) -> float:
        return item.right_mm if horizontal else item.bottom_mm

    def _overlap(
        self, mine: PlacedSymbol, other: PlacedSymbol, horizontal: bool, sign: float
    ) -> float:
        """Di quanto l'altro va spostato nel verso dato per liberare lo stacco."""
        if sign > 0:
            return self._high(mine, horizontal) + ROW_GAP_MM - self._low(other, horizontal)
        return self._high(other, horizontal) + ROW_GAP_MM - self._low(mine, horizontal)

    def _shifted_units(self, items: Iterable[str], horizontal: bool, amount: float) -> Move:
        leaders = sorted({self.leader_of(item) for item in items}, key=self.scan.index)
        return self._translated(
            leaders, amount if horizontal else 0.0, 0.0 if horizontal else amount
        )

    def _pushed(self, move: Move, horizontal: bool, sign: float) -> Move | None:
        """Chi e' addosso alla mossa si sposta nel verso dato, e chi gli sta
        oltre lo segue di altrettanto, a cascata."""
        pushed = dict(move)
        for _ in range(len(self.order)):
            hits = self._collisions(pushed)
            if not hits:
                return pushed
            amount = _snap_up(
                max(self._overlap(mine, other, horizontal, sign) for _, mine, other in hits),
                self.step,
            )
            if amount <= 0.0:
                return None
            edge = (
                min(self._low(other, horizontal) for _, _, other in hits)
                if sign > 0
                else max(self._high(other, horizontal) for _, _, other in hits)
            )
            taken = {self.leader_of(key) for key in pushed}
            beyond = [
                item
                for item in self.order
                if self.leader_of(item) not in taken
                and (
                    self._low(self.best[item], horizontal) >= edge - _TOLERANCE_MM
                    if sign > 0
                    else self._high(self.best[item], horizontal) <= edge + _TOLERANCE_MM
                )
            ]
            for column_member in list(beyond):
                beyond.extend(
                    mate for mate in self.column_of(column_member) if mate not in beyond
                )
            pushed = {**self._shifted_units(beyond, horizontal, sign * amount), **pushed}
        return None

    def _retreated(
        self,
        move: Move,
        collisions: list[tuple[str, PlacedSymbol, PlacedSymbol]],
        horizontal: bool,
        sign: float,
    ) -> Move | None:
        """La mossa e tutto cio' che le sta alle spalle — chi non collide e sta
        dal lato da cui e' partita — indietreggiano di quanto serve; chi
        collideva resta dov'e'."""
        amount = _snap_up(
            max(self._overlap(mine, other, horizontal, sign) for _, mine, other in collisions),
            self.step,
        )
        colliding = {leader for leader, _, _ in collisions}
        moving = {self.leader_of(key) for key in move}
        front = (
            min(self._low(item, horizontal) for item in move.values())
            if sign > 0
            else max(self._high(item, horizontal) for item in move.values())
        )
        behind = [
            item
            for item in self.order
            if self.leader_of(item) not in colliding
            and self.leader_of(item) not in moving
            and (
                self._high(self.best[item], horizontal) <= front + _TOLERANCE_MM
                if sign > 0
                else self._low(self.best[item], horizontal) >= front - _TOLERANCE_MM
            )
        ]
        for column_member in list(behind):
            behind.extend(mate for mate in self.column_of(column_member) if mate not in behind)
        retreated: Move = {}
        for item, placed in move.items():
            retreated[item] = placed.model_copy(
                update={
                    "origin": Point(
                        x_mm=placed.origin.x_mm - (sign * amount if horizontal else 0.0),
                        y_mm=placed.origin.y_mm - (0.0 if horizontal else sign * amount),
                    )
                }
            )
        retreated.update(self._shifted_units(behind, horizontal, -sign * amount))
        if self._collisions(retreated):
            return None
        return retreated

    def _swap_moves(self, leader: str) -> list[Move]:
        """Due membri di una pila si scambiano di posto (prima fase).

        Con due macchine impilate, quale sta sopra decide da che parte i
        raccordi le ricevono: un raccordo a T ha una mano sola, e la macchina
        che gli entra dall'alto non puo' essere quella che sta sotto. E' una
        candidata della posa di DRAW-002; nella rifinitura una pila conserva
        il proprio ordine, e lo scambio non si genera.
        """
        column = self.column_of(leader)
        out: list[Move] = []
        me = self.best[leader]
        for mate in column:
            if mate == leader:
                continue
            other = self.best[mate]
            if abs(other.origin.x_mm - me.origin.x_mm) > _TOLERANCE_MM:
                continue
            # Ognuno prende l'origine dell'altro; chi e' piu' alto si allinea
            # in basso al posto che prende, come una macchina a terra.
            mine = Point(x_mm=other.origin.x_mm, y_mm=other.bottom_mm - me.height_mm)
            theirs = Point(x_mm=me.origin.x_mm, y_mm=me.bottom_mm - other.height_mm)
            move = self.place_unit(leader, mine, me.rotation_deg)
            move.update(self.place_unit(mate, theirs, other.rotation_deg))
            out.append(move)
            # Lo scambio da solo raramente paga: e' il raccordo che li serve a
            # doversi rimettere in fila dalla porta che ora gli sta davanti.
            # Le catene e le pose da porta dei vicini si ricavano **sulla pila
            # gia' scambiata**, e viaggiano nella stessa mossa.
            out.extend(self._composed_with(move, (leader, mate)))
        return out

    def _axis_moves(self, leader: str, only_spine: bool = False) -> list[Move]:
        """Gli assi fra le porte, coordinati (DRAW-004, DRAW-006-R1 blocco B).

        Per ogni coppia di porte che il fluido collega — anche attraverso un
        raccordo, una catena di accessori in linea o un multivia, uno stato per
        volta — ci sono tre modi di metterle sullo stesso asse: muovo la mia
        colonna sull'asse della sua porta, muovo **la sua** sull'asse della
        mia, oppure muovo **tutte e due** verso un asse comune a meta' strada,
        sul passo.

        Le coppie che chiedono **lo stesso spostamento** si servono con una
        mossa sola: e' l'allineamento simultaneo di mandata e ritorno fra due
        macchine, che una candidata per coppia non avrebbe mai prodotto.

        Nessuno dei tre e' una regola: sono candidati, e decide il costo della
        tavola.
        """
        out: list[Move] = []
        me = self.best[leader]
        mine = self.column_of(leader)
        # Per ogni pari e per ciascuno dei due assi, gli scostamenti che le sue
        # coppie chiedono. Uno scostamento condiviso da due coppie e' una mossa
        # sola che le allinea tutte e due.
        wanted: dict[tuple[str, bool], list[float]] = {}
        if only_spine and leader not in self.spine:
            return []
        for pair in self.linked_peers(leader):
            if pair.peer_id not in self.best:
                continue
            if only_spine and pair.peer_id not in self.spine:
                continue
            anchor, face = self.port_at(self.best[pair.peer_id], pair.peer_port)
            own, _ = self.port_at(me, pair.my_port)
            horizontal = face in _HORIZONTAL_FACES
            gap = (own.y_mm - anchor.y_mm) if horizontal else (own.x_mm - anchor.x_mm)
            if abs(gap) <= _TOLERANCE_MM:
                continue
            found = wanted.setdefault((pair.peer_id, horizontal), [])
            if not any(abs(gap - item) <= _TOLERANCE_MM for item in found):
                found.append(gap)
        for (peer_id, horizontal), gaps in wanted.items():
            # Due granularita', e si provano tutt'e due (DRAW-007 §C.2). La
            # colonna e' cio' che il ciclo sapeva muovere fino a DRAW-006-R1, e
            # trascina pezzi che con questa coppia di porte non c'entrano: paga
            # contorno estraneo, e per quel contorno il costo la respinge. La
            # **macchina col proprio corredo** e' la mossa che un disegnatore
            # fa davvero, e non paga niente che non sia suo. Nessuna delle due
            # e' una regola: decide il costo della tavola.
            grane = [
                (mine, [item for item in self.column_of(peer_id) if item not in mine]),
                (
                    list(self.unit_of(leader)),
                    [item for item in self.unit_of(peer_id) if item not in mine],
                ),
            ]
            for mia, loro in grane:
                if not loro:
                    continue
                for gap in gaps:
                    # La sua parte sul mio asse.
                    out.append(self._shifted_units(loro, not horizontal, gap))
                    # La mia sull'asse del pari.
                    out.append(self._shifted_units(mia, not horizontal, -gap))
                    # Tutte e due su un asse comune: io di mezza distanza, sul
                    # passo, e il pari di quanto resta.
                    half = round(-gap / 2 / self.step) * self.step
                    if half != 0.0 and half != -gap:
                        out.append(
                            {
                                **self._shifted_units(mia, not horizontal, half),
                                **self._shifted_units(loro, not horizontal, gap + half),
                            }
                        )
        return out

    def lies_straight(self, table: Move, trunk: Trunk) -> bool:
        """Vero se questa tratta, **con questa posa**, e' un rettilineo.

        Si legge sulle porte e non sulla spezzata: due porte che si guardano,
        sullo stesso asse e nel verso giusto, sono unite da una retta e
        l'instradatore non ha motivo di piegare. E' la forma che la fase del
        tronco ha costruito, scritta come predicato perche' `is_valid` possa
        negarne la perdita **senza instradare**: un vincolo si verifica prima
        di misurare, altrimenti e' un costo.
        """
        here = table.get(trunk.start.component_id) or self.best[trunk.start.component_id]
        there = table.get(trunk.end.component_id) or self.best[trunk.end.component_id]
        source, face = self.port_at(here, trunk.start.port_id)
        goal, other = self.port_at(there, trunk.end.port_id)
        if other is not face.opposite:
            return False
        direction = _DIRECTION[face]
        if face in _HORIZONTAL_FACES:
            if abs(source.y_mm - goal.y_mm) > _TOLERANCE_MM:
                return False
            return (goal.x_mm - source.x_mm) * direction[0] > _TOLERANCE_MM
        if abs(source.x_mm - goal.x_mm) > _TOLERANCE_MM:
            return False
        return (goal.y_mm - source.y_mm) * direction[1] > _TOLERANCE_MM

    def chain_in_line(self, table: Move, highway: Highway) -> bool:
        """Vero se l'**autostrada intera**, con questa posa, e' una retta sola.

        Legge la stessa geometria di `lies_straight` — le porte, non la spezzata
        — e vi aggiunge la sola condizione che mancava: fra una tratta e la
        successiva la retta non cambia ne' direzione ne' quota. Il conto sta in
        `highways.py`, che e' l'unico posto dove si sa che cos'e' una catena.
        """

        def at(component_id: str, port_id: str) -> tuple[Point, PortFace] | None:
            placed = table.get(component_id) or self.best.get(component_id)
            if placed is None:
                return None
            return self.port_at(placed, port_id)

        return lies_in_line(highway, at)

    def crooked_chains(self, table: Move) -> tuple[Highway, ...]:
        """Le autostrade intere che con questa posa non sono una retta.

        La legge il ripiego graduale di `compose_sheet`, che deve sapere **a
        quale** catena sta per concedere una piega (§F.3)."""
        return tuple(
            item for item in self.highways if not self.chain_in_line(table, item)
        )

    def block_of(self, leader: str) -> tuple[str, ...]:
        """Il **corpo rigido** di cui un pezzo del tronco fa parte (DRAW-009 §B).

        Il tronco non si piega e non si deforma, ma trasla: il blocco e'
        l'insieme dei pezzi che una tratta di autostrada **gia' rettilinea**
        tiene allineati, chiuso per transitivita'. Chi e' unito al blocco da una
        tratta che dritta non e' — la serpentina del bollitore, che nessuna posa
        raddrizza — non fa parte dello stesso corpo: traslarlo insieme non
        conserverebbe niente, e il blocco esiste proprio per conservare.

        L'insieme e' vuoto per chi non sta sul tronco, e vuoto quando non c'e'
        nessuna fase del tronco alle spalle: senza una forma da conservare non
        c'e' nessun corpo rigido.
        """
        if not self.autostrade:
            return ()
        joined: dict[str, set[str]] = {}
        for trunk in self.autostrade:
            if not self.lies_straight(self.best, trunk):
                continue
            one = self.leader_of(trunk.start.component_id)
            two = self.leader_of(trunk.end.component_id)
            if one == two:
                continue
            joined.setdefault(one, set()).add(two)
            joined.setdefault(two, set()).add(one)
        root = self.leader_of(leader)
        if root not in joined:
            return ()
        seen = {root}
        frontier = [root]
        while frontier:
            item = frontier.pop()
            for other in sorted(joined.get(item, ())):
                if other in seen:
                    continue
                seen.add(other)
                frontier.append(other)
        return tuple(item for item in self.scan if item in seen)

    def _block_moves(self, leader: str) -> list[Move]:
        """La **traslazione di blocco**: il tronco si sposta tutto intero.

        DRAW-008 aveva letto «un tronco fermo» come *fermo nella forma e nella
        quota*, e su quella lettura la tavola 2 non aveva nessuna mossa capace
        di alzare le macchine di spina insieme al loro corredo: `_shift_moves`
        sposta un gruppo per una relazione gia' esistente, `_column_moves` una
        colonna, `_stretch_moves` taglia il foglio a meta' e pretende che
        qualcuno resti fermo. Nessuna trasla un blocco allineato **insieme a
        tutto cio' che deve seguirlo**.

        Qui il blocco si sposta tutto intero della stessa quantita', con le
        figure che gli pendono (`place_unit` le riappende al proprio attacco) e
        il corredo in linea, che segue le proprie tratte. **Il blocco non si
        deforma**: la traslazione e' rigida per costruzione, quindi ogni
        distanza interna resta quella di prima. Il resto del foglio non si
        muove.

        Se un pezzo non puo' seguire — fuori dall'area, addosso a un altro — la
        mossa **non si fa**: la rifiuta `is_valid`, che guarda la candidata
        intera. Non si fa a meta'.

        Come ogni spostamento di macchina costa zero: si giudica sulla chiave di
        costo del foglio intero dopo il reinstradamento, mai sul solo tronco.
        """
        block = self.block_of(leader)
        if len(block) < 2:
            return []
        # Un blocco lo propone **un pezzo solo**, il primo in ordine di posa:
        # proporlo da ciascun membro moltiplicherebbe la stessa candidata per
        # il numero dei membri, e ogni candidata e' un instradamento di prova.
        if self.leader_of(leader) != block[0]:
            return []
        out: list[Move] = []
        for steps in BLOCK_STEPS:
            amount = steps * self.step
            for dx, dy in ((0.0, -amount), (0.0, amount), (-amount, 0.0), (amount, 0.0)):
                out.append(self._translated(block, dx, dy))
        return out

    def straight_spine(self, table: Move) -> frozenset[tuple[str, ...]]:
        """Le autostrade che, con questa posa, sono rettilinee."""
        return frozenset(
            trunk.connection_ids
            for trunk in self.autostrade
            if self.lies_straight(table, trunk)
        )

    def _span_mm(self, table: Move, trunk: Trunk) -> float:
        """La campata fra le due porte di una tratta, lungo il proprio asse."""
        here = table.get(trunk.start.component_id) or self.best[trunk.start.component_id]
        there = table.get(trunk.end.component_id) or self.best[trunk.end.component_id]
        source, face = self.port_at(here, trunk.start.port_id)
        goal, _ = self.port_at(there, trunk.end.port_id)
        if face in _HORIZONTAL_FACES:
            return abs(goal.x_mm - source.x_mm)
        return abs(goal.y_mm - source.y_mm)

    def _stretch_moves(self, leader: str) -> list[Move]:
        """Il tronco si allunga, invece di piegarsi (DRAW-008 §B.2).

        E' la mossa che al ciclo mancava: fino a DRAW-007 le candidate
        spostavano **pezzi**, e per far posto a una valvola che non entrava
        l'unica strada era deviare la tubazione. Qui si taglia il foglio a meta'
        della tratta e si allontana tutto cio' che sta oltre, lungo l'asse della
        tratta stessa. Due macchine di spina si allontanano e cio' che sta in
        mezzo le segue: la campata cresce, **nessuna quota cambia**, e percio'
        nessun allineamento si perde e nessuna autostrada si piega.

        Le tratte che attraversano il taglio nell'altro verso — le rette
        perpendicolari — si portano dietro il proprio capo, altrimenti sarebbero
        loro a spezzarsi. E una tratta che il taglio **accorcerebbe** annulla la
        candidata: allungare il tronco da una parte per stringerlo dall'altra
        non e' uno stretch, e' un'altra piega mascherata.
        """
        out: list[Move] = []
        seen: set[tuple[bool, float, float]] = set()
        for trunk, my_port, peer, peer_port in self._trunks_of(leader):
            if self.hierarchy[trunk.connection_ids] is not Level.AUTOSTRADA:
                continue
            # ⛔ **Non si pretende piu' che la tratta sia gia' dritta.** Fino a
            # `DRAW-011` l'allungo era offerto solo dove il tronco era gia' un
            # rettilineo, e la cosa si mordeva la coda: quando la posa e'
            # stretta il tronco **non e'** dritto — e' proprio quello il
            # problema — e l'unica mossa capace di fare spazio spariva
            # dall'elenco. Misurato sul banco di DRAW-012, l'impianto 4: il
            # ciclo esauriva **centonovantotto** candidate senza che una sola
            # fosse un allungo. E' il «nessuna consegna ha ancora usato davvero
            # lo stretch» del pacchetto (§E.2), letto nel codice.
            #
            # Il taglio resta quello che era: si allontana cio' che sta oltre
            # **lungo un asse solo**, quindi nessuna quota dell'altro asse
            # cambia e nessun allineamento si perde. Cio' che era dritto non si
            # storce lo dice `is_valid`, come per ogni altra mossa.
            source, face = self.port_at(self.best[leader], my_port)
            goal, _ = self.port_at(self.best[peer], peer_port)
            horizontal = face in _HORIZONTAL_FACES
            span = self._span_mm(self.best, trunk)
            want = self._need_mm(trunk)
            amounts = [self.step * steps for steps in STRETCH_STEPS]
            if want > span + _TOLERANCE_MM:
                amounts.insert(0, _snap_up(want - span, self.step))
            cut = (
                (source.x_mm + goal.x_mm) / 2 if horizontal
                else (source.y_mm + goal.y_mm) / 2
            )
            direction = _DIRECTION[face][0 if horizontal else 1]
            for amount in amounts:
                # Allontanare si puo' da tutt'e due le parti: si spinge in la'
                # quel che sta oltre il taglio, oppure indietro quel che sta di
                # qua. La campata cresce uguale, e quale delle due entri nel
                # foglio lo dice `is_valid`, non questa funzione.
                for signed in (direction * amount, -direction * amount):
                    key = (horizontal, cut, signed)
                    if key in seen:
                        continue
                    seen.add(key)
                    found = self._stretched(cut, horizontal, signed)
                    if found:
                        out.append(found)
        return out

    def _stretched(
        self, cut_mm: float, horizontal: bool, amount_mm: float
    ) -> Move | None:
        """Tutto cio' che sta oltre il taglio, allontanato lungo quell'asse."""

        def beyond(item: str) -> bool:
            placed = self.best[item]
            middle = (
                placed.origin.x_mm + placed.width_mm / 2
                if horizontal
                else placed.origin.y_mm + placed.height_mm / 2
            )
            return (middle - cut_mm) * amount_mm > _TOLERANCE_MM

        moving = {item for item in self.order if beyond(item)}
        if not moving or len(moving) == len(self.order):
            return None
        # Due cose non si lasciano spezzare da un taglio, e chi le divide con un
        # pezzo che si muove si muove con lui: **le rette perpendicolari**, che
        # altrimenti sarebbero loro a piegarsi, e **le tratte vuote fra due
        # raccordi di cui uno regge uno stacco** (I-046), che sono gia' al
        # proprio minimo e non possono allungarsi — il raccordo della sicurezza
        # sta stretto alla confluenza, e allungare il tronco non e' una ragione
        # per staccarnelo.
        for _ in range(len(self.order)):
            grown = set(moving)
            for trunk in self.autostrade:
                if not self.lies_straight(self.best, trunk):
                    continue
                _, face = self.port_at(
                    self.best[trunk.start.component_id], trunk.start.port_id
                )
                if (face in _HORIZONTAL_FACES) == horizontal:
                    continue
                ends = {trunk.start.component_id, trunk.end.component_id}
                if ends & grown:
                    grown |= ends
            for trunk in self.service_links:
                ends = {trunk.start.component_id, trunk.end.component_id}
                if ends & grown:
                    grown |= ends
            if grown == moving:
                break
            moving = grown
        moving |= {
            item for leader in list(moving) for item in self.below(leader)
        }
        if len(moving) == len(self.order):
            return None
        # Nessuna campata del tronco si accorcia: un taglio che stringe da una
        # parte quel che allarga dall'altra non e' un allungamento.
        for trunk in self.autostrade:
            # ⛔ **Si guardano le campate che una campata ce l'hanno**, cioe' le
            # tratte rettilinee: e' lo stesso filtro del giro qui sopra, e qui
            # mancava. Su una tratta a gomito la faccia della porta di partenza
            # non dice da che parte stia l'altro capo — l'uscita di un radiatore
            # guarda a destra e il suo accumulo sta a sinistra — e il verso
            # calcolato da li' e' quello sbagliato: la candidata veniva
            # annullata sempre. Finche' l'autostrada era il solo circuito dei
            # generatori di tratte cosi' non ce n'erano; da `DRAW-012` §B lo
            # sono anche i ritorni dei terminali, e l'allungo spariva
            # dall'elenco proprio sulle tratte che ne avevano bisogno.
            if not self.lies_straight(self.best, trunk):
                continue
            here = trunk.start.component_id
            there = trunk.end.component_id
            if (here in moving) == (there in moving):
                continue
            _, face = self.port_at(self.best[here], trunk.start.port_id)
            if (face in _HORIZONTAL_FACES) != horizontal:
                return None
            outward = _DIRECTION[face][0 if horizontal else 1] * amount_mm
            if (there in moving) != (outward > 0):
                return None
        leaders = sorted({self.leader_of(item) for item in moving})
        return self._translated(
            leaders,
            amount_mm if horizontal else 0.0,
            0.0 if horizontal else amount_mm,
        )

    def _tee_moves(self, leader: str) -> list[Move]:
        """La T che puo' girare (DRAW-004, I-027).

        Per un raccordo che ammette permutazioni degli attacchi, ogni posa —
        rotazione e permutazione — diversa da quella attuale, sul posto: cosi'
        il percorso principale puo' usare due attacchi ortogonali e il gomito
        separato sparisce. Per ognuna, anche la colonna di ogni pari portata
        sull'asse della porta che ora le sta davanti: e' il raccordo che
        decide da che parte riceve, e chi riceve si mette in asse.
        """
        if len(self.permutations[leader]) < 2:
            return []
        me = self.best[leader]
        out: list[Move] = []
        for degrees, port_map in self._orientations(leader):
            if (degrees, port_map) == (me.rotation_deg, me.port_map):
                continue
            turned = self.place_unit(leader, me.origin, degrees, port_map)
            out.append(turned)
            for _, my_port, peer_id, peer_port in self._trunks_of(leader):
                own, face = self.port_at(turned[leader], my_port)
                theirs, _ = self.port_at(self.best[peer_id], peer_port)
                column = [item for item in self.column_of(peer_id) if item not in turned]
                if not column:
                    continue
                if face in _HORIZONTAL_FACES:
                    dx, dy = 0.0, own.y_mm - theirs.y_mm
                else:
                    dx, dy = own.x_mm - theirs.x_mm, 0.0
                if (dx, dy) != (0.0, 0.0):
                    out.append({**turned, **self._translated(column, dx, dy)})
        return out

    def _composed_with(self, move: Move, around: tuple[str, ...]) -> list[Move]:
        """Le mosse dei vicini, ricavate come se `move` fosse gia' stata fatta."""
        saved = self.best
        self.best = {**saved, **move}
        try:
            neighbours = [
                item
                for item in self.scan
                if item not in self.parent_of
                and item not in around
                and any(item in self._neighbours(member) for member in around)
            ]
            out: list[Move] = []
            for neighbour in neighbours:
                for extra in self._chain_moves(neighbour) + self._port_moves(neighbour):
                    out.append({**move, **extra})
            return out
        finally:
            self.best = saved

    def _hang_moves(self, leader: str) -> list[Move]:
        """Lo stacco di un appeso si allunga o si accorcia di qualche passo.

        Un appeso porta i propri organi sullo stacco, e quegli organi occupano
        una riga: la tratta di un altro pezzo che deve passarci trova la strada
        chiusa e gira. Spostare l'appeso di un passo la riapre, e costa zero.

        Chi pende **dall'appeso** viene con lui: da quando una figura puo'
        essere profonda — dal raccordo il gruppo di riempimento, dal gruppo il
        proprio ingresso — accorciare lo stacco del gruppo senza portarsi
        l'ingresso spezzava la figura, e la candidata cadeva. Era per questo che
        lo stacco del gruppo restava un passo piu' lungo del proprio minimo
        senza che nulla occupasse il posto piu' vicino.
        """
        out: list[Move] = []
        for child in self.unit_of(leader):
            link = self.parent_of.get(child)
            if link is None:
                continue
            parent_id, port_id = link
            for count in (-2, -1, 1, 2):
                gap = self.hang_gap[child] + count * self.step
                if gap < self.hang_min[child] - _TOLERANCE_MM:
                    continue
                hung = self._rehung(child, self.best[parent_id], port_id, gap)
                move: Move = {child: hung}
                self._rehang_below(child, hung, move)
                out.append(move)
        return out

    def _gap_of(self, table: Move, child: str) -> float:
        """Lo stacco di un appeso dal proprio attacco, su una posa qualunque."""
        parent, port_id = self.parent_of[child]
        stub, _ = self.port_at(table[parent], port_id)
        own, _ = self.port_at(
            table[child], self.hang_port.get(child, self.upright[child].ports[0].id)
        )
        return max(abs(own.x_mm - stub.x_mm), abs(own.y_mm - stub.y_mm))

    def _hang_ceiling(self, child: str) -> float:
        """Quanto puo' essere lungo, al piu', lo stacco di un appeso (**D-145**).

        Il proprio minimo su griglia, e **il rettilineo che quella tratta
        pretende** — il «vincolo dichiarato» di §G.2. Cio' che lo stacco **e'**
        oggi non entra qui: questo e' il tetto della regola, non quello della
        mossa, e chi lo usa ci aggiunge il secondo.

        ⚠️ **Il rettilineo si legge da `_need_mm`, e non dal solo posto degli
        accessori in linea**, ed e' una scelta che il rapporto §7.1 porta al PM
        con i numeri. `_need_mm` non scende mai sotto `ROW_GAP_MM`, cioe' lo
        stacco minimo fra due simboli che **D-062** dichiara: e' un vincolo
        dichiarato anche lui, e su uno stacco vuoto vale dieci millimetri dove
        il minimo ne vale cinque. La lettura piu' stretta — solo il posto degli
        accessori in linea — l'ho scritta e misurata: stringe il corredo e
        **allontana il gruppo**, perche' toglie al ciclo le mosse con cui lo
        avvicinava. Sulla tavola 2 l'ingresso dell'acqua fredda passa da 120 a
        192,5 mm dal bollitore e la tavola 1 guadagna un rilievo di preflight.
        Fra le due letture ho preso quella che **disegna meglio**, perche' e' il
        PO che giudica il prodotto (D-146).
        """
        return max(self.hang_min[child], self._need_mm(self.hang_trunk[child]))

    def _refresh_hang_gaps(self) -> None:
        """Gli stacchi degli appesi, riletti dalla posa corrente."""
        for child in self.parent_of:
            self.hang_gap[child] = self._gap_of(self.best, child)

    def _rotation_moves(self, leader: str) -> list[Move]:
        me = self.best[leader]
        return [
            self.place_unit(leader, me.origin, degrees, port_map)
            for degrees, port_map in self._orientations(leader)
            if (degrees, port_map) != (me.rotation_deg, me.port_map)
        ]

    def _lift_moves(self, leader: str) -> list[Move]:
        """L'interasse: il pezzo trasla in verticale, da solo, con cio' che gli
        pende (I-046). Costa zero e si prova **per primo**: due macchine
        impilate le cui catene si contendono lo spazio si allontanano di
        qualche passo prima che la tratta giri, devii o si scavi un corridoio.
        Vicino prima che lontano, in alto prima che in basso."""
        me = self.best[leader]
        out: list[Move] = []
        for count in LIFT_STEPS:
            for dy in (-count * self.step, count * self.step):
                out.append(
                    self.place_unit(
                        leader,
                        Point(x_mm=me.origin.x_mm, y_mm=me.origin.y_mm + dy),
                        me.rotation_deg,
                    )
                )
        return out

    def _nudge_moves(self, leader: str) -> list[Move]:
        """Le traslazioni cieche: in alto prima che in basso, vicino prima che
        lontano; poi le orizzontali, che l'ordine di processo limita."""
        me = self.best[leader]
        column = self.column_of(leader)
        out: list[Move] = []
        for count in NUDGE_STEPS:
            for dy in (-count * self.step, count * self.step):
                out.append(self.place_unit(leader, Point(x_mm=me.origin.x_mm, y_mm=me.origin.y_mm + dy), me.rotation_deg))
        for count in NUDGE_STEPS:
            for dx in (-count * self.step, count * self.step):
                if len(column) > 1:
                    out.append(self._translated(column, dx, 0.0))
                else:
                    out.append(self.place_unit(leader, Point(x_mm=me.origin.x_mm + dx, y_mm=me.origin.y_mm), me.rotation_deg))
        return out

    def _axis_of(self, move: Move) -> tuple[float, float]:
        """Il verso di una candidata: dove il suo baricentro e' andato."""
        before_x = before_y = after_x = after_y = 0.0
        for item, placed in move.items():
            was = self.best[item]
            before_x += was.origin.x_mm
            before_y += was.origin.y_mm
            after_x += placed.origin.x_mm
            after_y += placed.origin.y_mm
        dx, dy = after_x - before_x, after_y - before_y
        if abs(dx) >= abs(dy):
            return (1.0, 0.0) if dx >= 0 else (-1.0, 0.0)
        return (0.0, 1.0) if dy > 0 else (0.0, -1.0)

    def candidates(self, component_id: str) -> list[Move]:
        """Le mosse alternative per un pezzo, in ordine fisso e senza doppioni."""
        return [move for _, move in self.candidates_by_kind(component_id)]

    def candidates_by_kind(self, component_id: str) -> list[tuple[str, Move]]:
        """Le mosse alternative per un pezzo, ciascuna con la propria specie.

        Prima le pose ricavate dalla topologia — dorsali, catene, porte, assi,
        colonne, gruppi, la T che gira — poi le rotazioni, infine le
        traslazioni cieche. Ogni mossa porta la posa nuova dei soli simboli
        che cambiano. La specie serve al diario: il rapporto dice quali
        alternative sono state provate.
        """
        leader = self.leader_of(component_id)
        chained = self._chain_moves(leader)
        ported = self._port_moves(leader)
        spined = self._spine_moves(leader) if self.refining else []
        assi = self._axis_moves(leader, only_spine=not self.refining)
        roomy: list[tuple[str, Move]] = []
        # L'asse entra fra le mosse che sanno **fare spazio** (PO, 11 settembre
        # 2026): «mi sembra evidente che anche la seconda PDC la puoi spostare;
        # non c'e' nessuna distanza fissa fra le due». Una posa che allinea la
        # prima macchina e finisce addosso alla seconda non e' una ragione per
        # scartarla: e' una ragione per spostare anche la seconda, di quanto
        # serve a lei e non per forza di quanto si e' mossa la prima.
        for kind, moves in (
            ("dorsale", spined),
            ("catena", chained),
            ("porta", ported),
            ("asse", assi),
        ):
            for move in moves:
                roomy.extend(
                    (f"{kind}+spazio", extra)
                    for extra in self._with_room(move, self._axis_of(move))
                )
        stretched = self._stretch_moves(leader)
        if self.refining:
            generated: list[tuple[str, Move]] = [
                *(("allungo", move) for move in stretched),
                # **La traslazione di blocco sta qui, nella rifinitura**, e non
                # nella posa. DRAW-008 §C.1 diceva «un tronco fermo»; DRAW-009
                # §B.1 corregge: il tronco e' un corpo rigido, non un corpo
                # immobile, e trasla. Ma trasla su una tavola gia' disposta: in
                # mezzo alla posa la stessa mossa apre un ramo del greedy che
                # vince sulla chiave e perde l'impilamento dei rami paralleli —
                # misurato sulla fixture a due zone, dove le due zone smettono
                # di stare sulla stessa colonna. Il tronco si alza quando il
                # resto ha gia' preso il proprio posto.
                *(("blocco", move) for move in self._block_moves(leader)),
                *(("interasse", move) for move in self._lift_moves(leader)),
                *(("dorsale", move) for move in spined),
                *(("catena", move) for move in chained),
                *(("porta", move) for move in ported),
                *(("asse", move) for move in assi),
                *roomy,
                *(("colonna", move) for move in self._column_moves(leader)),
                *(("gruppo", move) for move in self._shift_moves(leader)),
                *(("tee", move) for move in self._tee_moves(leader)),
                *(("stacco", move) for move in self._hang_moves(leader)),
                *(("rotazione", move) for move in self._rotation_moves(leader)),
                *(("passo", move) for move in self._nudge_moves(leader)),
            ]
        else:
            generated = [
                # L'allungo viene per primo: quando il corredo non entra, la
                # risposta giusta e' allungare il tronco, non spostare il pezzo
                # che ci sta stretto (DRAW-008 §B.2).
                *(("allungo", move) for move in stretched),
                *(("interasse", move) for move in self._lift_moves(leader)),
                # L'allineamento del tronco entra **nella posa**, non solo nella
                # rifinitura (DRAW-007 §C.1). Fino a DRAW-006-R1 le candidate di
                # asse nascevano soltanto a rifinitura, cioe' quando la
                # disposizione era gia' decisa: si chiedeva al ciclo di
                # raddrizzare due macro-linee dopo aver costruito la tavola
                # attorno a una posa che non le prevedeva. Qui la fase prima
                # guarda **solo le macchine di spina**: l'asse del tronco e' una
                # struttura, il resto e' contorno e si sistema dopo.
                *(("asse", move) for move in assi),
                *(("catena", move) for move in chained),
                *(("porta", move) for move in ported),
                *roomy,
                *(("colonna", move) for move in self._column_moves(leader)),
                *(("gruppo", move) for move in self._shift_moves(leader)),
                *(("scambio", move) for move in self._swap_moves(leader)),
                *(("stacco", move) for move in self._hang_moves(leader)),
                *(("rotazione", move) for move in self._rotation_moves(leader)),
                *(("passo", move) for move in self._nudge_moves(leader)),
            ]
        # Chi divide una pila a terra con altri non se ne sfila: una mossa che
        # lo sposta in orizzontale porta con se' i compagni, dello stesso tanto.
        # Chi sta su una tubazione prova tutte e due le cose: da solo e in
        # colonna, e decide il costo.
        column = self.column_of(leader)
        if len(column) > 1:
            completed: list[tuple[str, Move]] = []
            grounded = self.standings[leader] is Standing.GROUND
            for kind, move in generated:
                if leader not in move:
                    completed.append((kind, move))
                    continue
                dx = move[leader].origin.x_mm - self.best[leader].origin.x_mm
                mates = [item for item in column if item != leader and item not in move]
                if dx == 0.0 or not mates:
                    completed.append((kind, move))
                    continue
                if not grounded:
                    completed.append((kind, move))
                completed.append((kind, {**self._translated(mates, dx, 0.0), **move}))
            generated = completed
        out: list[tuple[str, Move]] = []
        seen: set[Signature] = set()
        for kind, move in generated:
            changed = {
                item: placed
                for item, placed in self._with_followers(move).items()
                if not _same_pose(placed, self.best[item])
            }
            if not changed:
                continue
            # **Un allungo scorre lungo un asse, mai di traverso**: e' la
            # ragione per cui conserva ogni allineamento. Il taglio si muove su
            # un asse solo, ma cio' che si porta dietro no: una figura appesa a
            # un pezzo che si muove si **riappende**, e riappendendosi puo'
            # cambiare anche l'altra coordinata. Allora non e' piu' una campata
            # che cresce, e' un pezzo che scavalca: la candidata si scarta qui,
            # dove il seguito e' gia' stato aggiunto e si vede per intero.
            if kind == "allungo" and any(
                abs(placed.origin.x_mm - self.best[item].origin.x_mm) > _TOLERANCE_MM
                and abs(placed.origin.y_mm - self.best[item].origin.y_mm) > _TOLERANCE_MM
                for item, placed in changed.items()
            ):
                continue
            key = _signature(dict(sorted(changed.items())))
            if key in seen:
                continue
            seen.add(key)
            out.append((kind, changed))
        return out

    # -- la validita' --------------------------------------------------------

    def is_valid(self, move: Move) -> bool:
        """I vincoli che nessun guadagno compra: standing, terra, griglia, area,
        stacchi, colonne intere, ordine di processo."""
        after = dict(self.best)
        after.update(move)
        moved_leaders = {self.leader_of(item) for item in move}
        units = {item: self.leader_of(item) for item in self.order}
        for item, placed in move.items():
            before = self.best[item]
            if self.standing_at(item, placed.rotation_deg) is not self.standings[item]:
                return False
            if placed.port_map and placed.port_map not in self.permutations[item]:
                return False
            # La quota di chi sta a terra e' libera dentro l'area in tutte e
            # due le fasi (I-046): spostare una macchina in verticale costa
            # zero, e l'interasse fra due macchine impilate e' la prima cosa
            # da provare quando le loro catene si contendono lo spazio —
            # prima di curve, deviazioni e corridoi. Il riquadro, invece,
            # resta quello: la posa non ruota chi sta a terra.
            if (
                not self.refining
                and self.standings[item] is Standing.GROUND
                and item not in self.parent_of
                and placed.height_mm != before.height_mm
            ):
                return False
            if not is_on_grid(placed.origin.x_mm - self.area.x_mm, self.step):
                return False
            if not is_on_grid(placed.origin.y_mm - self.area.y_mm, self.step):
                return False
            if placed.origin.x_mm < self.area.x_mm - _TOLERANCE_MM:
                return False
            if placed.origin.y_mm < self.area.y_mm - _TOLERANCE_MM:
                return False
            if placed.right_mm > self.area.right_mm + _TOLERANCE_MM:
                return False
            # La «linea di terra» non e' un vincolo (PO, 11 settembre 2026):
            #
            #     «Non c'e', non esiste. E' uno schema quello che disegniamo,
            #     non c'e' nessun sopra e sotto linea di terra o simile.»
            #
            # Il segno non si disegna piu' da DRAW-004, ma la regola era
            # rimasta: niente poteva scendere sotto l'83% dell'altezza del
            # foglio, e quel pavimento invisibile impediva all'accumulo di
            # scendere — perche' il suo scarico ci arrivava contro — e quindi
            # impediva l'allineamento del tronco. Il solo limite e' il foglio,
            # ed e' controllato sopra.
            # Lo stesso stacco del posizionamento fra due simboli di figure
            # diverse (D-062); dentro la stessa figura basta non sovrapporsi.
            for other_id in self.order:
                if other_id == item:
                    continue
                gap = 0.0 if units[other_id] == units[item] else ROW_GAP_MM
                if not _too_close(placed, after[other_id], gap):
                    continue
                # **Una mossa risponde di cio' che crea, non di cio' che
                # trova.** Se i due erano gia' addosso prima — capita quando la
                # fase del tronco consegna una posa che si sovrappone, e sulla
                # tavola 2 ne consegna nove coppie — pretendere che ogni
                # candidata li separi rende **ogni** candidata non valida, e il
                # ciclo resta inchiodato sulla posa peggiore che abbia mai
                # avuto. E' lo stesso difetto per cui esiste `_first_routable`:
                # il ciclo rinunciava senza provare una mossa. Cio' che nessuna
                # mossa puo' fare e' **aggiungere** una sovrapposizione.
                if not _too_close(self.best[item], self.best[other_id], gap):
                    return False
        # Una pila a terra non si sfila di un elemento (D-073): chi la divide
        # con un altro si sposta in orizzontale solo insieme a lui. Chi sta su
        # una tubazione e divide la colonna con un pari puo' anche muoversi da
        # solo: la mossa di gruppo esiste comunque, e decide il costo.
        # E una pila conserva il proprio ordine (DRAW-004): chi sta sopra
        # resta sopra, qualunque quota prendano i membri.
        for leader in moved_leaders:
            column = self.column_of(leader)
            if len(column) < 2:
                continue
            stacked_before = sorted(column, key=lambda item: self.best[item].origin.y_mm)
            stacked_after = sorted(column, key=lambda item: after[item].origin.y_mm)
            if self.refining and stacked_before != stacked_after:
                return False
            if move.get(leader, self.best[leader]).origin.x_mm == self.best[leader].origin.x_mm:
                continue
            if self.standings[leader] is not Standing.GROUND:
                continue
            dx = move[leader].origin.x_mm - self.best[leader].origin.x_mm
            for mate in column:
                if mate == leader:
                    continue
                if mate not in move or move[mate].origin.x_mm - self.best[mate].origin.x_mm != dx:
                    return False
        # Un raccordo che regge soltanto uno stacco statico sta **stretto** al
        # raccordo a cui e' attaccato (I-046): la tratta vuota fra i due non
        # si allunga oltre il minimo — una posa che gia' la tiene lunga puo'
        # solo accorciarla. E' cosi' che la sicurezza di circuito resta vicino
        # al gruppo: lungo la retta della mandata il tubo totale e' lo stesso
        # ovunque stia il suo raccordo, e senza questo vincolo scivolava
        # verso l'accumulo per uno spareggio.
        for trunk in self.service_links:
            ends = (trunk.start.component_id, trunk.end.component_id)
            if not any(item in move for item in ends):
                continue
            was = self._link_mm(self.best, trunk)
            now_mm = self._link_mm(after, trunk)
            if now_mm > max(self._need_mm(trunk), was) + _TOLERANCE_MM:
                return False
        # **Un organo di servizio sta addosso al pezzo che serve** (**D-145**,
        # `DRAW-013` §G), e la vicinanza e' un **vincolo**, non un costo. Sta
        # qui, fra cio' che nessun guadagno compra, e non in `SheetCost`: D-139
        # ha tolto i millimetri dalle voci di costo e fin qui **niente** aveva
        # preso il posto della riga che teneva stretto il corredo — «ogni
        # millimetro oltre il minimo peggiora il costo» di `DRAW-005-R1`
        # blocco E. Il PO: «le valvole di servizio devono rimanere vicino ai
        # loro padroni; una valvola in mezzo a una linea cosi' lontana da tutto
        # e' equivoca».
        #
        # Il conto e' **monotono**, come quello del tronco: uno stacco al
        # proprio minimo non si allunga, e uno che il posizionamento ha dovuto
        # fare piu' lungo — perche' il posto era preso — puo' solo accorciarsi.
        # L'unico allungamento ammesso e' quello che il minimo stesso dichiara,
        # cioe' il posto per gli accessori in linea sulla stessa tratta, e
        # quello e' gia' dentro `hang_min` (`place.stub_minimum_mm`).
        for child in self.parent_of:
            parent, _port_id = self.parent_of[child]
            if child not in move and parent not in move:
                continue
            # Il tetto: il proprio minimo, cio' che lo stacco e' gia', e **il
            # posto che gli accessori in linea pretendono su quella tratta**.
            # Quest'ultimo e' il «vincolo dichiarato» di §G.2, ed e' esattamente
            # l'esempio che D-145 fa — «far posto a un altro accessorio in linea
            # sulla stessa tratta». Senza di lui il vincolo murerebbe l'unica
            # mossa capace di far entrare una valvola che non ci sta: misurato
            # sulla tavola 2, dove l'intercettazione dell'acquedotto non trovava
            # piu' il proprio rettilineo e la tavola smetteva di uscire.
            #
            # ⛔ **Non si legge da `_need_mm`**, che sembrerebbe la funzione
            # giusta e non lo e': quella non scende mai sotto `ROW_GAP_MM`,
            # cioe' dieci millimetri, perche' misura la distanza fra **due
            # simboli** e non il bisogno di questa tratta. Usata come tetto
            # regalava cinque millimetri di gioco a ogni stacco vuoto — il cui
            # minimo e' cinque — e il vincolo non teneva niente. Misurato sulla
            # tavola 2: nove appesi, sei dei quali con `room` a zero e
            # `_need_mm` a dieci.
            ceiling = max(self._hang_ceiling(child), self.hang_gap[child])
            if self._gap_of(after, child) > ceiling + _TOLERANCE_MM:
                return False
        # **La rettilineita' del tronco e' un vincolo, non una voce di costo**
        # (DRAW-008 §A.4). Sta qui, dove stanno i vincoli che nessun guadagno
        # compra, e non in `SheetCost`: una mossa che piega un'autostrada gia'
        # dritta viene rifiutata anche se la tavola intera costasse meno. Il
        # conto e' monotono, come l'ordine di processo: cio' che e' dritto non
        # si storce, cio' che storto era puo' solo raddrizzarsi.
        if self.autostrade:
            for trunk in self.autostrade:
                if not self.lies_straight(self.best, trunk):
                    continue
                ends = (trunk.start.component_id, trunk.end.component_id)
                if not any(item in move for item in ends):
                    continue
                if not self.lies_straight(after, trunk):
                    return False
        # **E l'invariante vero sta sulla catena intera** (DRAW-012 §C). Quello
        # qui sopra guarda una tratta per volta, e su una tratta di cinque
        # millimetri fra due raccordi e' vero comunque la si posi: e' il motivo
        # per cui la tavola 4 usciva storta con tutti i numeri verdi. Qui si
        # guarda l'**autostrada intera** — da un capo all'altro, attraverso i
        # propri crocevia — e si nega alla mossa di farle prendere una piega che
        # non aveva. Stessa monotonia: cio' che e' dritto non si storce.
        for highway in self.highways:
            if not self.chain_in_line(self.best, highway):
                continue
            if not any(item in move for item in highway.component_ids):
                continue
            if not self.chain_in_line(after, highway):
                return False
        # **Nella fase delle strade di servizio il tronco e' fermo nella forma**
        # (DRAW-008 §C.1). «Fermo» qui vuol dire due cose, e tutt'e due sono
        # vincoli: nessuna mossa piega un'autostrada — l'ha appena detto il
        # blocco sopra — e nessuna **gira** una macchina di spina o ne
        # ridistribuisce gli attacchi. Girare una macchina di spina rifa' la
        # forma del tronco, e la forma e' decisa; scorrere lungo il proprio
        # asse, invece, non la tocca — e resta permesso, perche' e' cosi' che
        # una strada di servizio trova la propria strada senza chiedere al
        # tronco di piegarsi.
        if self.phase is Phase.SERVIZIO and self.spine_layout is not None:
            for item, placed in move.items():
                if item not in self.spine:
                    continue
                before = self.best[item]
                if placed.rotation_deg != before.rotation_deg:
                    return False
                if placed.port_map != before.port_map:
                    return False
        # L'ordine di processo e' un vincolo, non un costo (D-060), e si legge
        # sul verso del fluido: la mandata va a destra, il ritorno torna a
        # sinistra. Una posa che gia' contraddice il verso puo' essere corretta,
        # e nessuna puo' cominciare a contraddirlo; dove il verso non e' deciso
        # vale l'ordine gia' disegnato.
        for trunk in self.trunks:
            start_id, end_id = trunk.start.component_id, trunk.end.component_id
            if start_id == end_id or start_id not in self.best or end_id not in self.best:
                continue
            if units[start_id] == units[end_id]:
                continue
            if units[start_id] not in moved_leaders and units[end_id] not in moved_leaders:
                continue

            def centre(table: Move, item: str) -> float:
                return table[item].origin.x_mm + table[item].width_mm / 2

            was = _relation(centre(self.best, start_id), centre(self.best, end_id))
            now = _relation(centre(after, start_id), centre(after, end_id))
            if now == was:
                continue
            flow = self.flow.get(trunk.connection_ids)
            if flow is True and now <= 0:
                continue
            if flow is False and now >= 0:
                continue
            return False
        return True

    def _swapped_in_column(self, item: str, move: Move) -> bool:
        """Vero se la quota nuova e' quella che un compagno di pila lascia."""
        column = [mate for mate in self.column_of(item) if self.standings[mate] is Standing.GROUND]
        if len(column) < 2:
            return False
        before = sorted(self.best[mate].bottom_mm for mate in column)
        after = sorted(move.get(mate, self.best[mate]).bottom_mm for mate in column)
        return before == after

    # -- il ciclo --------------------------------------------------------------

    def _offenders(self, current: Measured) -> list[str]:
        """I pezzi ai capi di una tratta che costa qualcosa, in ordine di posa."""
        guilty: set[str] = set()
        for index, (trunk, route) in enumerate(
            zip(self.trunks, current.settled.routes, strict=True)
        ):
            has_bends = any(len(segment) > 2 for segment in route.segments)
            arrival = self.best[trunk.end.component_id]
            goal, _ = self.port_at(arrival, trunk.end.port_id)
            turned_back = overshoot_beyond_goal_mm(route, goal) > _TOLERANCE_MM or any(
                overshoot_mm(segment, self.step) > _TOLERANCE_MM for segment in route.segments
            )
            far = sum(
                abs(after.x_mm - before.x_mm) + abs(after.y_mm - before.y_mm)
                for segment in route.segments
                for before, after in zip(segment, segment[1:], strict=False)
            ) > self._need_mm(trunk) + _TOLERANCE_MM
            if has_bends or route.crossings or index in current.settled.unfit or turned_back or far:
                guilty.add(self.leader_of(trunk.start.component_id))
                guilty.add(self.leader_of(trunk.end.component_id))
        # E chi regge un appeso il cui stacco e' **piu' lungo del proprio
        # minimo**: accorciarlo toglie tubo e non costa niente, ma nessuna delle
        # voci qui sopra se ne accorge. Uno stacco dritto, senza incroci e piu'
        # corto del rettilineo che la tratta pretende (`_need_mm`, che non
        # scende sotto lo stacco fra due simboli) non e' «lontano» per nessuno,
        # e restava lungo com'era uscito dalla posa (I-046).
        for child, (parent, _port_id) in self.parent_of.items():
            if self.hang_gap[child] > self.hang_min[child] + _TOLERANCE_MM:
                guilty.add(self.leader_of(parent))
        return [item for item in self.scan if item in guilty]

    def run(self) -> list[PlacedSymbol]:
        """Le fasi, nell'ordine che il PO ha fissato (DRAW-008).

        Il **tronco** non si cerca qui: `spine.lay_the_spine` l'ha gia'
        costruito e questo ciclo lo riceve gia' dritto. Da qui in avanti la sua
        rettilineita' e' un vincolo di `is_valid`, non una voce di costo.

        **Il corredo** (§B): valvole, filtri e raccordi entrano dentro il tronco
        posato; dove non ci stanno il tronco si allunga, con la mossa nuova
        `allungo`. Le macchine di spina si muovono ancora, perche' allungare
        vuol dire proprio allontanarle.

        **Le strade di servizio** (§C): stacchi, diramazioni e appesi si
        attaccano a un tronco ormai **fermo**. Qui le curve si pagano, con i
        pesi della gerarchia, e si accettano — ma nessuna piega un'autostrada.

        Dentro ciascuna fase decide `SheetCost`, che non cambia: e' l'ordine
        delle decisioni a cambiare, non il criterio (§D).
        """
        current = self.measure(self.best)
        if current is None:
            current = self._first_routable()
        if current is None:
            return [self.best[item] for item in self.order]
        self.phase = Phase.CORREDO
        current = self._fit_the_corredo(current)
        self.phase = Phase.SERVIZIO
        current = self._settle_placement(current)
        self.refining = True
        self._refine_axes(current)
        return [self.best[item] for item in self.order]

    def _fit_the_corredo(self, current: Measured) -> Measured:
        """La fase del corredo: si allunga il tronco finche' i pezzi ci stanno.

        Si guardano le sole tratte che **non ospitano i propri accessori** —
        quelle che `settle_sheet` segna `unfit` — e le sole macchine di spina ai
        loro capi, perche' allungare e' una mossa del tronco. Una passata basta
        quasi sempre; il tetto e' quello della posa, e scatta in un punto che
        dipende solo dagli ingressi.
        """
        for _ in range(MAX_PASSES):
            moved = False
            for leader in self._cramped(current):
                for kind, move in self.candidates_by_kind(leader):
                    if kind != "allungo":
                        continue
                    if self.trials >= MAX_TRIAL_ROUTINGS:
                        return current
                    if not self.is_valid(move):
                        continue
                    trial = dict(self.best)
                    trial.update(move)
                    found = self.measure(trial)
                    # **L'allungo si paga con il corredo, non con il
                    # riempimento** (D-142 §A.3): qui il criterio e' la sola
                    # ragione per cui il contratto lo ammetteva.
                    accepted = found is not None and found.cost.beats(current.cost)
                    self.journal.append(
                        Attempt(
                            "corredo",
                            kind,
                            leader,
                            None if found is None else found.cost.key(),
                            accepted,
                        )
                    )
                    if found is None or not accepted:
                        continue
                    self.best = trial
                    self._refresh_hang_gaps()
                    current = found
                    moved = True
                    break
            if not moved:
                break
        return current

    def _cramped(self, current: Measured) -> list[str]:
        """Le macchine di spina ai capi di una tratta a cui manca il rettilineo.

        Sono le tratte che non ospitano i propri accessori e quelle la cui
        campata e' piu' corta di quel che gli accessori pretendono: le prime le
        dichiara `settle_sheet`, le seconde si contano sulle porte.
        """
        guilty: set[str] = set()
        for index, trunk in enumerate(self.trunks):
            short = self._span_mm(self.best, trunk) + _TOLERANCE_MM < self._need_mm(
                trunk
            )
            if index not in current.settled.unfit and not short:
                continue
            for item in (trunk.start.component_id, trunk.end.component_id):
                guilty.add(self.leader_of(item))
        return [item for item in self.scan if item in guilty]

    def _first_routable(self) -> Measured | None:
        """Una posa da cui partire, quando quella iniziale non si instrada.

        La posa iniziale e' un'ipotesi, e puo' capitare che una sua tratta non
        trovi strada nemmeno in modo tollerante — uno stacco murato da un
        vicino, per esempio. Prima il ciclo rinunciava senza provare una
        mossa, e la tavola falliva o riusciva a seconda di un dettaglio della
        posa iniziale (DRAW-005). Qui si prova, pezzo per pezzo nell'ordine di
        posa e specie per specie, la **prima** candidata che si lascia
        instradare: e' una posa cattiva, ma misurabile, e da li' il ciclo
        riparte come sempre. Il tetto di prove e' quello della posa, e scatta
        in un punto che dipende solo dagli ingressi; ogni prova finisce nel
        diario.
        """
        for leader in self.scan:
            # Fra le candidate di un pezzo che si lasciano instradare si tiene
            # **la migliore**, non la prima (I-046): la prima dipendeva
            # dall'ordine in cui le mosse sono generate, e da li' il ciclo
            # ripartiva da una posa cattiva che poi non lasciava piu'. Il
            # tetto di prove resta quello, e scatta allo stesso modo.
            best_found: Measured | None = None
            best_trial: Move | None = None
            best_kind = ""
            for kind, move in self.candidates_by_kind(leader):
                if self.trials >= MAX_TRIAL_ROUTINGS:
                    break
                if not self.is_valid(move):
                    continue
                trial = dict(self.best)
                trial.update(move)
                found = self.measure(trial)
                self.journal.append(
                    Attempt(
                        "posa",
                        kind,
                        leader,
                        None if found is None else found.cost.key(),
                        False,
                    )
                )
                if found is None:
                    continue
                if best_found is None or found.cost.beats(best_found.cost):
                    best_found, best_trial, best_kind = found, trial, kind
            if best_found is not None and best_trial is not None:
                self.journal.append(Attempt("posa", best_kind, leader, best_found.cost.key(), True))
                self.best = best_trial
                self._refresh_hang_gaps()
                return best_found
            if self.trials >= MAX_TRIAL_ROUTINGS:
                return None
        return None

    def _settle_placement(self, current: Measured) -> Measured:
        for _ in range(MAX_PASSES):
            moved = False
            for leader in self._offenders(current):
                for kind, move in self.candidates_by_kind(leader):
                    if self.trials >= MAX_TRIAL_ROUTINGS:
                        return current
                    if not self.is_valid(move):
                        continue
                    trial = dict(self.best)
                    trial.update(move)
                    found = self.measure(trial)
                    accepted = found is not None and found.cost.beats(current.cost)
                    self.journal.append(
                        Attempt(
                            self.phase.name.lower(),
                            kind,
                            leader,
                            None if found is None else found.cost.key(),
                            accepted,
                        )
                    )
                    if found is None or not accepted:
                        continue
                    self.best = trial
                    self._refresh_hang_gaps()
                    current = found
                    moved = True
                    break
            if not moved:
                break
        return current

    def _refine_axes(self, current: Measured) -> Measured:
        spent = self.trials
        for _ in range(MAX_PASSES):
            moved = False
            for leader in self._offenders(current):
                best_found: Measured | None = None
                best_trial: Move | None = None
                best_kind = ""
                for kind, move in self.candidates_by_kind(leader):
                    if self.trials - spent >= MAX_AXIS_TRIALS:
                        break
                    if not self.is_valid(move):
                        continue
                    trial = dict(self.best)
                    trial.update(move)
                    found = self.measure(trial)
                    self.journal.append(
                        Attempt(
                            "rifinitura",
                            kind,
                            leader,
                            None if found is None else found.cost.key(),
                            False,
                        )
                    )
                    if found is None or not found.cost.beats(current.cost):
                        continue
                    if best_found is None or found.cost.beats(best_found.cost):
                        best_found, best_trial, best_kind = found, trial, kind
                if best_found is not None and best_trial is not None:
                    self.journal.append(
                        Attempt("rifinitura", best_kind, leader, best_found.cost.key(), True)
                    )
                    self.best = best_trial
                    self._refresh_hang_gaps()
                    current = best_found
                    moved = True
                if self.trials - spent >= MAX_AXIS_TRIALS:
                    self.axis_trials = self.trials - spent
                    return current
            if not moved:
                break
        self.axis_trials = self.trials - spent
        return current


def improve_sheet(
    project: ProjectModel,
    partition: SheetPartition,
    catalog: ComponentRegistry,
    frame: SheetFrame,
    placed: list[PlacedSymbol],
    inline_ids: frozenset[str],
    spine_layout: SpineLayout | None = None,
    conceded: frozenset[TrunkKey] = frozenset(),
) -> list[PlacedSymbol]:
    """Rivede la disposizione reinstradando: si tiene solo cio' che batte la
    posa corrente sul confronto unico della tavola (`SheetCost`).

    Con `spine_layout` il ciclo sa che il tronco e' gia' stato costruito e non
    torna a cercarlo: lo riceve e non lo perde (DRAW-008).

    `conceded` sono le tratte a cui **l'ultima spiaggia** ha gia' concesso la
    piega (DRAW-012 §F): le catene che le contengono escono dall'invariante, e
    il ciclo puo' piegarle per far entrare il resto. Si concede una catena per
    volta, e chi chiama dichiara quale."""
    if not placed or not partition.trunks:
        return list(placed)
    return Improver(
        project, partition, catalog, frame, placed, inline_ids, spine_layout, conceded
    ).run()


__all__ = [
    "BLOCK_STEPS",
    "MAX_AXIS_TRIALS",
    "MAX_PASSES",
    "MAX_TRIAL_ROUTINGS",
    "STRETCH_STEPS",
    "Attempt",
    "Improver",
    "Measured",
    "Move",
    "Phase",
    "SheetCost",
    "improve_sheet",
    "objective_of",
    "overshoot_beyond_goal_mm",
    "overshoots_the_goal",
]
