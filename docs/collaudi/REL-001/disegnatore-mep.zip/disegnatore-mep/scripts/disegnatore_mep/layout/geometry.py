"""Il modello geometrico derivato.

Il modello tecnico canonico resta la fonte di verita' e **non contiene
coordinate** (D-026, ADR 0002). Posizioni, spezzate, testi, legenda e rimandi
vivono qui, in un modello separato che si rigenera dal primo: correggere una
tavola significa correggere il modello tecnico o il piano di impaginazione,
mai queste coordinate.
"""

import hashlib
import json
import math
from enum import StrEnum
from typing import Any

from pydantic import Field, SerializerFunctionWrapHandler, model_serializer

from disegnatore_mep.model.base import FiniteFloat, StrictModel


class FlowKind(StrEnum):
    """Che specie di tratto e', ai fini della freccia (DRAW-005-R1, I-042).

    La freccia di verso compare solo dove esiste un flusso ordinario diretto.
    Uno stacco di servizio non lo ha: il manometro e il vaso insistono sul
    ritorno tecnico senza portare una circolazione; lo sfiato e la sicurezza
    su uno stacco nemmeno. Il riempimento e' acqua che **entra** nel circuito,
    e uno scarico esplicitamente modellato e' acqua che ne **esce**. La specie
    si decide sul modello e sul catalogo, mai sulla geometria.
    """

    ORDINARY = "ordinary"
    """Una tubazione del percorso: la freccia segue il verso del modello."""

    STATIC = "static"
    """Uno stacco senza circolazione ordinaria: nessuna freccia."""

    INBOUND = "inbound"
    """Uno stacco da cui l'acqua entra nel circuito: la freccia va verso il
    tratto che lo regge."""

    OUTBOUND = "outbound"
    """Uno stacco da cui l'acqua esce dal circuito: la freccia se ne allontana."""


class Point(StrictModel):
    x_mm: FiniteFloat
    y_mm: FiniteFloat


class PlacedSymbol(StrictModel):
    """Un simbolo posato: dove sta, come e' ruotato, quanto ingombra."""

    component_id: str
    symbol_id: str
    rotation_deg: int
    specchiato: bool = False
    """Se il simbolo e' **specchiato** attorno al proprio asse verticale.

    **D-169**: le giaciture di un simbolo sono **otto**, non quattro — le
    quattro rotazioni ammesse, per diritto o specchiato. Lo specchio si applica
    **prima** della rotazione, ed e' una facolta' del **motore**: il manifesto
    non la dichiara.

    ⚠ **Chi rilegge le porte di un pezzo posato deve passare di qui.**
    `manifest.rotated(placed.rotation_deg)` senza lo specchio da' le facce
    sbagliate, e la linea arriva da una porta che guarda dall'altra parte.
    Per questo il valore sta **accanto** alla rotazione e non altrove.

    Assente in una geometria scritta prima del 22 settembre 2026: si legge
    come `False`, che e' la giacitura di tutte quelle tavole.
    """
    origin: Point
    width_mm: FiniteFloat = Field(gt=0)
    height_mm: FiniteFloat = Field(gt=0)
    tag: str | None = None
    port_map: dict[str, str] = Field(default_factory=dict)
    """Quale attacco fisico del simbolo serve ciascuna porta del modello.

    Vuoto vuol dire «lo stesso»: la porta `a` del modello sta sull'attacco
    `a` del simbolo. Per un raccordo a T — che si disegna come un punto e ha
    tre attacchi uguali — la posa puo' decidere che la porta di prosecuzione
    stia sull'attacco perpendicolare, cosi' che il percorso principale giri
    nel raccordo invece che in un gomito a parte (DRAW-004, I-027). E' una
    proprieta' della posa: il grafo, le connessioni e le porte del modello
    non cambiano, e ogni lettura di una porta passa da qui.
    """

    @property
    def right_mm(self) -> float:
        return self.origin.x_mm + self.width_mm

    @property
    def bottom_mm(self) -> float:
        return self.origin.y_mm + self.height_mm

    port_flows: dict[str, str] = Field(default_factory=dict)
    """Il verso dell'acqua sulle porte che portano una freccia di verso.

    Lo scrive la posa leggendo il `PortFlow` della definizione di catalogo
    (DRAW-005, I-032): il renderer, che riceve la geometria e la libreria dei
    simboli ma non il catalogo, punta la freccia da qui — verso la porta se
    l'acqua esce dal simbolo, verso l'interno se vi entra. Vuoto per i simboli
    senza frecce; una geometria agli atti senza questo campo si legge ancora e
    disegna le frecce verso la porta, come la libreria le pubblica.
    """

    def physical_port(self, port_id: str) -> str:
        """L'attacco del simbolo su cui sta questa porta del modello."""
        return self.port_map.get(port_id, port_id)


class RoutedTrunk(StrictModel):
    """Una tratta instradata: la spezzata ortogonale, con le sue interruzioni.

    `segments` e' l'elenco delle polilinee da disegnare: una sola quando la
    tratta non porta accessori in linea, piu' di una quando li porta, perche'
    ogni accessorio interrompe la linea invece di esservi sovrapposto (D-027).
    """

    network_id: str
    medium: str = ""
    """Il fluido, che decide colore e tratto: la rete da sola non basta."""
    supply: bool = True
    """Andata o ritorno. Su una tavola sono due linee distinte, non una.

    Per uno stacco e' il servizio della tratta che lo regge (DRAW-005-R1,
    I-042): il manometro appeso al ritorno e' del ritorno, blu, comunque lo
    stacco sia disegnato."""
    connection_ids: list[str] = Field(default_factory=list)
    segments: list[list[Point]] = Field(default_factory=list)
    crossings: list[Point] = Field(default_factory=list)
    flow_kind: FlowKind = FlowKind.ORDINARY
    """La specie del tratto, che decide se e come si disegna la freccia.

    Una geometria agli atti senza questo campo si legge ancora, come flusso
    ordinario: e' cio' che ogni tratta era prima che la specie esistesse."""
    flow_from_start: bool = True
    """Il verso del flusso rispetto alla spezzata: dal primo punto all'ultimo,
    oppure al contrario. Lo decide il modello — la porta da cui il fluido esce
    — e non l'ordine in cui la tratta e' stata scritta o instradata."""
    unresolved: bool = False
    """Vero quando questa tratta **non si e' instradata** e la spezzata che
    porta e' un ripiego dichiarato (**D-150**).

    Non e' un dettaglio di rendering: e' il contratto di questa tavola. Una
    tratta cosi' non evita ostacoli, non rispetta i rettilinei che le catene
    pretendono e puo' sovrapporsi ad altro. Esiste perche' **una tavola con una
    tratta segnata vale piu' di nessuna tavola**: il PO la puo' guardare e
    giudicare, e il disegnatore la chiude in CAD sul DXF.

    Chi legge una geometria agli atti senza questo campo la legge come risolta,
    che e' cio' che ogni tratta era prima che il ripiego esistesse."""


class Richiamo(StrictModel):
    """Il richiamo di un'etichetta staccata dal proprio pezzo o dalla propria linea
    (I-162, I-163): **la freccia piena** tocca il pezzo o la linea in `punta`; **un
    tratto obliquo a 45 gradi** arriva al `gomito`; da li' **la spalla orizzontale**
    arriva in `spalla`, accanto alla scritta, a meta' delle sue maiuscole. E' la
    forma dell'esempio del PO, che supera D-075: il richiamo non entra piu' nella
    scritta con la sola diagonale."""

    punta: Point
    gomito: Point
    spalla: Point

    @property
    def segmenti(self) -> tuple[tuple[Point, Point], tuple[Point, Point]]:
        """Il tratto obliquo e la spalla, nell'ordine in cui si disegnano."""
        return ((self.punta, self.gomito), (self.gomito, self.spalla))


class PlacedLabel(StrictModel):
    """Un testo sulla tavola: mai una denominazione, solo valore o sigla (D-052)."""

    id: str
    text: str
    role: str
    anchor: Point
    leader_from: Point | None = None
    """Da dove parte la linea di richiamo, quando il testo sta fuori dal corpo."""
    corpo_mm: FiniteFloat | None = Field(default=None, gt=0)
    """Il corpo del testo, se non e' quello delle scritte della tavola: una sigla che
    a 9 punti non trova posto accanto al pezzo scende a 8, il minimo del PO
    (I-159, I-160). `None` e' il corpo di sempre, e non si scrive."""
    richiamo: Richiamo | None = None
    """Il richiamo con freccia e spalla (I-162, I-163), quando il testo sta lontano
    dal pezzo. `leader_from` e' il richiamo di prima — una sola diagonale fino alla
    base del testo —: le geometrie scritte prima lo portano ancora, e si
    disegnano come allora."""

    @model_serializer(mode="wrap")
    def _senza_il_corpo_di_sempre(self, handler: SerializerFunctionWrapHandler) -> dict[str, Any]:
        dati: dict[str, Any] = handler(self)
        for campo in ("corpo_mm", "richiamo"):
            if dati.get(campo) is None:
                dati.pop(campo, None)
        return dati


class DiametroSullaTavola(StrictModel):
    """Il DN di un tratto, scritto in linea con la tubazione (REL-007, D-193).

    Un'etichetta sola per tratto (I-143). `ancora` e' la base della scritta: per
    un'etichetta orizzontale l'angolo in basso a sinistra, come un `<text>` SVG;
    per una **verticale**, che si legge dal basso verso l'alto (I-152), il punto
    da cui la scritta sale, ed e' li' che si gira di novanta gradi."""

    testo: str = Field(min_length=1)
    ancora: Point
    verticale: bool = False
    connection_ids: list[str] = Field(default_factory=list)
    """Le connessioni del tratto che l'etichetta nomina: e' cosi' che il preflight
    verifica che ogni tratto ne abbia una, e una sola."""
    corpo_mm: FiniteFloat | None = Field(default=None, gt=0)
    """Il corpo della scritta, se non e' quello delle scritte della tavola: il DN che
    a 9 punti non trova posto scende a 8, il minimo del PO (I-159). `None` e' il
    corpo di sempre, e non si scrive."""
    richiamo: Richiamo | None = None
    """Il richiamo, quando l'etichetta sta staccata dalla linea: e' l'ultima spiaggia
    per il DN di una strada principale che accanto alla linea non entra (I-162). La
    freccia tocca la linea del tratto, e l'etichetta e' orizzontale. `None` — il
    caso di sempre — non si scrive."""

    @model_serializer(mode="wrap")
    def _senza_il_corpo_di_sempre(self, handler: SerializerFunctionWrapHandler) -> dict[str, Any]:
        dati: dict[str, Any] = handler(self)
        for campo in ("corpo_mm", "richiamo"):
            if dati.get(campo) is None:
                dati.pop(campo, None)
        return dati


class NotaDellaLegenda(StrictModel):
    """Una riga della legenda che spiega una scritta, non un simbolo: «Øi» (I-155)."""

    campione: str = Field(min_length=1)
    righe: list[str] = Field(min_length=1)
    """La spiegazione, gia' andata a capo sulla larghezza della fascia: la prima
    riga sta in quota con il campione, le altre sotto, a un passo di griglia."""
    anchor: Point


class LegendEntry(StrictModel):
    symbol_id: str
    name: str
    anchor: Point


class NetworkKey(StrictModel):
    """Voce della sezione fluidi della legenda: colore e tratto di un fluido.

    Una per **fluido**, non per rete: primario e secondario portano la stessa
    acqua di riscaldamento e si disegnano uguali.
    """

    medium: str
    name: str
    colour: str
    dash: str
    anchor: Point


class CrossReference(StrictModel):
    id: str
    pair_id: str
    peer_sheet_id: str
    text: str
    anchor: Point


class RigaDellaTabella(StrictModel):
    """Un'apparecchiatura nella tabella in alto a sinistra (REL-006, I-141).

    Un campo `None` e' un dato che il progettista non ha dato: sulla tavola la
    cella resta vuota, con un trattino, e nessuno lo inventa (D-087, I-144)."""

    component_id: str
    codice: str | None
    """La sigla del pezzo: la stessa che il disegno scrive accanto al pezzo."""
    descrizione: str
    caratteristiche: str | None
    marca: str | None
    modello: str | None


class TabellaDelleApparecchiature(StrictModel):
    """La tabella delle apparecchiature, gia' impaginata: dove sta e quanto e' grande.

    La compone `graphics/tabella.py`; l'SVG e il DXF la disegnano dalle stesse
    misure, cosi' e' la stessa nei due."""

    x_mm: FiniteFloat
    y_mm: FiniteFloat
    colonne_mm: list[FiniteFloat] = Field(min_length=1)
    riga_mm: FiniteFloat = Field(gt=0)
    righe: list[RigaDellaTabella] = Field(min_length=1)

    @property
    def larghezza_mm(self) -> float:
        return sum(self.colonne_mm)

    @property
    def altezza_mm(self) -> float:
        """L'intestazione piu' una riga per apparecchiatura."""
        return self.riga_mm * (len(self.righe) + 1)

    @property
    def riquadro(self) -> tuple[float, float, float, float]:
        """`(sinistra, alto, destra, basso)`, in millimetri di carta."""
        return (
            self.x_mm,
            self.y_mm,
            self.x_mm + self.larghezza_mm,
            self.y_mm + self.altezza_mm,
        )


class SheetGeometry(StrictModel):
    sheet_id: str
    title: str
    symbols: list[PlacedSymbol] = Field(default_factory=list)
    routes: list[RoutedTrunk] = Field(default_factory=list)
    labels: list[PlacedLabel] = Field(default_factory=list)
    legend: list[LegendEntry] = Field(default_factory=list)
    network_keys: list[NetworkKey] = Field(default_factory=list)
    cross_references: list[CrossReference] = Field(default_factory=list)
    ground_line_y_mm: FiniteFloat | None = None
    """Ritirata (D-121, DRAW-003): la composizione non la scrive piu' e il
    renderer non la disegna in nessun caso. Il campo resta, sempre `None`, per
    leggere le geometrie gia' agli atti e per la catena che ancora lo nomina;
    la quota su cui le macchine si allineano e' un riferimento interno della
    posa, non un elemento della tavola."""
    tabella: TabellaDelleApparecchiature | None = None
    """La tabella delle apparecchiature in alto a sinistra (REL-006). Facoltativa
    e additiva: una tavola che non la porta si scrive come prima, senza il campo."""
    diametri: list[DiametroSullaTavola] = Field(default_factory=list)
    """Le etichette del DN, una per tratto (REL-007). Facoltative e additive come
    la tabella."""
    note_della_legenda: list[NotaDellaLegenda] = Field(default_factory=list)
    """Le righe della legenda che spiegano una scritta: «Øi» (REL-007, I-155)."""

    @model_serializer(mode="wrap")
    def _senza_la_tabella_che_non_c_e(
        self, handler: SerializerFunctionWrapHandler
    ) -> dict[str, Any]:
        """Una tabella che non c'e' non si scrive, nemmeno come `null`, e cosi' le
        etichette del DN e le note della legenda quando non ce ne sono: le
        geometrie scritte prima di REL-006 e di REL-007 restano identiche byte
        per byte."""
        dati: dict[str, Any] = handler(self)
        if dati.get("tabella") is None:
            dati.pop("tabella", None)
        for campo in ("diametri", "note_della_legenda"):
            if not dati.get(campo):
                dati.pop(campo, None)
        return dati


class DrawingGeometry(StrictModel):
    project_id: str
    sheets: list[SheetGeometry] = Field(default_factory=list)


TOLERANCE_MM = 1e-6
"""Tolleranza delle misure sulla spezzata: la stessa del validatore."""


def _sign(value: float) -> int:
    if value > TOLERANCE_MM:
        return 1
    if value < -TOLERANCE_MM:
        return -1
    return 0


def moves_of(polyline: list[Point]) -> list[tuple[Point, Point]]:
    """I soli tratti che percorrono una distanza: un punto ripetuto non e' un tratto."""
    return [
        (before, after)
        for before, after in zip(polyline, polyline[1:], strict=False)
        if abs(after.x_mm - before.x_mm) > TOLERANCE_MM
        or abs(after.y_mm - before.y_mm) > TOLERANCE_MM
    ]


def _one_way_overshoot_mm(polyline: list[Point], step_mm: float) -> float:
    """Di quanto la spezzata, letta da un capo, supera l'altro e ci torna.

    L'ultimo tratto dice su quale asse si arriva — orizzontale o verticale — e i
    due capi dicono da che parte: la spezzata viaggia dal primo punto all'ultimo,
    e su quell'asse non deve mai andare oltre l'arrivo. Se i due capi hanno la
    stessa coordinata sull'asse di arrivo non c'e' un verso di viaggio da
    superare, e la misura e' zero: quello e' un aggiramento, non un'andata e
    ritorno.

    **Un passo non e' un giro.** Una porta si imbocca solo dal lato verso cui
    guarda, quindi quando guarda dalla parte opposta al verso di marcia della
    tratta l'ultimo tratto cade per forza oltre la porta, e il minimo che
    l'instradatore possa lasciare e' **un passo di griglia**: quello e'
    l'imbocco, non un superamento. Contarlo faceva segnalare come bloccante una
    figura che nessuna disposizione puo' evitare — una ricerca esaustiva sulle
    pose raggiungibili dei due terminali di zona del caso completo non ne trova
    nemmeno una che la eviti. Si concede quel passo e nulla di piu': chi gira
    due passi oltre la porta ha davvero allungato la linea per tornare indietro,
    e resta un rilievo.
    """
    moves = moves_of(polyline)
    if not moves:
        return 0.0
    source, goal = polyline[0], polyline[-1]
    before, after = moves[-1]
    if abs(after.y_mm - before.y_mm) <= TOLERANCE_MM:
        direction = _sign(goal.x_mm - source.x_mm)
        beyond = [(point.x_mm - goal.x_mm) * direction for point in polyline]
        approach = (before.x_mm - goal.x_mm) * direction
    else:
        direction = _sign(goal.y_mm - source.y_mm)
        beyond = [(point.y_mm - goal.y_mm) * direction for point in polyline]
        approach = (before.y_mm - goal.y_mm) * direction
    # Quando la porta guarda nel verso di marcia l'ultimo tratto arriva da
    # dietro, `approach` e' negativo e non si concede niente: la misura resta
    # quella di prima, tolleranza zero dalla porta.
    return max(beyond) - min(max(approach, 0.0), step_mm)


def overshoot_mm(polyline: list[Point], step_mm: float) -> float:
    """B12, D-078 — di quanto la spezzata supera una propria porta e ci torna.

    E' **la** misura dell'andata e ritorno, e vive qui perche' due moduli la
    devono leggere identica: il preflight di qualita', che blocca la tavola
    quando e' positiva, e il ciclo di miglioramento, che sceglie le mosse per
    annullarla. Finche' stavano su due formule diverse il ciclo poteva credere
    di aver chiuso un giro che il preflight vedeva ancora.

    Vale su **entrambi** i capi, perche' il verso in cui una spezzata e' scritta
    e' una convenzione dell'instradatore e il difetto non lo e'. Il passo di
    griglia serve a riconoscere l'imbocco obbligato di una porta, che non e' un
    superamento.
    """
    return max(
        _one_way_overshoot_mm(polyline, step_mm),
        _one_way_overshoot_mm(list(reversed(polyline)), step_mm),
    )


def distance_to_box(
    before: Point, after: Point, box: tuple[float, float, float, float]
) -> float:
    """Distanza fra un tratto ortogonale e un riquadro, zero se lo tocca."""
    left, top, right, bottom = box
    x_low, x_high = min(before.x_mm, after.x_mm), max(before.x_mm, after.x_mm)
    y_low, y_high = min(before.y_mm, after.y_mm), max(before.y_mm, after.y_mm)
    gap_x = max(left - x_high, x_low - right, 0.0)
    gap_y = max(top - y_high, y_low - bottom, 0.0)
    return math.hypot(gap_x, gap_y)


def attaches_to(polyline: list[Point], box: tuple[float, float, float, float]) -> bool:
    """Vero se un capo della spezzata cade sul riquadro: la tratta ci si attacca.

    La geometria non porta il legame fra tratta e componente — porta gli
    identificativi delle connessioni, che sono un altro spazio di nomi — quindi
    l'attacco si riconosce dove si vede: un capo di spezzata sul bordo o dentro
    il riquadro e' una porta.
    """
    left, top, right, bottom = box
    return any(
        left - TOLERANCE_MM <= point.x_mm <= right + TOLERANCE_MM
        and top - TOLERANCE_MM <= point.y_mm <= bottom + TOLERANCE_MM
        for point in (polyline[0], polyline[-1])
    )


def box_of(symbol: PlacedSymbol) -> tuple[float, float, float, float]:
    return (symbol.origin.x_mm, symbol.origin.y_mm, symbol.right_mm, symbol.bottom_mm)


def lies_inside(
    box: tuple[float, float, float, float], before: Point, after: Point
) -> bool:
    """Vero se il riquadro **contiene** il tratto, bordi compresi.

    E' la misura storica di D-027, tenuta parola per parola. Prende due cose
    che l'attraversamento non prende, e la seconda vale la pena dirla: il
    tratto tutto dentro il corpo, e il tratto che corre **a filo del bordo**
    per la lunghezza del riquadro. Il secondo caso non entra nel corpo — sulla
    carta la linea passa esattamente sul fianco del simbolo — ma si legge come
    se ci passasse sopra, e la freccia del flusso ci finisce dentro. E' il
    difetto che il commento di questa misura chiamava «esattamente il difetto
    peggiore», ed e' una convenzione di rappresentazione: **restringerla non e'
    del disegnatore** (D-124).
    """
    left, top, right, bottom = box
    return (
        left < min(before.x_mm, after.x_mm) + TOLERANCE_MM
        and max(before.x_mm, after.x_mm) < right + TOLERANCE_MM
        and top < min(before.y_mm, after.y_mm) + TOLERANCE_MM
        and max(before.y_mm, after.y_mm) < bottom + TOLERANCE_MM
    )


def enters_body(
    box: tuple[float, float, float, float], before: Point, after: Point
) -> bool:
    """Vero se il tratto entra nel **corpo pieno** del riquadro (D-027).

    Entrare vuol dire percorrere una lunghezza maggiore di zero dentro il
    riquadro **aperto**, cioe' bordi esclusi. Ne discendono le due cose che
    servono, senza bisogno di sapere quali tratte tocchino quale componente:

    - il tratto che **termina su un attacco** non entra. Una porta sta sul
      perimetro del simbolo e l'instradamento ci arriva da fuori: il tratto
      tocca il bordo e si ferma li', quindi la sua lunghezza dentro il corpo
      e' nulla. Vale anche per chi costeggia il fianco a filo;
    - il tratto che **attraversa** il simbolo entra, e non importa se ne esce
      dall'altra parte.

    ⛔ **Da sola questa misura non basta, e non sostituisce quella storica.**
    Prima si guardava il **contenimento** (`lies_inside`), che vedeva soltanto il
    caso estremo: un tratto che entrava da un lato e usciva dall'altro — o che
    sporgeva di un millimetro oltre il bordo — passava per buono, ed era una
    linea disegnata **sotto** un simbolo invece che interrotta da lui. E' il
    difetto che la regola di vicinanza del PM (D-120) ha fatto affiorare
    avvicinando le valvole agli attacchi: e' bastato che l'accessorio si sedesse
    dove un'altra tratta si attacca alla stessa macchina.

    Le due misure prendono cose diverse e si usano **insieme**
    (`intrudes_into`): questa vede chi attraversa, quella vede chi corre a filo
    del fianco. Sostituire la seconda con la prima avrebbe **allentato** un
    controllo di rappresentazione, che non e' del disegnatore.
    """
    left, top, right, bottom = box
    x_low, x_high = min(before.x_mm, after.x_mm), max(before.x_mm, after.x_mm)
    y_low, y_high = min(before.y_mm, after.y_mm), max(before.y_mm, after.y_mm)
    inside_x = min(x_high, right) - max(x_low, left)
    inside_y = min(y_high, bottom) - max(y_low, top)
    if inside_x < -TOLERANCE_MM or inside_y < -TOLERANCE_MM:
        return False
    # Un tratto ortogonale ha spessore nullo su un asse: li' basta che cada
    # **dentro** il riquadro, bordi esclusi, e sull'altro che percorra una
    # lunghezza vera.
    if abs(y_high - y_low) <= TOLERANCE_MM:
        return top + TOLERANCE_MM < y_low < bottom - TOLERANCE_MM and (
            inside_x > TOLERANCE_MM
        )
    if abs(x_high - x_low) <= TOLERANCE_MM:
        return left + TOLERANCE_MM < x_low < right - TOLERANCE_MM and (
            inside_y > TOLERANCE_MM
        )
    return inside_x > TOLERANCE_MM and inside_y > TOLERANCE_MM


def intrudes_into(
    box: tuple[float, float, float, float], before: Point, after: Point
) -> bool:
    """La misura completa di D-027: chi attraversa il corpo o chi ci corre dentro.

    E' l'unione delle due, e sta in un posto solo perche' i due consumatori — il
    cancello di correttezza e chi posa gli accessori — devono dare la stessa
    risposta: chi posa chiede «questa posizione la consegno o no?», e se le due
    misure divergono si approva una tavola e se ne disegna un'altra.
    """
    return enters_body(box, before, after) or lies_inside(box, before, after)


def run_intrudes_on(
    box: tuple[float, float, float, float],
    routes: list[RoutedTrunk],
    clearance_mm: float,
) -> bool:
    """Vero se una di queste tratte, contro questo riquadro, e' un rilievo bloccante.

    E' l'unione esatta di cio' che i due validatori bloccano, e non un
    millimetro di piu': chi posa un simbolo deve poter chiedere «questa
    posizione la consegno o no?» e ricevere la stessa risposta che daranno loro.

    - **B5**: un tratto passa a meno della distanza di rispetto dal riquadro.
      Le spezzate che finiscono dentro il riquadro non si misurano: e' il modo
      in cui il preflight riconosce un attacco, e vale anche qui.
    - **D-027**: un tratto entra nel corpo del riquadro **o gli corre dentro a
      filo del bordo**, e allora la linea passa **sotto** il simbolo invece di
      essere interrotta da lui. Questo si misura sempre, esenzione o no: una
      spezzata che si attacca al simbolo e' esente dalla distanza di rispetto —
      e' cosi' che si riconosce un attacco — ma non dall'attraversarlo.
    """
    for route in routes:
        for segment in route.segments:
            moves = moves_of(segment)
            if any(intrudes_into(box, before, after) for before, after in moves):
                return True
            if attaches_to(segment, box):
                continue
            if any(
                distance_to_box(before, after, box) < clearance_mm - TOLERANCE_MM
                for before, after in moves
            ):
                return True
    return False


SHEET_FILL_MIN_RATIO = 0.45
"""Sotto questa quota dell'area di disegno il foglio e' **vuoto** (A1, D-140).

**Numero del PO**, non taratura del PM: il 17 settembre 2026 il PO ha fissato la
finestra del riempimento in **45–65 %** — «sotto il 45 % il disegno e' vuoto e
stretto insieme». Prima era tre quinti, e la soglia era una taratura del PM.

Vive accanto alla misura, e non fra i controlli, perche' da D-111 la leggono in
due: il **preflight**, che avvisa a tavola finita, e il **collocatore**, che la
insegue mentre dispone. Un numero solo, in un posto solo.
"""

SHEET_FILL_MAX_RATIO = 0.65
"""Sopra questa quota il foglio e' **stretto** (D-140).

L'altra sponda della finestra, e il motivo per cui e' una finestra e non una
soglia: il PO, «sopra il 65 % non ci sta piu' lo spazio per le sigle dei
componenti». Un disegno ben fatto e' anche **comodo** (D-139).
"""

SHEET_MARGIN_MM = 25.0
"""Il margine di rispetto fra l'inchiostro e il bordo dell'area (**D-143**).

**Numero del PO**, non taratura del PM: «non si mettono gli oggetti cosi' vicini
al bordo del foglio a meno che non ci sia un disegno molto molto pieno. Ma un
disegno cosi' comodo non si disegna dal bordo a bordo». Venticinque millimetri
per lato e' il **punto di partenza**, cioe' il margine di un disegno scarico.

Il margine sta **dentro** l'area su cui si misura il riempimento, non in
aggiunta: la finestra di D-140 continua a leggersi sui 350 x 235 mm.
"""

SHEET_MARGIN_MIN_MM = 10.0
"""Fin dove il margine si stringe, e non oltre (**D-143**).

Si stringe **solo per far entrare un disegno** che altrimenti non ci starebbe,
mai per far salire il riempimento: quella e' la dilatazione di D-142, che il
margine limita invece di assecondare.
"""

STACCO_DALLA_TABELLA_MM = 5.0
"""Quanto il disegno sta lontano dalla tabella delle apparecchiature (REL-006):
due passi di griglia. Niente del disegno — simboli, tubazioni, sigle — entra
nella tabella allargata di questo stacco. *Taratura della sessione*, da
giudicare sulla tavola."""


def zona_della_tabella(
    riquadro: tuple[float, float, float, float],
    stacco_mm: float = STACCO_DALLA_TABELLA_MM,
) -> tuple[float, float, float, float]:
    """La tabella delle apparecchiature allargata dello stacco: dove il disegno
    non entra, e nemmeno le sue scritte."""
    return (
        riquadro[0] - stacco_mm,
        riquadro[1] - stacco_mm,
        riquadro[2] + stacco_mm,
        riquadro[3] + stacco_mm,
    )


def border_margin_mm(
    symbols: list[PlacedSymbol],
    routes: list[RoutedTrunk],
    area: tuple[float, float, float, float],
) -> float | None:
    """Quanto dista dal bordo dell'area il pezzo che gli sta piu' vicino.

    E' il minimo dei quattro lati, e puo' essere negativo se il disegno esce.
    `None` quando non c'e' inchiostro: un foglio vuoto non ha un margine.
    """
    box = ink_box(symbols, routes)
    if box is None:
        return None
    return min(
        box[0] - area[0], box[1] - area[1], area[2] - box[2], area[3] - box[3]
    )


def margin_allowed_mm(
    symbols: list[PlacedSymbol],
    routes: list[RoutedTrunk],
    area: tuple[float, float, float, float],
    step_mm: float,
) -> float:
    """Il margine che **questo** disegno puo' permettersi (D-143).

    Venticinque millimetri se l'ingombro ci sta; altrimenti il piu' largo che
    ci sta, sulla griglia, e mai meno di dieci. Un disegno che non entra
    nemmeno a dieci resta con dieci: non e' il margine ad averlo stretto, e il
    preflight lo dice.

    E' la misura con cui si giudica un disegno vicino al bordo: vicino **e'
    autorizzato** solo quando il disegno, di suo, non poteva stare piu' dentro.
    """
    box = ink_box(symbols, routes)
    if box is None:
        return SHEET_MARGIN_MM
    width, height = box[2] - box[0], box[3] - box[1]
    room = min((area[2] - area[0] - width) / 2.0, (area[3] - area[1] - height) / 2.0)
    on_grid = int((room + TOLERANCE_MM) // step_mm) * step_mm
    return max(min(SHEET_MARGIN_MM, on_grid), SHEET_MARGIN_MIN_MM)


QUADRANT_IMBALANCE_MAX = 3.0
"""Rapporto massimo fra il quadrante piu' pieno e il piu' vuoto (A1, A3).

**Taratura.** «Si copre meta' foglio con una mano: se una meta' e' quasi bianca
e l'altra e' fitta, non va», e «i quattro margini bianchi si somigliano». Tre
volte e' lo squilibrio oltre il quale la differenza si vede da due metri.
"""


def ink_box(
    symbols: list[PlacedSymbol], routes: list[RoutedTrunk]
) -> tuple[float, float, float, float] | None:
    """L'ingombro di cio' che e' disegnato: simboli e tubazioni.

    Legenda e fluidi vivono nella propria fascia, fuori dall'area di disegno per
    costruzione, e non entrano nel conto: il riempimento che la carta chiede e'
    quello del disegno, non quello del foglio.
    """
    xs: list[float] = []
    ys: list[float] = []
    for symbol in symbols:
        xs += [symbol.origin.x_mm, symbol.right_mm]
        ys += [symbol.origin.y_mm, symbol.bottom_mm]
    for route in routes:
        for segment in route.segments:
            xs += [point.x_mm for point in segment]
            ys += [point.y_mm for point in segment]
    if not xs or not ys:
        return None
    return (min(xs), min(ys), max(xs), max(ys))


def fill_ratio(
    symbols: list[PlacedSymbol],
    routes: list[RoutedTrunk],
    area: tuple[float, float, float, float],
) -> float:
    """Quanta parte dell'area di disegno copre l'ingombro dell'inchiostro (A1).

    Vive qui, e non fra i controlli, perche' due moduli la devono leggere
    identica: il **preflight**, che avvisa quando la tavola e' una fascia, e il
    **collocatore**, che da D-111 la usa come obiettivo mentre dispone invece di
    scoprirla alla fine. Finche' stavano su due formule diverse il collocatore
    poteva credere di aver riempito un foglio che il preflight vedeva vuoto.
    """
    box = ink_box(symbols, routes)
    if box is None:
        return 0.0
    width = max(box[2] - box[0], TOLERANCE_MM)
    height = max(box[3] - box[1], TOLERANCE_MM)
    span_x = max(area[2] - area[0], TOLERANCE_MM)
    span_y = max(area[3] - area[1], TOLERANCE_MM)
    return (width * height) / (span_x * span_y)


def quadrants_of(
    area: tuple[float, float, float, float],
) -> list[tuple[float, float, float, float]]:
    """I quattro quadranti di un rettangolo, in ordine di lettura."""
    half_width = (area[2] - area[0]) / 2.0
    half_height = (area[3] - area[1]) / 2.0
    return [
        (x_mm, y_mm, x_mm + half_width, y_mm + half_height)
        for y_mm in (area[1], area[1] + half_height)
        for x_mm in (area[0], area[0] + half_width)
    ]


def _clipped_length_mm(
    before: Point, after: Point, area: tuple[float, float, float, float]
) -> float:
    """Quanto di un tratto ortogonale cade dentro un rettangolo."""
    if abs(before.y_mm - after.y_mm) <= TOLERANCE_MM:
        if not area[1] - TOLERANCE_MM <= before.y_mm <= area[3] + TOLERANCE_MM:
            return 0.0
        low, high = min(before.x_mm, after.x_mm), max(before.x_mm, after.x_mm)
        return max(min(high, area[2]) - max(low, area[0]), 0.0)
    if abs(before.x_mm - after.x_mm) <= TOLERANCE_MM:
        if not area[0] - TOLERANCE_MM <= before.x_mm <= area[2] + TOLERANCE_MM:
            return 0.0
        low, high = min(before.y_mm, after.y_mm), max(before.y_mm, after.y_mm)
        return max(min(high, area[3]) - max(low, area[1]), 0.0)
    return 0.0


def ink_area_mm2(
    symbols: list[PlacedSymbol],
    routes: list[RoutedTrunk],
    area: tuple[float, float, float, float],
    line_mm: float,
) -> float:
    """L'inchiostro dentro un rettangolo: riquadri dei simboli piu' tratto delle linee."""
    total = 0.0
    for symbol in symbols:
        left, top, right, bottom = box_of(symbol)
        width = max(min(right, area[2]) - max(left, area[0]), 0.0)
        height = max(min(bottom, area[3]) - max(top, area[1]), 0.0)
        total += width * height
    for route in routes:
        for segment in route.segments:
            for before, after in moves_of(segment):
                total += _clipped_length_mm(before, after, area) * line_mm
    return total


def ink_imbalance(
    symbols: list[PlacedSymbol],
    routes: list[RoutedTrunk],
    area: tuple[float, float, float, float],
    line_mm: float,
) -> float:
    """Quanto il quadrante piu' pieno pesa piu' del piu' vuoto (A1, A3).

    Un quadrante senza inchiostro vale infinito: e' il caso del disegno tutto
    su un lato, che non e' uno squilibrio grande ma un difetto di specie diversa.
    """
    areas = [
        ink_area_mm2(symbols, routes, quadrant, line_mm)
        for quadrant in quadrants_of(area)
    ]
    if max(areas) <= TOLERANCE_MM:
        return 1.0
    if min(areas) <= TOLERANCE_MM:
        return math.inf
    return max(areas) / min(areas)


INK_COVERAGE_CELLS = 8
"""In quante parti per lato si divide l'ingombro per contare i vuoti.

Otto per otto sono sessantaquattro celle: abbastanza fitte da isolare una
propaggine larga un tubo, abbastanza larghe da non contare come vuoto lo stacco
fra due componenti vicini.
"""


INK_COVERAGE_MIN = 0.75
"""Sotto questa copertura l'ingombro porta una fascia vuota: una propaggine.

**Taratura, misurata sulle tavole dell'impianto 1** e non scelta a occhio: la
tavola compatta di partenza copre 0,86; quella che si era comprata tredici punti
di riempimento spingendo uno sfiato diciassette millimetri sopra tutto il resto
copre 0,69; quella senza propaggini, 0,81. Tre quarti stanno in mezzo, e
lasciano al collocatore lo spazio per aprire il disegno senza lasciarci dentro
una striscia di carta bianca attraversata da un solo stelo.
"""


def ink_coverage(
    symbols: list[PlacedSymbol],
    routes: list[RoutedTrunk],
    box: tuple[float, float, float, float] | None,
    cells: int = INK_COVERAGE_CELLS,
) -> float:
    """Quante celle dell'ingombro portano inchiostro, sul totale.

    E' la misura che riconosce una **propaggine**, e serve perche' il
    riempimento da solo non la vede: il riempimento guarda il rettangolo che
    circonda il disegno, quindi un pezzo leggero spinto lontano da tutti lo
    allunga di due centimetri di carta bianca e il numero sale. Qui invece quel
    pezzo riempie una cella su otto della propria fascia, e la copertura scende.

    ⛔ **Non basta guardare lo squilibrio fra i quattro quadranti**, ed e' un
    errore gia' commesso: misurato sui quadranti dell'ingombro da' *esattamente*
    lo stesso numero che sui quadranti dell'area centrata su di esso — stesse
    rette di divisione, stesso inchiostro — quindi non aggiunge niente. Una
    propaggine sta dentro un quadrante e non lo svuota: lo si vede solo
    guardando piu' fitto.
    """
    if box is None or cells <= 0:
        return 1.0
    width, height = box[2] - box[0], box[3] - box[1]
    if width <= TOLERANCE_MM or height <= TOLERANCE_MM:
        return 1.0
    step_x, step_y = width / cells, height / cells

    # L'inchiostro si versa **nelle celle** che ciascun pezzo tocca, invece di
    # rileggere tutto il disegno per ciascuna delle sessantaquattro. E' la
    # stessa somma, con la stessa formula e nello stesso ordine — prima i
    # simboli, poi le tubazioni — quindi lo stesso numero: cambia solo che le
    # celle lontane da un pezzo non gli fanno piu' sommare uno zero. Da
    # `DRAW-012` questo conto sta accanto al riempimento **dentro** il costo di
    # posa (D-141), e vi si entra migliaia di volte per tavola.
    poured = [0.0] * (cells * cells)

    def span(low: float, high: float, origin: float, step: float) -> range:
        """Le celle di un lato che un intervallo puo' toccare, tolleranza compresa."""
        first = int((low - origin - TOLERANCE_MM) // step)
        last = int((high - origin + TOLERANCE_MM) // step)
        return range(max(first, 0), min(last, cells - 1) + 1)

    for symbol in symbols:
        left, top, right, bottom = box_of(symbol)
        for row in span(top, bottom, box[1], step_y):
            top_mm = box[1] + row * step_y
            bottom_mm = top_mm + step_y
            covered = max(min(bottom, bottom_mm) - max(top, top_mm), 0.0)
            if covered <= 0.0:
                continue
            for col in span(left, right, box[0], step_x):
                left_mm = box[0] + col * step_x
                right_mm = left_mm + step_x
                across = max(min(right, right_mm) - max(left, left_mm), 0.0)
                poured[row * cells + col] += across * covered

    for route in routes:
        for segment in route.segments:
            for before, after in moves_of(segment):
                low_x, high_x = min(before.x_mm, after.x_mm), max(before.x_mm, after.x_mm)
                low_y, high_y = min(before.y_mm, after.y_mm), max(before.y_mm, after.y_mm)
                for row in span(low_y, high_y, box[1], step_y):
                    top_mm = box[1] + row * step_y
                    for col in span(low_x, high_x, box[0], step_x):
                        left_mm = box[0] + col * step_x
                        cell = (left_mm, top_mm, left_mm + step_x, top_mm + step_y)
                        poured[row * cells + col] += _clipped_length_mm(
                            before, after, cell
                        )

    return sum(1 for value in poured if value > TOLERANCE_MM) / float(cells * cells)


def drawing_fingerprint(drawing: DrawingGeometry) -> str:
    """Impronta riproducibile della geometria.

    Stesso modello e stesso piano di impaginazione devono dare la stessa
    tavola: questa e' la misura che lo dimostra, come `project_fingerprint`
    fa per il modello tecnico.
    """
    payload = json.dumps(
        drawing.model_dump(mode="json"),
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
        allow_nan=False,
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()
