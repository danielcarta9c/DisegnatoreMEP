"""Una proposta: cosa, dove, perche', e da quale regola.

Non e' una modifica. Il motore le produce, l'ingegnere le approva, e solo dopo
qualcuno le applica (§9.2). Il campo che conta per il dossier e' `rationale`:
una proposta senza motivazione non e' rappresentabile, perche' non ci sarebbe
niente da approvare.
"""

from collections.abc import Iterable
from enum import StrEnum

from pydantic import Field

from disegnatore_mep.model.base import ID_PATTERN, StrictModel
from disegnatore_mep.model.project import PortRef
from disegnatore_mep.model.types import IntegrationCategory


class GapReason(StrEnum):
    """Perche' una regola che si applica non ha niente da proporre."""

    MISSING_PIECE = "missing_piece"
    """Il catalogo non ha nessun pezzo con quella funzione su quel fluido."""

    NO_COMMON_RUN = "no_common_run"
    """La regola si posa sul tratto comune della rete, e la rete non ne ha
    uno: le camminate dagli ancoraggi non condividono nessuna tubazione."""

    NO_SOURCE_NETWORK = "no_source_network"
    """La regola propone un **ponte** fra due reti, e la rete da cui il ponte
    dovrebbe pescare non c'e' o non ha una sorgente gia' approvata. Un ponte
    con un capo nel vuoto non e' un pezzo: e' una domanda al progettista
    (DRAW-006-R1, blocco D.2)."""

    ON_BOARD_UNKNOWN = "on_board_unknown"
    """La regola aggiungerebbe un dispositivo perche' la macchina non lo porta
    a bordo, ma il catalogo non dice se lo porta: il dato e' ignoto, e un
    dato ignoto non e' un'assenza (I-046). Si chiede al progettista."""


class RuleGap(StrictModel):
    """Una regola che si applica, e non ha niente da proporre.

    Non e' la stessa cosa di una regola che non si applica. Qui le condizioni
    sono vere — c'e' un pezzo che chiede quell'accessorio — ma il catalogo non
    ha nessuna voce che porti quella funzione su quel fluido. **Tacere sarebbe
    inventare al contrario**: l'ingegnere leggerebbe un elenco completo di
    integrazioni e crederebbe che non manchi niente.

    Non blocca. E' un punto aperto che entra nel dossier accanto alle proposte,
    con la stessa categoria della regola che lo ha generato: se la regola era
    necessaria, il punto aperto e' necessario.
    """

    rule_id: str = Field(pattern=ID_PATTERN)
    rule_version: str = Field(pattern=r"^\d+\.\d+\.\d+$")
    category: IntegrationCategory
    name: str = Field(min_length=1)
    network_id: str = Field(pattern=ID_PATTERN)
    medium: str = Field(pattern=ID_PATTERN)
    anchor: PortRef
    """Il primo attacco rimasto scoperto. Ce ne possono essere altri sulla
    stessa rete: il punto aperto e' uno solo perche' il pezzo che manca in
    catalogo e' uno solo."""

    missing_function: str = Field(min_length=1)
    reason: GapReason = GapReason.MISSING_PIECE
    """Cosa manca davvero: il pezzo in catalogo, o il posto sulla rete."""

    rationale: str = Field(min_length=1)
    source: str = Field(min_length=1)

    @property
    def key(self) -> tuple[str, str, str, str]:
        """Cosa rende due punti aperti lo stesso punto aperto.

        Il pezzo che manca in catalogo manca una volta per rete; il dato di
        bordo che manca, invece, manca **per macchina**: la domanda si fa a
        ciascuna, e due macchine sono due domande."""
        if self.reason is GapReason.ON_BOARD_UNKNOWN:
            return (self.rule_id, self.network_id, self.missing_function, self.anchor.component_id)
        return (self.rule_id, self.network_id, self.missing_function, self.medium)


class RuleProposal(StrictModel):
    """Un accessorio proposto su un attacco di un componente esistente."""

    rule_id: str = Field(pattern=ID_PATTERN)
    rule_version: str = Field(pattern=r"^\d+\.\d+\.\d+$")
    category: IntegrationCategory
    component_id: str = Field(pattern=ID_PATTERN)
    definition_id: str = Field(pattern=ID_PATTERN)
    name: str = Field(min_length=1)
    network_id: str = Field(pattern=ID_PATTERN)
    anchor: PortRef
    """L'attacco su cui si posa. La connessione si ritrova al momento di
    applicare, non si registra qui: se un'altra proposta e' gia' stata applicata
    sullo stesso attacco, la connessione di allora non esiste piu'."""

    inlet_port: str = Field(pattern=ID_PATTERN)
    outlet_port: str = Field(pattern=ID_PATTERN)

    source_anchor: PortRef | None = None
    """L'attacco della rete da cui un **ponte** pesca (DRAW-006-R1, blocco D).

    Vuoto per tutto cio' che sta dentro una tubazione sola. Quando c'e', il
    pezzo ha due capi: `anchor` e' quello sulla rete di cui la regola parla, e
    questo e' quello sulla rete da cui il fluido arriva — la sorgente che il
    progettista ha gia' dichiarato. Chi applica apre una derivazione da
    ciascuna parte."""

    bridge_port: str | None = Field(default=None, pattern=ID_PATTERN)
    """Il terzo attacco di un ponte **in linea** (D-175): il pezzo spezza la
    tubazione su cui la regola parla, fra `inlet_port` e `outlet_port`, e da
    qui riceve l'altro fluido dal proprio confine di rete. Vuoto per il ponte
    ordinario."""

    service_port: str | None = Field(default=None, pattern=ID_PATTERN)
    """L'attacco di servizio dell'ancoraggio su cui questo accessorio si appende.

    Vale solo per gli accessori che pendono da uno stacco (D-101). Se e'
    valorizzato, la macchina quell'attacco ce l'ha e l'accessorio ci si collega;
    se e' vuoto, la macchina non ce l'ha e lo stacco si apre sulla tubazione, con
    un raccordo. Chi applica non lo ridecide: lo ha gia' stabilito chi ha
    valutato la regola, guardando cosa la macchina dichiara.
    """

    rationale: str = Field(min_length=1)
    source: str = Field(min_length=1)


def proposed_component_id(definition_id: str, anchor: PortRef) -> str:
    """Identificativo derivato dai dati, mai da un contatore.

    Un contatore renderebbe il modello dipendente dall'ordine in cui le proposte
    sono state approvate: rieseguire produrrebbe identificativi diversi e il
    disegno non sarebbe piu' rigenerabile identico (§3.4 del piano).
    """
    return f"{definition_id}-{anchor.component_id}-{anchor.port_id}".replace("_", "-")


def anchor_of_proposed(
    component_id: str, definition_id: str, attachments: Iterable[tuple[str, str]]
) -> PortRef | None:
    """L'attacco su cui una proposta e' stata posata, riletto dal suo identificativo.

    E' l'inverso di `proposed_component_id`, e si legge **confrontando** con gli
    attacchi che esistono davvero, mai spezzando la stringa a naso: un
    identificativo derivato dai dati si riconosce solo ricostruendolo dagli
    stessi dati. Vuoto per cio' che nessuna proposta ha posato — quello che il
    progettista ha scritto — o che non deriva da nessuno di questi attacchi.
    """
    for owner, port_id in attachments:
        anchor = PortRef(component_id=owner, port_id=port_id)
        if proposed_component_id(definition_id, anchor) == component_id:
            return anchor
    return None


__all__ = [
    "GapReason",
    "RuleGap",
    "RuleProposal",
    "anchor_of_proposed",
    "proposed_component_id",
]
