"""Grandezze grafiche in millimetri di carta.

Unico punto in cui vivono le grandezze della carta: dimensioni del foglio,
margini, griglia, spessori dei tratti, altezze di testo. Un modulo che
disegna puo' nominare le proprie costanti di impaginazione, ma nessun valore
dimensionale puo' restare un numero anonimo nel codice, qui o altrove.
"""

from pydantic import Field, model_validator

from disegnatore_mep.model.base import FiniteFloat, StrictModel

from .symbol import StrokeWeight

PT_MM = 25.4 / 72
"""Un punto tipografico in millimetri di carta: i corpi dei testi si dicono in punti."""

CORPO_DELLE_SCRITTE_PT = 9.0
"""Il corpo delle scritte del disegno, in punti (I-159, 29 settembre 2026).

Il PO: «Adesso mi sembra che sta a circa 5, dovrebbe essere almeno 8 o meglio
9». Il «circa 5» era misurato: 1,8 mm, 5,1 pt, per sigle, dati, DN, legenda,
tabella e intestazione. Nove punti sono 3,175 mm."""

CORPO_MINIMO_PT = 8.0
"""Il corpo sotto cui nessuna scritta del disegno scende (I-159): «almeno 8»."""

FAMIGLIA_DELLE_SCRITTE = "Arial, Helvetica, sans-serif"
"""Il carattere di tutte le scritte della tavola e del foglio dei simboli
(REL-008): lo dichiara la radice dell'SVG, e ogni testo lo eredita. Prima lo
dichiaravano solo il DN, la tabella e il cartiglio, e sigle, legenda e rimandi
uscivano nel PDF con le grazie (I-122). Il DXF e' in Arial da `REL-004`."""


class GraphicStandard(StrictModel):
    sheet_width_mm: FiniteFloat = Field(gt=0)
    sheet_height_mm: FiniteFloat = Field(gt=0)
    margin_left_mm: FiniteFloat = Field(ge=0)
    margin_right_mm: FiniteFloat = Field(ge=0)
    margin_top_mm: FiniteFloat = Field(ge=0)
    margin_bottom_mm: FiniteFloat = Field(ge=0)
    grid_mm: FiniteFloat = Field(gt=0)
    line_thin_mm: FiniteFloat = Field(gt=0)
    line_medium_mm: FiniteFloat = Field(gt=0)
    line_thick_mm: FiniteFloat = Field(gt=0)
    text_small_mm: FiniteFloat = Field(gt=0)
    text_normal_mm: FiniteFloat = Field(gt=0)
    text_title_mm: FiniteFloat = Field(gt=0)
    min_clearance_mm: FiniteFloat = Field(gt=0)

    @property
    def usable_width_mm(self) -> float:
        return self.sheet_width_mm - self.margin_left_mm - self.margin_right_mm

    @property
    def usable_height_mm(self) -> float:
        return self.sheet_height_mm - self.margin_top_mm - self.margin_bottom_mm

    def line_mm(self, weight: StrokeWeight) -> float:
        """I millimetri di un peso di tratto dichiarato da un simbolo (I-041).

        E' l'unica traduzione fra la classe dichiarata nel manifesto e la
        carta: tavola, legenda e foglio di riscontro passano tutti da qui.
        """
        return {
            StrokeWeight.THIN: self.line_thin_mm,
            StrokeWeight.MEDIUM: self.line_medium_mm,
            StrokeWeight.THICK: self.line_thick_mm,
        }[weight]

    def legend_line_mm(self, weight: StrokeWeight) -> float:
        """Il tratto con cui la legenda disegna un simbolo di quel peso.

        La legenda alleggerisce i simboli ordinari di una classe — li disegna
        sottili, come ha sempre fatto, perche' un campione da otto millimetri
        di un serbatoio scalato porta le linee vicine — ma **conserva il tratto
        spesso dichiarato**: lo spessore e' parte del segno, e un filtro a Y
        sottile in legenda non sarebbe il filtro della tavola (I-041).
        """
        if weight is StrokeWeight.THICK:
            return self.line_thick_mm
        return self.line_thin_mm

    @model_validator(mode="after")
    def geometry_is_coherent(self) -> "GraphicStandard":
        if self.usable_width_mm <= 0 or self.usable_height_mm <= 0:
            raise ValueError("margins leave no usable area")
        if not self.line_thin_mm < self.line_medium_mm < self.line_thick_mm:
            raise ValueError("line weights must increase from thin to thick")
        if not self.text_small_mm < self.text_normal_mm < self.text_title_mm:
            raise ValueError("text heights must increase from small to title")
        return self


# I margini sono quelli del cartiglio Nove C fornito come input del progetto: 10 mm sui
# quattro lati (D-053). Non vengono da ISO 5457, che il registro fonti elenca ancora «da
# acquisire e valutare», e che avrebbe imposto 20 mm di rilegatura a sinistra.
# I due assi restano asimmetrici rispetto alla griglia: la larghezza utile (400 mm) e' un
# numero intero di passi (160), l'altezza (277) no (110,8). I margini non vengono corretti
# per forzare entrambi gli assi sulla griglia: la squadratura e' quella del cartiglio.
A3_LANDSCAPE = GraphicStandard(
    sheet_width_mm=420.0,
    sheet_height_mm=297.0,
    margin_left_mm=10.0,
    margin_right_mm=10.0,
    margin_top_mm=10.0,
    margin_bottom_mm=10.0,
    grid_mm=2.5,
    line_thin_mm=0.18,
    line_medium_mm=0.35,
    line_thick_mm=0.50,
    text_small_mm=CORPO_DELLE_SCRITTE_PT * PT_MM,
    text_normal_mm=3.5,
    text_title_mm=5.0,
    min_clearance_mm=2.0,
)

# L'A4 orizzontale e' il formato per i disegni piccoli (D-058). Stessa squadratura a 10 mm
# e stessa taratura di tratti e testi dell'A3: la scala di stampa e' invariante (ADR 0003),
# quindi un simbolo misura lo stesso su entrambi i fogli e cambia solo quanto ce ne sta.
A4_LANDSCAPE = A3_LANDSCAPE.model_copy(
    update={"sheet_width_mm": 297.0, "sheet_height_mm": 210.0}
)

# **Oltre l'A3 si va** (D-148, 19 settembre 2026). Il divieto di D-058 — «ne' A2, ne' A0,
# ne' strisce» — nasceva da come l'elaborato veniva consegnato: si stampa in ufficio e si
# maneggia. Da I-072 la tavola esce anche in **DXF**, e il disegnatore la rifinisce in
# AutoCAD: il foglio e' diventato un contenitore, non il prodotto. E il divieto costava
# tavole intere — misurato il 19 settembre, tutt'e tre gli impianti che non uscivano
# fallivano contro il bordo destro dell'area A3, e l'impianto 4 esce su A2 senza toccare
# nient'altro.
#
# Stessa squadratura e stessa taratura di tratti e testi: la scala di stampa e'
# invariante (ADR 0003), quindi un simbolo misura lo stesso su ogni foglio e cambia
# soltanto quanto ce ne sta.
A2_LANDSCAPE = A3_LANDSCAPE.model_copy(
    update={"sheet_width_mm": 594.0, "sheet_height_mm": 420.0}
)

A1_LANDSCAPE = A3_LANDSCAPE.model_copy(
    update={"sheet_width_mm": 841.0, "sheet_height_mm": 594.0}
)
